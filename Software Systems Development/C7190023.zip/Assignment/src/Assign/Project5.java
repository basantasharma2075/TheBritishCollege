package Assign;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.attribute.DosFileAttributes;

public class Project5 implements Project2 {

	@Override
	public String produceFileHash(File file) {
		//Encodes this String into a sequence of bytes using theplatform's default charset, storing the result into a new byte array. 
		byte[] byt = file.getName().getBytes();
		//assigning he value
		long hashing = 0;
		
		for(byte bt : byt){
			//puting the value in hashing
			hashing += bt*5329745;
		}
		hashing *= hashing*3;
		//Returns a string representation of the longargument as an unsigned integer in base 16

		return Long.toHexString(hashing);
	}

	@Override
	//The String class represents character strings. 
	//Allstring literals in Java programs, such as "abc", areimplemented as instances of this class. 
	public String produceDirHash(File file) {
		//Returns an array of abstract pathnames denoting the files in thedirectory denoted by this abstract pathname
		File[] all = file.listFiles();
		//declaring the variable
		long val1 = 0;
		byte[] byt = null;
		for(File fil : all){
			//Returns the name of the file or directory denoted by this abstractpathname. 
            //This is just the last name in the pathname's namesequence. 
			//If the pathname's name sequence is empty, then the emptystring is returned

			byt = fil.getName().getBytes();
			for(byte bt1 : byt){
				//assigning value
				val1 += bt1*1283822;
			}
		}
		//assigning the value
		val1 *= val1*45;
		//this class provides several methods for convertinga long to a String and a String to a long, 
		//as well as other constants and methods useful when dealingwith a long. 
		return Long.toHexString(val1);
	}

	@Override
	public String produceDirMetaHash(File file) {
		//retrieve an array of File objects for each file in the directory, and then call the getName() method to get the filename
		File[] all = file.listFiles();
		//declaring the value of variable
		long val1 = 0;
		long val2 = 0;
		byte[] bt1 = null;
		for(File fil : all){
			//to obtain the filesystem path.
			Path fileP = Paths.get(file.getAbsolutePath());
			try {
				//File attributes associated with a file in a file system that supportslegacy "DOS" attributes. 
			    DosFileAttributes attribute1 = null;
				try {
					//Reads a file's attributes as a bulk operation. 
					attribute1 = Files.readAttributes(fileP, DosFileAttributes.class);
					
					//Signals that an I/O exception of some sort has occurred. 
					//Thisclass is the general class of exceptions produced by failed orinterrupted I/O operations.
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				//Returns the size of the file (in bytes). 
				//The size may differ from theactual size on the file system due to compression, support for sparsefiles, or other reasons.
			    val2 = attribute1.size();
			    bt1 = attribute1.creationTime().toString().getBytes();
			    //Thrown to indicate that the requested operation is not supported.
			} catch (UnsupportedOperationException exc) {
				
				//error message
			    System.err.println("DOS file" +
			        " attributes not supported:" + exc);
			}
			//assigning the value
			for(byte sw : bt1) {
				val1 += sw*23;
			}
			val1 += val2*6;//assigning the value
		}
		val1 *= val1*8;
		//Returns a string representation of the longargument as an unsigned integer in base 16. 
		return Long.toHexString(val1);
	}
	



}
