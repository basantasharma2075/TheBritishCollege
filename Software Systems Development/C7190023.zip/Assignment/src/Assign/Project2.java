package Assign;

import java.io.File;

public interface Project2 {
	
	
	//Generate a hash value using the contents of a given file .... throw new 
	//\InvalidArgumentException('Second argument must be a string');
	String produceFileHash(File file);
	//Generate a hash value using the contents of a given file .... throw new 
	//\InvalidArgumentException('Second argument must be a string');

	String produceDirHash(File file);

	//Generate a hash value using the contents of a given file .... throw new 
		//\InvalidArgumentException('Second argument must be a string');

	String produceDirMetaHash(File file);



}
