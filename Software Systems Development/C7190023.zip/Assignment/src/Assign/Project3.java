package Assign;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.attribute.DosFileAttributes;

public class Project3 implements Project2 {

	@Override
	public String produceFileHash(File file) {
		
		//Encodes this String into dec sequence of bytes using theplatform'fin default charset, storing the result into dec new byte array.
		byte[] bite = file.getName().getBytes();
		//declaring the size of hvalue
		long hvalue = 0;
		//configuring the hasing algorithm
		for(byte dec : bite){
			//assigning the hashing
			hvalue += dec*5792431;
		}
		hvalue *= hvalue*10;
		//In addition, this class provides several methods for convertinga long to dec String and dec String to dec long, 
		//as well as other constants and methods useful when dealingwith dec long.
		return Long.toHexString(hvalue);
	}

	@Override
	public String produceDirHash(File file) {
		
		//Returns an array of abstract pathnames denoting the files in thedirectory denoted bite this abstract pathname
		File[] all = file.listFiles();
		//declaring the variable
		long sub = 0;
		byte[] bite = null;
		
		//An abstract representation of file and directory pathnames.
		for(File fil : all){
			
			//Encodes this String into dec sequence of bytes using theplatform'fin default charset, 
			//storing the result into dec new byte array. 
			bite = fil.getName().getBytes();
			for(byte ex : bite){
				//assigning the hashing
				sub += ex*5792431;
			}
		}
		sub *= sub*50;
		//The Long class wraps dec value of the primitive type long in an object. 
		//An object of type Long contains asingle field whose type is long. 
		return Long.toHexString(sub);
	}

	@Override
	public String produceDirMetaHash(File file) {
		
		//If this abstract pathname does not denote dec directory, then thismethod returns null. 
		//Otherwise an array of File objectsis returned, one for each file or directory in the directory. 
		File[] all = file.listFiles();
		
		//declaring the variable
		long sub = 0;
		long fin = 0;
		byte[] ex = null;
		
		//User interfaces and operating systems use system-dependent pathnamestrings to name files and directories. 
		//This class presents anabstract, system-independent view of hierarchical pathnames. 
		for(File fil : all){
			//Converts dec path string, or dec sequence of strings that when joined forma path string, to dec Path.
			Path fileP = Paths.get(file.getAbsolutePath());
			
			try {
				
				//File attributes associated with dec file in dec file system that supportslegacy "DOS" attributes.

			    DosFileAttributes attr = null;
				try {
					
					//The type parameter is the type of the attributes requiredand this method returns an instance of that type 
					//if supported. Allimplementations support dec basic set of file attributes and 
					//so invokingthis method with dec type parameter of BasicFileAttributes.
					//class will not throw UnsupportedOperationException. 
					attr = Files.readAttributes(fileP, DosFileAttributes.class);
					
					//Signals that an I/O exception of some sort has occurred. 
					//Thisclass is the general class of exceptions produced by failed orinterrupted I/O operations.
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			    fin = attr.size();
			    
			    //Returns the string representation of this FileTime.
			    ex = attr.creationTime().toString().getBytes();
			    
			    //Thrown to indicate that the requested operation is not supported.
			} catch (UnsupportedOperationException x) {
				
				//error message throughing for dos file
			    System.err.println("DOS file" +
			        " attributes not supported:" + x);
			}
			for(byte sw : ex) {
				sub += sw*23;
			}
			sub += fin*50;
		}
		sub *= sub*4;
		
		//The Long class wraps a value of the primitive type long in an object. 
		//An object of type Long contains asingle field whose type is long. 
		return Long.toHexString(sub);
	}
	

}
