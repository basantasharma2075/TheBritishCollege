package Assign;

import java.awt.GridLayout;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

import javax.swing.ButtonGroup;
import javax.swing.ImageIcon;
import javax.swing.JCheckBox;
import javax.swing.JFileChooser;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;

public class Project4 extends JPanel{
	
	
	//declaring the menu item loader exit and about
	JMenuItem loader,exit,about;
	//declaring the check box
	JCheckBox cbox1, cbox2, cbox3;
	//declaring the radio button
	JRadioButton rrbutton1,rrbutton2,rrbutton3;
	//declaring the true or false
	boolean exists;
	JMenuBar setupMenu() {

		JMenuBar Mbar = new JMenuBar();
		
		JMenu menu1 = new JMenu("File");//creating the object in menubar
		menu1.setMnemonic(KeyEvent.VK_F); //giving shortcut to cfile
		JMenu menu2 = new JMenu("Help");//creating the object in menubar
		menu2.setMnemonic(KeyEvent.VK_H);  //giving shortcut to help
		
	
		Mbar.add(menu1); //ading menu on menubar
		Mbar.add(menu2);//adding the menu on menubar

		JMenuItem item1 = new JMenuItem("");//creating the object in menuitem		
		//creating the image icon and its size on menubar
		ImageIcon img = new ImageIcon(new ImageIcon("abuie.png"
				+ ""
				+ "").
				getImage().getScaledInstance(20,20,Image. //declaring size of image
						SCALE_DEFAULT));
		JMenuItem item2 = new JMenuItem("ABOUT",img);//passing ther images on menuitem
		item2.setMnemonic(KeyEvent.VK_A);  //giving shortcut to exit		
		
		//creating the image icon and defining its size
		ImageIcon img1 = new ImageIcon(new ImageIcon("hello.jpg").
				getImage().getScaledInstance(20,20,Image.
						SCALE_DEFAULT));//declaring size of image
		item1 = new JMenuItem("Exit",img1);//adding the images on menuitems
		item1.setMnemonic(KeyEvent.VK_E);  //giving shortcut to exit
		
		//JMenuItem FileButton = new JMenuItem("Filename/Directoryname ");//declaring the cfile button
		//FileButton.setMnemonic(KeyEvent.VK_L);
		
		//adding menu item
		menu1.add(item1); 
		menu2.add(item2);//adding item on menu 2
		
		//displaying the message on about
			item2.addActionListener(new ActionListener() {//adding the listener listener
				//it terminate the program to execute when about is clicked
			public void actionPerformed(ActionEvent event) {
				//dialogue boxes appears when about is clicked
                JOptionPane.showMessageDialog(null, 
                    "This program is used to find the hashing value"
                    + "" + "\n" 
                    + "This all code belongs to Mr. Basanta Timilsena" + "\n" +
                    "Copyright (c) 2019" + "\n" + 
                    "All Rights Reserved", 
                    "",
                    JOptionPane.PLAIN_MESSAGE);
            }
		});
		
		//exit button to exit  		
		item1.addActionListener(new ActionListener() {//adding the actionlistener
			public void actionPerformed(ActionEvent event){//program terminates to execute when exit is clicked
		          System.exit(0);//exit when exit is clicked
		      }
		});
		

		//Constructs a new JMenu with the supplied string as its text.
		JMenu upload = new JMenu("Upload");	
		//Creates a JMenuItem with the specified text.

		loader = new JMenuItem("Load");
		//adding the menubar
		Mbar.add(upload);
		upload.add(loader);
		//There is no way to set a project on a existing project unless it is coming from a workspace.
		menuAc mac = new menuAc();
		//adding action listener
		loader.addActionListener(mac);
		return Mbar;
		
	}
	Project4(){
		
		cbox1 = new JCheckBox("File");//Creates an initially unselected check box with text
		cbox2 = new JCheckBox("Directory");//Creates an initially unselected check box with text
		cbox3 = new JCheckBox("Meta Data");//Creates an initially unselected check box with text
		rrbutton1=new JRadioButton("Algorithm 1");//Creates an initially unselected radio button with text
		rrbutton2=new JRadioButton("Algorithm 2");//Creates an initially unselected radio button with text
		rrbutton3=new JRadioButton("Algorithm 3");//Creates an initially unselected radio button with text
		ButtonGroup bg = new ButtonGroup();//Creates a new ButtonGroup.

		ButtonGroup bg1 = new ButtonGroup();//Creates a new ButtonGroup.

		bg.add(cbox1);//adding combo box in button group
		bg.add(cbox2);//adding combo box in button group
		bg.add(cbox3);//adding combo box in button group
		bg1.add(rrbutton1);//adding radio button in button group
		bg1.add(rrbutton2);//adding radio button in button group
		bg1.add(rrbutton3);//adding radio button in button group
		add(rrbutton1);//adding radio button 
		add(rrbutton2);//adding radio button 
		add(rrbutton3);//adding radio button 
		add(cbox1);//adding combo box
		add(cbox2);//adding combo box
		add(cbox3);//adding combo box
		
		 
	        
	}
	
	
	
	
	//The listener interface for receiving action events.
	//The class that is interested in processing an action eventimplements this interface,
	//and the object created with thatclass is registered with a component, 
	//using the component's addActionListener method. When the action eventoccurs, that object's actionPerformed method isinvoked.
	public class menuAc implements ActionListener{

		@Override
		//To invoke an ActionEvent on a Button using the keyboard, use the Space bar. 

		public void actionPerformed(ActionEvent event) {
			//The object on which the Event initially occurred.

			if(event.getSource() == loader){
				//Constructs a JFileChooser pointing to the user'sdefault directory. 
				
				JFileChooser chooser = new JFileChooser();
				//Convenience call that determines if directories are selectable basedon the current file selection mode.

				chooser.isDirectorySelectionEnabled();
               //Instruction to display both files and directories. 

				chooser.setFileSelectionMode(JFileChooser.FILES_AND_DIRECTORIES);
				
				//Pops up an "Open File" file chooser dialog. 

				int value = chooser.showOpenDialog(null);
				//JFileChooser provides a simple mechanism for the user tochoose a file.
				if (value == JFileChooser.APPROVE_OPTION) {
					//algorithm
					Project3 hashing = new Project3();
					Project5 hashing1=new Project5();
					Project6 hashing2=new Project6();
					//returns the selected files
					File cfile = chooser.getSelectedFile();
					
					
				//Returns the state of the button. True if thetoggle button is selected, false if it's not.
	
				if(rrbutton1.isSelected()) {	
					//Returns the state of the button. True if thetoggle button is selected, false if it's not.

					if(cbox1.isSelected()){
						//assigning the boolean value
					 exists = false;
					 //Tests whether the file denoted by this abstract pathname is a normalfile
						if(cfile.isFile()){
							
							//providing the file name to write the file name and hash value
							 String fileName = "details.txt";

						        // The String class represents character strings
						        String stmt = null;

						        try {
						            // FileReader reads text files in the default encoding.
						            FileReader fileReader = 
						                new FileReader(fileName);

						            // Always wrap FileReader in BufferedReader.
						            BufferedReader bufferedReader = 
						                new BufferedReader(fileReader);

						            while((stmt = bufferedReader.readLine()) != null) {
						            	//This method works as if by invoking the two-argument 
						                String[] spl = stmt.split("-");
						                
						                //Indicates that a method declaration is intended to override amethod declaration in a supertype
						               String compareVariable = hashing.produceFileHash(cfile).toUpperCase();
						                
						               //Compares this string to the specified object. 
						               //The result is true if and only if the argument is not null and 
						               //is a String object that represents the same sequence of characters as thisobject. 

						                if(spl[1].equals(compareVariable)){
						                	exists = true;
						                }
						            }   

						            // Always close files.
						            bufferedReader.close();         
						        }
						        
						        //Signals that an attempt to open the file denoted by a specified pathnamehas failed. 

						        catch(FileNotFoundException ex) {
						            System.out.println(
						                "Unable to open cfile '" + 
						                fileName + "'");                
						        }
						        catch(IOException ex) {
						            System.out.println(
						                "Error reading cfile '" 
						                + fileName + "'");                  
						            // Or we could just do this: 
						            // ex.printStackTrace();
						        }
						    
							if(!exists){
								//Whether or not a file is available or may be created depends upon theunderlying platform.
								FileWriter fileWriter = null;
								try {
									fileWriter = new FileWriter("details.txt",true);
								} catch (IOException exc) {
									// TODO Auto-generated catch block
									exc.printStackTrace();
								}
								//Creates a new PrintWriter, without automatic line flushing.

							    PrintWriter printWriter = new PrintWriter(fileWriter);
								String all = "";//declaring the string
								all += cfile.getName()+"\n";
								all += hashing.produceFileHash(cfile).toUpperCase();
								JOptionPane.showMessageDialog(null, all, "hashing Value",
										JOptionPane.INFORMATION_MESSAGE);
								printWriter.println(cfile.getName()+"-"+hashing.produceFileHash(cfile).toUpperCase()+"-"+1);
							    printWriter.close();
							}
							
							
							if(exists){
								JOptionPane.showMessageDialog(null, "hashing Value already exists", "hashing",
										JOptionPane.INFORMATION_MESSAGE);
							}
						}else{
							JOptionPane.showMessageDialog(null, "Please select a file", 
				                    "",
				                    JOptionPane.PLAIN_MESSAGE);
						}
					}
					
					
					
					
					
					
					if(cbox2.isSelected()){
						 exists = false;
							if(cfile.isDirectory()){
								
								 String fileName = "details.txt";

							        // This will reference one stmt at a time
							        String stmt = null;

							        try {
							            // FileReader reads text files in the default encoding.
							            FileReader fileReader = 
							                new FileReader(fileName);

							            // Always wrap FileReader in BufferedReader.
							            BufferedReader bufferedReader = 
							                new BufferedReader(fileReader);

							            while((stmt = bufferedReader.readLine()) != null) {
							                String[] spl = stmt.split("-");
							                
							                
							               String compareVariable = hashing.produceDirHash(cfile).toUpperCase();
							                
							                if(spl[1].equals(compareVariable)){
							                	exists = true;
							                }
							            }   

							            bufferedReader.close();         
							        }
							        catch(FileNotFoundException ex) {
							            System.out.println(
							                "Unable to open cfile '" + 
							                fileName + "'");                
							        }
							        catch(IOException ex) {
							            System.out.println(
							                "Error reading cfile '" 
							                + fileName + "'");                  
							            // Or we could just do this: 
							            // ex.printStackTrace();
							        }
							    
								if(!exists){
									FileWriter fileWriter = null;
									try {
										fileWriter = new FileWriter("details.txt",true);
									} catch (IOException exc) {
										// TODO Auto-generated catch block
										exc.printStackTrace();
									}
								    PrintWriter printWriter = new PrintWriter(fileWriter);
								    String all = "";
									for(File fil1 : cfile.listFiles()){
										all += fil1.getName()+",";
									}
									all += "\n";
									all += hashing.produceDirHash(cfile).toUpperCase();
									JOptionPane.showMessageDialog(null, all, "hashing Value",
											JOptionPane.INFORMATION_MESSAGE);
									printWriter.println(cfile.getName()+"-"+hashing.produceDirHash(cfile).toUpperCase()+"-"+1);
								    printWriter.close();
								}
								
								
								if(exists){
									JOptionPane.showMessageDialog(null, "hashing Value already exists", "hashing",
											JOptionPane.INFORMATION_MESSAGE);
								}
							}else{
								JOptionPane.showMessageDialog(null, "Please select a directory", 
					                    "",
					                    JOptionPane.PLAIN_MESSAGE);							}
						}
	
					if(cbox3.isSelected()){
						 exists = false;
							if(cfile.isDirectory()){
								
								 String fileName = "details.txt";

							        // This will reference one stmt at a time
							        String stmt = null;

							        try {
							            // FileReader reads text files in the default encoding.
							            FileReader fileReader = 
							                new FileReader(fileName);

							            // Always wrap FileReader in BufferedReader.
							            BufferedReader bufferedReader = 
							                new BufferedReader(fileReader);

							            while((stmt = bufferedReader.readLine()) != null) {
							            	//System.out.println(stmt);
							                String[] spl = stmt.split("-");
							                
							//System.out.println(spl[1]);
							                
							               String compareVariable = hashing.produceDirMetaHash(cfile).toUpperCase();
							               //System.out.println(compareVariable);
							                
							                if(spl[1].equals(compareVariable)){
							                	exists = true;
							                	System.out.println("lol");
							                }
							            }   

							            // Always close files.
							            bufferedReader.close();         
							        }
							        catch(FileNotFoundException ex) {
							            System.out.println(
							                "Unable to open cfile '" + 
							                fileName + "'");                
							        }
							        catch(IOException ex) {
							            System.out.println(
							                "Error reading cfile '" 
							                + fileName + "'");                  
							            // Or we could just do this: 
							            // ex.printStackTrace();
							        }
							    
								if(!exists){
									FileWriter fileWriter = null;
									try {
										fileWriter = new FileWriter("details.txt",true);
									} catch (IOException exc) {
										// TODO Auto-generated catch block
										exc.printStackTrace();
									}
								    PrintWriter printWriter = new PrintWriter(fileWriter);
									String all = "";
									for(File fil1 : cfile.listFiles()){
										all += fil1.getName()+",";
									}
									all += "\n";
									all += hashing.produceDirMetaHash(cfile).toUpperCase();
									JOptionPane.showMessageDialog(null, all, "hashing Value",
											JOptionPane.INFORMATION_MESSAGE);
									printWriter.println(cfile.getName()+"-"+hashing.produceDirMetaHash(cfile).toUpperCase()+"-"+1);
								    printWriter.close();
								}
								
								
								if(exists){
									JOptionPane.showMessageDialog(null, "hashing Value already exists", "hashing",
											JOptionPane.INFORMATION_MESSAGE);
								}
							}else{
								JOptionPane.showMessageDialog(null, "Please select a directory", 
					                    "",
					                    JOptionPane.PLAIN_MESSAGE);							}
						}
	
					}
				
				//
				if(rrbutton2.isSelected()) {	
					if(cbox1.isSelected()){
					 exists = false;
						if(cfile.isFile()){
							
							 String fileName = "details.txt";

						        // This will reference one stmt at a time
						        String stmt = null;

						        try {
						            // FileReader reads text files in the default encoding.
						            FileReader fileReader = 
						                new FileReader(fileName);

						            // Always wrap FileReader in BufferedReader.
						            BufferedReader bufferedReader = 
						                new BufferedReader(fileReader);

						            while((stmt = bufferedReader.readLine()) != null) {
						            	//System.out.println(stmt);
						                String[] spl = stmt.split("-");
						                
						//System.out.println(spl[1]);
						                
						               String compareVariable = hashing1.produceFileHash(cfile).toUpperCase();
						              // System.out.println(compareVariable);
						                
						                if(spl[1].equals(compareVariable)){
						                	exists = true;
						                	System.out.println("lol");
						                }
						            }   

						            // Always close files.
						            bufferedReader.close();         
						        }
						        catch(FileNotFoundException ex) {
						            System.out.println(
						                "Unable to open cfile '" + 
						                fileName + "'");                
						        }
						        catch(IOException ex) {
						            System.out.println(
						                "Error reading cfile '" 
						                + fileName + "'");                  
						            // Or we could just do this: 
						            // ex.printStackTrace();
						        }
						    
							if(!exists){
								FileWriter fileWriter = null;
								try {
									fileWriter = new FileWriter("details.txt",true);
								} catch (IOException exc) {
									// TODO Auto-generated catch block
									exc.printStackTrace();
								}
							    PrintWriter printWriter = new PrintWriter(fileWriter);
								String all = "";
								all += cfile.getName()+"\n";
								all += hashing.produceFileHash(cfile).toUpperCase();
								JOptionPane.showMessageDialog(null, all, "hashing Value",
										JOptionPane.INFORMATION_MESSAGE);
								printWriter.println(cfile.getName()+"-"+hashing1.produceFileHash(cfile).toUpperCase()+"-"+2);
							    printWriter.close();
							}
							
							
							if(exists){
								JOptionPane.showMessageDialog(null, "hashing Value already exists", "hashing",
										JOptionPane.INFORMATION_MESSAGE);
							}
						}else{
							JOptionPane.showMessageDialog(null, "Please select a file", 
				                    "",
				                    JOptionPane.PLAIN_MESSAGE);						}
					}
					
					
					
					
					
					
					if(cbox2.isSelected()){
						 exists = false;
							if(cfile.isDirectory()){
								
								 String fileName = "details.txt";

							        // This will reference one stmt at a time
							        String stmt = null;

							        try {
							            // FileReader reads text files in the default encoding.
							            FileReader fileReader = 
							                new FileReader(fileName);

							            // Always wrap FileReader in BufferedReader.
							            BufferedReader bufferedReader = 
							                new BufferedReader(fileReader);

							            while((stmt = bufferedReader.readLine()) != null) {
							            	//System.out.println(stmt);
							                String[] spl = stmt.split("-");
							                
							//System.out.println(spl[1]);
							                
							               String compareVariable = hashing1.produceDirHash(cfile).toUpperCase();
							               //System.out.println(compareVariable);
							                
							                if(spl[1].equals(compareVariable)){
							                	exists = true;
							                	//System.out.println("lol");
							                }
							            }   

							            // Always close files.
							            bufferedReader.close();         
							        }
							        catch(FileNotFoundException ex) {
							            System.out.println(
							                "Unable to open cfile '" + 
							                fileName + "'");                
							        }
							        catch(IOException ex) {
							            System.out.println(
							                "Error reading cfile '" 
							                + fileName + "'");                  
							            // Or we could just do this: 
							            // ex.printStackTrace();
							        }
							    
								if(!exists){
									FileWriter fileWriter = null;
									try {
										fileWriter = new FileWriter("details.txt",true);
									} catch (IOException exc) {
										// TODO Auto-generated catch block
										exc.printStackTrace();
									}
								    PrintWriter printWriter = new PrintWriter(fileWriter);
								    String all = "";
									for(File fil1 : cfile.listFiles()){
										all += fil1.getName()+",";
									}
									all += "\n";
									all += hashing.produceDirHash(cfile).toUpperCase();
									JOptionPane.showMessageDialog(null, all, "hashing Value",
											JOptionPane.INFORMATION_MESSAGE);
									printWriter.println(cfile.getName()+"-"+hashing1.produceDirHash(cfile).toUpperCase()+"-"+2);
								    printWriter.close();
								}
								
								
								if(exists){
									JOptionPane.showMessageDialog(null, "hashing Value already exists", "hashing",
											JOptionPane.INFORMATION_MESSAGE);
								}
							}else{
								JOptionPane.showMessageDialog(null, "Please select a directory", 
					                    "",
					                    JOptionPane.PLAIN_MESSAGE);							}
						}
	
					if(cbox3.isSelected()){
						 exists = false;
							if(cfile.isDirectory()){
								
								 String fileName = "details.txt";

							        // This will reference one stmt at a time
							        String stmt = null;

							        try {
							            // FileReader reads text files in the default encoding.
							            FileReader fileReader = 
							                new FileReader(fileName);

							            // Always wrap FileReader in BufferedReader.
							            BufferedReader bufferedReader = 
							                new BufferedReader(fileReader);

							            while((stmt = bufferedReader.readLine()) != null) {
							            	//System.out.println(stmt);
							                String[] spl = stmt.split("-");
							                
							//System.out.println(spl[1]);
							                
							               String compareVariable = hashing1.produceDirMetaHash(cfile).toUpperCase();
							               //System.out.println(compareVariable);
							                
							                if(spl[1].equals(compareVariable)){
							                	exists = true;
							                	System.out.println("lol");
							                }
							            }   

							            // Always close files.
							            bufferedReader.close();         
							        }
							        catch(FileNotFoundException ex) {
							            System.out.println(
							                "Unable to open cfile '" + 
							                fileName + "'");                
							        }
							        catch(IOException ex) {
							            System.out.println(
							                "Error reading cfile '" 
							                + fileName + "'");                  
							            // Or we could just do this: 
							            // ex.printStackTrace();
							        }
							    
								if(!exists){
									FileWriter fileWriter = null;
									try {
										fileWriter = new FileWriter("details.txt",true);
									} catch (IOException exc) {
										// TODO Auto-generated catch block
										exc.printStackTrace();
									}
								    PrintWriter printWriter = new PrintWriter(fileWriter);
									String all = "";
									for(File fil1 : cfile.listFiles()){
										all += fil1.getName()+",";
									}
									all += "\n";
									all += hashing1.produceDirMetaHash(cfile).toUpperCase();
									JOptionPane.showMessageDialog(null, all, "hashing Value",
											JOptionPane.INFORMATION_MESSAGE);
									printWriter.println(cfile.getName()+"-"+hashing1.produceDirMetaHash(cfile).toUpperCase()+"-"+2);
								    printWriter.close();
								}
								
								
								if(exists){
									JOptionPane.showMessageDialog(null, "hashing Value already exists", "hashing",
											JOptionPane.INFORMATION_MESSAGE);
								}
							}else{
								JOptionPane.showMessageDialog(null, "Please select a directory", 
					                    "",
					                    JOptionPane.PLAIN_MESSAGE);							}
						}
	
					}
				if(rrbutton3.isSelected()) {	
					if(cbox1.isSelected()){
					 exists = false;
						if(cfile.isFile()){
							
							 String fileName = "details.txt";

						        // This will reference one stmt at a time
						        String stmt = null;

						        try {
						            // FileReader reads text files in the default encoding.
						            FileReader fileReader = 
						                new FileReader(fileName);

						            // Always wrap FileReader in BufferedReader.
						            BufferedReader bufferedReader = 
						                new BufferedReader(fileReader);

						            while((stmt = bufferedReader.readLine()) != null) {
						            	//System.out.println(stmt);
						                String[] spl = stmt.split("-");
						                
						//System.out.println(spl[1]);
						                
						               String compareVariable = hashing2.produceFileHash(cfile).toUpperCase();
						              // System.out.println(compareVariable);
						                
						                if(spl[1].equals(compareVariable)){
						                	exists = true;
						                	//System.out.println("lol");
						                }
						            }   

						            // Always close files.
						            bufferedReader.close();         
						        }
						        catch(FileNotFoundException ex) {
						            System.out.println(
						                "Unable to open cfile '" + 
						                fileName + "'");                
						        }
						        catch(IOException ex) {
						            System.out.println(
						                "Error reading cfile '" 
						                + fileName + "'");                  
						            // Or we could just do this: 
						            // ex.printStackTrace();
						        }
						    
							if(!exists){
								FileWriter fileWriter = null;
								try {
									fileWriter = new FileWriter("details.txt",true);
								} catch (IOException exc) {
									// TODO Auto-generated catch block
									exc.printStackTrace();
								}
							    PrintWriter printWriter = new PrintWriter(fileWriter);
								String all = "";
								all += cfile.getName()+"\n";
								all += hashing2.produceFileHash(cfile).toUpperCase();
								JOptionPane.showMessageDialog(null, all, "hashing Value",
										JOptionPane.INFORMATION_MESSAGE);
								printWriter.println(cfile.getName()+"-"+hashing2.produceFileHash(cfile).toUpperCase()+"-"+3);
							    printWriter.close();
							}
							
							
							if(exists){
								JOptionPane.showMessageDialog(null, "hashing Value already exists", "hashing",
										JOptionPane.INFORMATION_MESSAGE);
							}
						}else{
							JOptionPane.showMessageDialog(null, "Please select a file", 
				                    "",
				                    JOptionPane.PLAIN_MESSAGE);						}
					}
					
					
					
					
					
					
					if(cbox2.isSelected()){
						 exists = false;
							if(cfile.isDirectory()){
								
								 String fileName = "details.txt";

							        // This will reference one stmt at a time
							        String stmt = null;

							        try {
							            // FileReader reads text files in the default encoding.
							            FileReader fileReader = 
							                new FileReader(fileName);

							            // Always wrap FileReader in BufferedReader.
							            BufferedReader bufferedReader = 
							                new BufferedReader(fileReader);

							            while((stmt = bufferedReader.readLine()) != null) {
							            	//System.out.println(stmt);
							                String[] spl = stmt.split("-");
							                
							//System.out.println(spl[1]);
							                
							               String compareVariable = hashing2.produceDirHash(cfile).toUpperCase();
							               //System.out.println(compareVariable);
							                
							                if(spl[1].equals(compareVariable)){
							                	exists = true;
							                	//System.out.println("lol");
							                }
							            }   

							            // Always close files.
							            bufferedReader.close();         
							        }
							        catch(FileNotFoundException ex) {
							            System.out.println(
							                "Unable to open cfile '" + 
							                fileName + "'");                
							        }
							        catch(IOException ex) {
							            System.out.println(
							                "Error reading cfile '" 
							                + fileName + "'");                  
							            // Or we could just do this: 
							            // ex.printStackTrace();
							        }
							    
								if(!exists){
									FileWriter fileWriter = null;
									try {
										fileWriter = new FileWriter("details.txt",true);
									} catch (IOException exc) {
										// TODO Auto-generated catch block
										exc.printStackTrace();
									}
								    PrintWriter printWriter = new PrintWriter(fileWriter);
								    String all = "";
									for(File fil1 : cfile.listFiles()){
										all += fil1.getName()+",";
									}
									all += "\n";
									all += hashing2.produceDirHash(cfile).toUpperCase();
									JOptionPane.showMessageDialog(null, all, "hashing Value",
											JOptionPane.INFORMATION_MESSAGE);
									printWriter.println(cfile.getName()+"-"+hashing2.produceDirHash(cfile).toUpperCase()+"-"+3);
								    printWriter.close();
								}
								
								
								if(exists){
									JOptionPane.showMessageDialog(null, "hashing Value already exists", "hashing",
											JOptionPane.INFORMATION_MESSAGE);
								}
							}else{
								JOptionPane.showMessageDialog(null, "Please select a directory", 
					                    "",
					                    JOptionPane.PLAIN_MESSAGE);							}
						}
	
					if(cbox3.isSelected()){
						 exists = false;
							if(cfile.isDirectory()){
								
								 String fileName = "details.txt";

							        // This will reference one stmt at a time
							        String stmt = null;

							        try {
							            // FileReader reads text files in the default encoding.
							            FileReader fileReader = 
							                new FileReader(fileName);

							            // Always wrap FileReader in BufferedReader.
							            BufferedReader bufferedReader = 
							                new BufferedReader(fileReader);

							            while((stmt = bufferedReader.readLine()) != null) {
							            	//System.out.println(stmt);
							                String[] spl = stmt.split("-");
							                
							//System.out.println(spl[1]);
							                
							               String compareVariable = hashing2.produceDirMetaHash(cfile).toUpperCase();
							               //System.out.println(compareVariable);
							                
							                if(spl[1].equals(compareVariable)){
							                	exists = true;
							                	//System.out.println("lol");
							                }
							            }   

							            // Always close files.
							            bufferedReader.close();         
							        }
							        catch(FileNotFoundException ex) {
							            System.out.println(
							                "Unable to open cfile '" + 
							                fileName + "'");                
							        }
							        catch(IOException ex) {
							            System.out.println(
							                "Error reading cfile '" 
							                + fileName + "'");                  
							            // Or we could just do this: 
							            // ex.printStackTrace();
							        }
							    
								if(!exists){
									FileWriter fileWriter = null;
									try {
										fileWriter = new FileWriter("details.txt",true);
									} catch (IOException exc) {
										// TODO Auto-generated catch block
										exc.printStackTrace();
									}
								    PrintWriter printWriter = new PrintWriter(fileWriter);
									String all = "";
									for(File fil1 : cfile.listFiles()){
										all += fil1.getName()+",";
									}
									all += "\n";
									all += hashing2.produceDirMetaHash(cfile).toUpperCase();
									JOptionPane.showMessageDialog(null, all, "hashing Value",
											JOptionPane.INFORMATION_MESSAGE);
									printWriter.println(cfile.getName()+"-"+hashing2.produceDirMetaHash(cfile).toUpperCase()+"-"+3);
								    printWriter.close();
								}
								
								
								if(exists){
									JOptionPane.showMessageDialog(null, "hashing Value already exists", "hashing",
											JOptionPane.INFORMATION_MESSAGE);
								}
							}else{
								JOptionPane.showMessageDialog(null, "Please select a directory", 
					                    "",
					                    JOptionPane.PLAIN_MESSAGE);							}
						}
	
					}
				
				
				}
				
				
			}
			
		}
		
	}
}

