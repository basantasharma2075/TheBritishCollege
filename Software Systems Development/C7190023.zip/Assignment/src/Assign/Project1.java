package Assign;

import java.awt.FlowLayout;

import javax.swing.JFrame;


public class Project1 {
	public static void main(String[] args) {
		JFrame frame = new JFrame("Converter");

		// object created of the mainpanel class
		Project4 panel = new Project4();

		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		// setting the menubar to the panel object of class mainpanel
		frame.setJMenuBar(panel.setupMenu());

		frame.setLayout(new FlowLayout ());
		// adding panel to the frame
		frame.getContentPane().add(panel);
		// frame.setLayout(new BoxLayou Bt(cpanel, BoxLayout.X_AXIS));

		// frame size and width declaration
		frame.setSize(600, 400);
		// this line of code will help the frame always appears on the center of
		// the
		// screen
		frame.setLocationRelativeTo(null);
		frame.setVisible(true);
	}

}
