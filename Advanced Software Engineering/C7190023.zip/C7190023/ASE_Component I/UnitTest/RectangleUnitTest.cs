﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using ASE_Component_I;
namespace UnitTest
{
    [TestClass]
    public class RectangleUnitTest
    {
        [TestMethod]
        public void TestMethod2()
        {
            var form = new Rectangle();
            var a = form.val1;
            var b = form.val2;
            var c = form.val3;
            var d = form.val4;
            form.saved_values(1, 2, 1, 2);
            bool test = false;
            if (a != form.val1 && b != form.val2 && c != form.val3 && d != form.val4)
                test = true;
            Assert.IsTrue(test);
        }
    }
}
