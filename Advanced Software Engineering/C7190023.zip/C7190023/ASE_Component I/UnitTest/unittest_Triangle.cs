﻿using ASE_Component_I;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace UnitTest
{
    [TestClass]
    public class UnitTestTriangle
    {
        [TestMethod]
        public void TestMethoda()
        {
            var formA = new Triangle();
            var a = formA.val1;
            var b = formA.val2;
            var c = formA.bas;
            var d = formA.perp;

            formA.saved_values(5, 3, 1, 4);
            bool test = false;
            if (a != formA.val1 && b != formA.val2 && c != formA.bas && d != formA.perp)
                test = true;
            Assert.IsTrue(test);
        }
    }
}