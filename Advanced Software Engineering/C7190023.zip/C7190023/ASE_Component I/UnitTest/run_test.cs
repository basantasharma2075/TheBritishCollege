﻿using ASE_Component_I;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;

namespace UnitTest
{
    [TestClass]
    public class run_test
    {
        [TestMethod]
        public void Execute()
        {
            var from = new Form1();
            object a = new object();
            EventArgs b = new EventArgs();
            from.button2_Click(a, b);
            Assert.IsTrue(from.execute);
        }
    }
}
