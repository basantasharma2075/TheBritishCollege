﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ASE_Component_I
{
    /// <summary>
    /// intializing the value to draw circle
    /// </summary>
    public class Circle: Important
    {
        public int val1, val2, val3;
        public void saved_values(int vala, int valb, int valc) {
            val2 = vala;
            val3 = valb;
            val1 = valc;
        }
        /// <summary>
        /// drawing circle
        /// </summary>
        /// <param name="g"></param>
        public override void Draw_shape(Graphics g)
        {
            Pen VarB = new Pen(Color.Black,3);
            g.DrawEllipse(VarB, val2, val3, val1, val1);
        }
    }
}
