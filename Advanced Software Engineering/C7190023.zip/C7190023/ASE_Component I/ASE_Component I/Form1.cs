﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Drawing.Drawing2D;

using System.IO;

namespace ASE_Component_I
{
    /// <summary>
    /// intializing the origin
    /// </summary>
    public partial class Form1 : Form
    {
        public bool execute = false;
        public int cordinateX = 0;
        public int cordinateY = 0;
        public Form1()
        {
            InitializeComponent();
        }
        /// <summary>
        /// providing the parameter in x and y axis
        /// </summary>
        /// <param name="x"></param>
        /// <param name="y"></param>
        public void pentomove(int x, int y)
        {
            Pen pen_move = new Pen(Color.Black, 3);
            cordinateX = x;
            cordinateY = y;




        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            ///
        }
        /// <summary>
        /// declaring variable to draw the line
        /// </summary>
        /// <param name="varA"></param>
        /// <param name="varB"></param>
        public void pentodraw(int varA, int varB)
        {
            execute = false;
            Pen PenVarA = new Pen(Color.Black, 3);
            Graphics graA = panel1.CreateGraphics();
            graA.DrawLine(PenVarA, cordinateX, cordinateY, varA, varB);
            cordinateX = varA;
            cordinateY = varB;
        }
        /// <summary>
        /// action listner in button to pass the parameter
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        public void button2_Click(object sender, EventArgs e)
        {
            //var multicontrolA = textBox2.Text;

           // var controlA = textBox1.Text;
            //string[] TestingA = controlA.Split(' ');

            var controlA = textBox1.Text;
            String[] TestingAB = controlA.Split('\n');
            for (int i = 0; i < TestingAB.Length - 1; i++)
            {
                String bas = TestingAB[i].Trim();
                string[] TestingA = bas.Split('(');


                try
                {
                    if (string.Compare(TestingA[0].ToLower(), "moveto") == 0)
                    {
                        textBox2.Text = "";
                        String[] Val1 = TestingA[1].Split(',');
                        String[] Val2 = Val1[1].Split(')');
                        String point1 = Val1[0];
                        String point2 = Val2[0];
                        pentomove(int.Parse(point1), int.Parse(point2));

                    }
                    else if (TestingA[0].Equals("\n")) { }

                    else if (string.Compare(TestingA[0].ToLower(), "drawto") == 0)
                    {
                        textBox2.Text = "";
                        String[] Val1 = TestingA[1].Split(',');
                        String[] Val2 = Val1[1].Split(')');
                        String point1 = Val1[0];
                        String point2 = Val2[0];
                        pentodraw(int.Parse(point1), int.Parse(point2));
                    }

                    else if (string.Compare(TestingA[0].ToLower(), "clear") == 0)
                    {
                        clear();
                    }

                    else if (string.Compare(TestingA[0].ToLower(), "clear") == 0)
                    {
                        reset();
                    }

                    else if (string.Compare(TestingA[0].ToLower(), "rectangle") == 0)
                    {
                        String[] Val1 = TestingA[1].Split(',');
                        String[] Val2 = Val1[1].Split(')');
                        String point1 = Val1[0];
                        String point2 = Val2[0];
                          rectangle_draw(cordinateX, cordinateY, int.Parse(point1), int.Parse(point2));
                        textBox2.Text = "";
                    }

                    else if (string.Compare(TestingA[0].ToLower(), "triangle") == 0)
                    {
                        String[] Val1 = TestingA[1].Split(',');
                        String[] Val2 = Val1[1].Split(',');
                        String point1 = Val1[0];
                        String point2 = Val2[0];
                        triangle_draw(cordinateX, cordinateY, int.Parse(point1), int.Parse(point2));
                    }

                    else if (string.Compare(TestingA[0].ToLower(), "circle") == 0)
                    {
                        String[] Val2 = TestingA[1].Split(')');
                        String point2 = Val2[0];
                        circle_draw(cordinateX, cordinateY, int.Parse(point2));
                        textBox2.Text = "";
                    }






                    else
                    {
                        
                        textBox2.Text = ""; 
                        textBox2.Text += "Syntax Error in Line: " +(i+1);
                        panel1.Refresh();
                        break;
                        
                    }
                }
                catch (Exception)
                {
                   
                    textBox2.Text = "";
                   
                    textBox2.Text += "Wrong Parameter Pass in Line"+ (i+1);
                    panel1.Refresh();
                    break;

                }

            }

            execute = true;


        }
        /// <summary>
        /// clear in clear button
        /// </summary>
        private void clear()
        {
            panel1.Refresh();
        }
        /// <summary>
        /// reset the coordinate to origin
        /// </summary>
        private void reset()
        {
            cordinateX = 0;
            cordinateY = 0;
        }
        /// <summary>
        /// giving the length of rectangle
        /// </summary>
        /// <param name="pointa"></param>
        /// <param name="pointb"></param>
        /// <param name="pointc"></param>
        /// <param name="pointd"></param>
        public void rectangle_draw(int pointa, int  pointb,int pointc, int pointd )
        {
            Rectangle rect1 = new Rectangle();
            rect1.saved_values(pointa, pointb, pointc, pointd);
            Graphics graA = panel1.CreateGraphics();
            rect1.Draw_shape(graA);
        }
        /// <summary>
        /// passing the value of triangle
        /// </summary>
        /// <param name="x"></param>
        /// <param name="y"></param>
        /// <param name="z"></param>
        /// <param name="w"></param>
        public void triangle_draw(int x, int y, int z, int w)
        {
            Triangle tri = new Triangle();
            tri.saved_values(x, y, z, w);
            Graphics g = panel1.CreateGraphics();
            tri.Draw_shape(g);
        }

        /// <summary>
        /// giving the point of circle
        /// </summary>
        /// <param name="pointa"></param>
        /// <param name="pointb"></param>
        /// <param name="pointc"></param>
        public void circle_draw(int pointa, int pointb, int pointc)
        {
            Circle circ1 = new Circle();
            circ1.saved_values(pointa, pointb, pointc);
            Graphics graA = panel1.CreateGraphics();
            circ1.Draw_shape(graA);
        }
        /// <summary>
        /// reseting reset button
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void button1_Click(object sender, EventArgs e)
        {
            reset();
            
        }
        /// <summary>
        /// clear button
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void button3_Click(object sender, EventArgs e)
        {
            clear();
            textBox2.Text = "";
          //  textBox1.Text = "";
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {


        }
        /// <summary>
        /// load button to load the file
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void loadToolStripMenuItem_Click(object sender, EventArgs e)
        {

            OpenFileDialog loadFileDialog = new OpenFileDialog();
            loadFileDialog.Filter = "Text File (.txt)|*.txt";
            loadFileDialog.Title = "Open File...";

            if (loadFileDialog.ShowDialog() == DialogResult.OK)
            {
                System.IO.StreamReader streamReader = new System.IO.StreamReader(loadFileDialog.FileName);
                textBox1.Text = streamReader.ReadToEnd();
                streamReader.Close();
            }

        }
        /// <summary>
        /// save button while pressing the save
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void saveToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (String.IsNullOrEmpty(textBox1.Text))
            {
                textBox2.Text += "Textbox is empty";
            }
            else { 
            SaveFileDialog saveFileDialog = new SaveFileDialog();
            saveFileDialog.Filter = "Text File (.txt)| *.txt";
            saveFileDialog.Title = "Save File...";
            if (saveFileDialog.ShowDialog() == DialogResult.OK)
            {
                StreamWriter fWriter = new StreamWriter(saveFileDialog.FileName);
                fWriter.Write(textBox1.Text);
                fWriter.Close();
            }
            textBox2.Text = "";
            textBox2.Text += "Command Save";

        }

            //panel2.Text ="hello";
        }

        private void button1_Click_1(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
    