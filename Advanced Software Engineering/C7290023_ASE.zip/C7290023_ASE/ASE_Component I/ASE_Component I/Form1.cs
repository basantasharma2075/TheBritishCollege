﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Drawing.Drawing2D;
using System.IO;

namespace ASE_Component_I
{
    /// <summary>
    /// Form1 contains all the components like buttons
    /// panel text field and all
    /// </summary>
    
    public partial class Form1 : Form
    {
    /// <summary>
    /// declaring the xcoordinate o
    /// </summary>

    public int XCoordinate = 0;
        /// <summary>
        /// declaring the y coordinate 0
        /// </summary>
        public int YCoordinate = 0;
        string[] Command_Line = {"drawto", "moveto", "rectangle", "circle","triangle", "rotate" };
        /// <summary>
        /// declaring the boolean value d_shape false
        /// </summary>
        public bool d_shape = false;
        /// <summary>
        /// declaring the boolean value b_load and bool_method false
        /// </summary>
        public bool b_load = false;
        bool bool_method = false;
        /// <summary>
        /// declaring the boolean value save false
        /// </summary>
        public bool save = false;
        /// <summary>
        /// declaring the boolean value execute false
        /// </summary>
        public bool execute = false;
        /// <summary>
        /// declaring the boolean value clear_bool false
        /// </summary>
        public bool clear_bool = false;

        List<String[]> method_valA = new List<String[]>();
        List<String> method_body = new List<string>();
        List<String> cmnd_method = new List<String>();
        List<int> m_size = new List<int>();
        List<String> m_split = new List<String>();

        /// <summary>
        /// declaring the boolean value b_reset false
        /// </summary>
        public bool b_reset = false;
        /// <summary>
        /// declaring the line counter 1
        /// </summary>
        public int l_Counter = 1;
        /// <summary>
        /// declaring the int LN_Counter for loop
        /// </summary>
        public int LN_Counter = 0;
        /// <summary>
        /// declaring the line counter in if statement
        /// </summary>
        public int count_if = 0;

        public float rotation = 0;
        /// <summary>
        /// creating the data dictionary
        /// </summary>
        public Dictionary<string, string> data_dictionary = new Dictionary<string, string>();
        /// <summary>
        /// creating the form1 method
        /// </summary>
        public Form1()
        {
            InitializeComponent();
        }
        
        /// <summary>
        /// this methods takes two parameters x and y which when given values
        /// acts as another origin which is taken refrence for any drawing of
        /// Command_Line formerly the values of x and y are (0,0) 
        /// </summary>
        /// <param name="x">x co ordinate of origin</param>
        /// <param name="y">y co ordinate of origin</param>
        public void pentomove(int x, int y)
        {
            Pen pen_move = new Pen(Color.Black, 2);
            XCoordinate = x;
            YCoordinate = y;




        }



        /// <summary>
        /// new variable multi command is created in a array. 
        /// input is taken in this variable and compared to other command
        /// </summary>
        /// <param name="multi_comand"></param>
        public void m_variable(String[] multi_comand)
        {
            if (string.Compare(multi_comand[0].ToLower(), "moveto") == 0)
            {
                String[] para1 = multi_comand[1].Split(',');
                if (para1.Length != 2)
                    throw new Exception("MoveTo command takes 2 parameter");
                else if (!para1[para1.Length - 1].Contains(')'))
                    throw new Exception(" " + "Paranthesis is Missing");
                else
                {
                    String[] para2 = para1[1].Split(')');
                    String point1 = para1[0];
                    String point2 = para2[0];
                    pentomove(int.Parse(point1), int.Parse(point2));
                    if (para1.Length > 1 && para1.Length < 3)
                        pentomove(int.Parse(point1), int.Parse(point2));
                    else
                        throw new ArgumentException("MoveTo command takes 2 parameter");

                }
            }
            else if (multi_comand[0].Equals("\n"))
            {

            }
            //executes if "drawto" command is triggered
            else if (string.Compare(multi_comand[0].ToLower(), "drawto") == 0)
            {

                String[] para1 = multi_comand[1].Split(',');
                if (para1.Length != 2)
                    throw new Exception("DrawTo command takes 2 parameter");
                else if (!para1[para1.Length - 1].Contains(')'))
                    throw new Exception(" " + "Paranthesis is Missing");
                else
                {
                    String[] para2 = para1[1].Split(')');
                    String point1 = para1[0];
                    String point2 = para2[0];
                    pentodraw(int.Parse(point1), int.Parse(point2));
                    if (para1.Length == 2)
                        pentodraw(int.Parse(point1), int.Parse(point2));

                    else
                    {
                        throw new ArgumentException("DrawTo command takes 2 parameter");
                    }
                }

            }
            
            else if (string.Compare(multi_comand[0].ToLower(), "clear") == 0)
            {
                clear();
            }
            else if (string.Compare(multi_comand[0].ToLower(), "reset") == 0)
            {
                reset();
            }
            else if (string.Compare(multi_comand[0].ToLower(), "rectangle") == 0)
            {
                String[] para1 = multi_comand[1].Split(',');
                if (para1.Length != 2)
                    throw new Exception("Rectangle command takes 2 parameter");
                else if (!para1[para1.Length - 1].Contains(')'))
                    throw new Exception(" " + "Paranthesis is Missing");
                else
                {
                    String[] para2 = para1[1].Split(')');
                    String point1 = para1[0];
                    String point2 = para2[0];
                    if (para1.Length > 1 && para1.Length < 3)
                        rectangle_draw(XCoordinate, YCoordinate, int.Parse(point1), int.Parse(point2));
                    else
                        throw new ArgumentException("Rectangle command takes 2 parameter");
                }
            }

            


            else if (string.Compare(multi_comand[0].ToLower(), "circle") == 0)
            {
                String tester_V = multi_comand[1];
                String[] para2 = multi_comand[1].Split(')');
                if (!tester_V.Contains(')'))
                    throw new Exception(" " + "Paranthesis is Missing");
                else
                {
                    String point2 = para2[0];
                    if (point2 != null || point2 != "" || point2 != " ")
                        circle_draw(XCoordinate, YCoordinate, int.Parse(point2));
                    else
                        throw new ArgumentException("Circle command takes 1 Parameter");

                }
            }
            else if (string.Compare(multi_comand[0].ToLower(), "triangle") == 0)
            {
                String[] para1 = multi_comand[1].Split(',');
                if (para1.Length != 2)
                    throw new Exception("Triangle command takes 2 parameter");
                else if (!para1[para1.Length - 1].Contains(')'))
                    throw new Exception(" " + "Paranthesis is Missing");
                else
                {
                    String[] para2 = para1[1].Split(')');
                    String point1 = para1[0];
                    String point2 = para2[0];
                    if (para1.Length > 1 && para1.Length < 3)
                        triangle_draw(XCoordinate, YCoordinate, int.Parse(point1), int.Parse(point2));
                    else
                        throw new ArgumentException("Triangle command takes 2 parameter");
                }
            }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }
        /// <summary>
        /// method to d_shape a line from (XCoordinate,YCoordinate) to 
        /// given points (a,b)
        /// </summary>
        /// <param name="a"></param>
        /// <param name="b"></param>
        public void pentodraw(int a, int b)
        {
            Pen pen_varA = new Pen(Color.Black, 2);
            Graphics gp = panel1.CreateGraphics();
            gp.DrawLine(pen_varA, XCoordinate, YCoordinate, a, b);
            XCoordinate = a;
            YCoordinate = b;
        }
        /// <summary>
        /// takes every line of the command and checks for the shape names 
        /// if it is in array Command_Line.
        /// </summary>
        /// <param name="line">line of command stored after each loop </param>
        /// <returns></returns>
        public bool checkCommand(string line)
        {
            for (int a = 0; a < Command_Line.Length; a++)
            {
                if (line.Contains(Command_Line[a]))
                {
                   

                    return true;
                }
            }
            String[] temp = line.Split('(');
            if (cmnd_method.Contains(temp[0])) {
                return true;
            }
            return false;
        }

        /// <summary>
        ///methods which becomes active as soon as Execute button is pressed. 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        public void button2_Click(object sender, EventArgs e)
        {
            data_dictionary.Clear();
            bool_method = false;

            l_Counter = 1;
            panel1.Refresh();
            textBox1.Clear();

            execute = false;
            var multi_command = textBox2.Text;
            string[] multi_syntax = multi_command.Split(new char[] { '\n'}, StringSplitOptions.RemoveEmptyEntries);

            foreach(string LBr_split in multi_syntax) 
            {


                    bool result = caseRun(LBr_split);
                if (!result)
                {
                    panel1.Invalidate();
                    break;
                }


                l_Counter++;

            }

               

        }

        /// <summary>
        /// line case is created
        /// </summary>
        /// <param name="line"></param>
        /// <returns></returns>
            public bool caseRun(string line)
            {
                line = line.ToLower().Trim();



            if (count_if != 0)
            {
                count_if--;
                return true;

            }

            if (LN_Counter != 0)
            {
                
                LN_Counter--;

                return true;
            }

            else if (checkCommand(line))
            {

                string[] multi_comand = line.Split(new char[] { '(' }, StringSplitOptions.RemoveEmptyEntries);
                if (!runShape(multi_comand, line))
                    return false;


            }
            
            else if(checkVariableDec(line)){
                
                try
                {
                    string[] variableDeclration = line.Split(new char[] { '=' }, 2, StringSplitOptions.RemoveEmptyEntries);
                    string key = variableDeclration[0];
                    string value = variableDeclration[1];
                   

                    data_dictionary.Add(key,value);

                 

                }
               
                catch (Exception e)
                {
                    textBox1.Text = " Invalid variable in Line: " + l_Counter + " "+ e.Message;
                    return false;
                }


            }else if (checkIfElse(line))
            {
                bool endIfCheck = false;
                bool conditionStatus = false;
                string conditionOperator = "";
                try
                {

                    string[] IfCondtionParameter = getIfParameter(line);

                    foreach(string c in IfCondtionParameter){
                        Console.WriteLine(c);
                    }


                    if (!data_dictionary.ContainsKey(IfCondtionParameter[0].Trim().ToLower()))
                    {
                        textBox1.Text = " Variable error in line: "+l_Counter;
                        return false;
                    }


                    string condValueString = IfCondtionParameter[1];
                    int condValue = Int32.Parse(condValueString);




                   string v = IfCondtionParameter[0].Trim().ToLower();
                    string varValuestring = data_dictionary[v];
                    int varvalue = Int32.Parse(varValuestring);

                    if (line.Contains("="))
                    {
                        conditionOperator = "=";

                    }else if (line.Contains("<"))
                    {
                        conditionOperator = "<";
                    }
                    else if (line.Contains(">"))
                    {
                        conditionOperator = ">";
                    }


                   


                    var multi_command = textBox2.Text;
                    string[] multi_syntax = multi_command.Split(new char[] { '\n' },StringSplitOptions.RemoveEmptyEntries);

                    foreach (string LBr_split in multi_syntax)
                    {

                        if(LBr_split.ToLower().Trim() == "endif")
                        {
                            endIfCheck = true;
                            break;
                        }
                       
                    }
                    if (!endIfCheck)
                    {
                        textBox1.Text = "Please close the if Endif command in line: "+l_Counter;
                        return false;
                    }


                    if(conditionOperator == "=")
                    {
                        if(varvalue == condValue)
                        {
                            conditionStatus = true;
                        }
                    }else if( conditionOperator == "<"){


                        if(varvalue < condValue)
                        {
                            conditionStatus = true;
                        }
                    }else if (conditionOperator == ">")
                    {
                        if (varvalue > condValue)
                        {
                            conditionStatus = true;
                        }
                    }
                    for (int i = l_Counter; i < multi_syntax.Length; i++)
                    {
                        if(multi_syntax[i] == "endif")
                        {
                            break;
                        }
                        else
                        {
                            count_if++;
                        }
                    }

                        if (conditionStatus)
                    {
                        count_if = 0;
                    }

                    }
                catch (Exception e)
                {
                    textBox1.Text = " Invalid if else statement is not valid in line: " + l_Counter + "\n" + e.Message;
                    return false;
                }






            }else if(line=="endif"){
                return true;
            }
            else if(checkVariableOperation(line)){



                //check variable operation
                string[] variable = line.Split(new char[] { '+','-' }, 2, StringSplitOptions.RemoveEmptyEntries);
                string variableOperator = "";

                if (line.Contains("+"))
                {
                    variableOperator = "+";

                }else
                {
                    variableOperator = "-";
                }
                string realKey = variable[0];
                int realValue=Int32.Parse(variable[1]);
                int dictValue = Int32.Parse(data_dictionary[realKey]);
                if (!data_dictionary.ContainsKey(realKey))
                {
                    textBox1.Text = " please enter the variable in line: " + l_Counter;
                    return false;
                }


                if(variableOperator == "+")
                {
                    data_dictionary[realKey] = (dictValue + realValue).ToString();
                }
                else
                {
                    data_dictionary[realKey] = (dictValue - realValue).ToString();
                }
         
            }
            else if (checkLoop(line))
            {

                bool endloopCheck = false;
                try
                {
                    string[] loop = line.Split(new string[] { "for" }, 2, StringSplitOptions.RemoveEmptyEntries);

                    string loopCondition = loop[1].Trim();

                    string[] loopVariable = loopCondition.Split(new string[] { "<=",">=" }, 2, StringSplitOptions.RemoveEmptyEntries);

                    foreach(string LBr_split in loopVariable)
                    {
                        Console.WriteLine(LBr_split);
                    }

                    foreach(KeyValuePair<string,string> k in data_dictionary)
                    {
                        Console.WriteLine(k.Key +"=" +k.Value);
                    }
                    int loopValue = Int32.Parse(loopVariable[1].Trim()) ;
                    string loopKey = loopVariable[0].Trim();
                    Console.WriteLine(loopKey);
                    if (!data_dictionary.ContainsKey(loopKey))
                    {
                        textBox1.Text = " Variable doesn't exist in line: " + l_Counter;
                        return false;
                    }


                    var multi_command = textBox2.Text;
                    string[] multi_syntax = multi_command.Split(new char[] { '\n' }, StringSplitOptions.RemoveEmptyEntries);

                    foreach (string LBr_split in multi_syntax)
                    {

                        if (LBr_split.ToLower().Trim() == "endloop")
                        {
                            endloopCheck = true;
                            break;
                        }

                    }
                    if (!endloopCheck)
                    {
                        textBox1.Text = "closed the loop for count command of line: " + l_Counter;
                        return false;
                    }


                    //endloop check

                   
                    
                    int counterLine = 0;
                    int lineNumberCount1 = 0;

                    List<string> loopList = new List<string>();
                    for (int i = l_Counter; i < multi_syntax.Length; i++)
                    {
                       
                        if (multi_syntax[i] == "endloop")
                        {

                            break;
                        }
                        else
                        {
                            lineNumberCount1++;
                            loopList.Add(multi_syntax[i]);
                        }
                    }



                    int dictValue = 0;
                    string loopOperator = "";
                    counterLine = l_Counter;

                    if (line.Contains("<="))
                    {
                        loopOperator = "<=";
                    }
                    else
                    {
                        loopOperator = ">=";
                    }


                    if (loopOperator == "<=")
                    {
                        while (dictValue <= loopValue)
                        {
                            l_Counter = counterLine;
                            foreach (string list in loopList)
                            {
                                l_Counter++;
                                if (!caseRun(list))
                                    return false;
                            }
                            dictValue = Int32.Parse(data_dictionary[loopKey]);
                        }
                    }
                    else
                    {

                        while (dictValue >= loopValue)
                        {
                            l_Counter = counterLine;
                            foreach (string list in loopList)
                            {
                                l_Counter++;
                                if (!caseRun(list))
                                    return false;
                            }
                            dictValue = Int32.Parse(data_dictionary[loopKey]);
                        }
                    }

                    l_Counter = counterLine;
                    LN_Counter = lineNumberCount1;
                }
                catch (Exception e)
                {
                    textBox1.Text = " Invaild Loop command in line: " + l_Counter + " + \n " + e.Message;
                    return false;
                }

            }
            else if(line=="endloop"){
                return true;
            }else if (checkMethod(line))
            {
                bool endMethodCheck = false;
                var multi_command = textBox2.Text;
                string[] multi_syntax = multi_command.Split(new char[] { '\n' }, StringSplitOptions.RemoveEmptyEntries);
                for (int i = l_Counter; i < multi_syntax.Length; i++)
                {

                    if (multi_syntax[i] == "endmethod")
                    {
                        endMethodCheck = true;
                        break;
                    }
                   
                }

                if (!endMethodCheck)
                {
                    textBox1.Text = " please close the method first of line: " + l_Counter;
                    return false;
                }



                    String[] SM_Command = multi_command.Split('\n');
                    String VarA = "";
                    String VarB = "";

                    for (int i = 0; i < SM_Command.Length; i++)
                    {
                        if (SM_Command[i].ToLower().Contains("method"))
                        {
                            String[] s_VarC = SM_Command[i].Split(' ');
                            String[] B_VarD = s_VarC[s_VarC.Length - 1].Split('(');
                            if (B_VarD[B_VarD.Length - 1].Contains(','))
                            {
                                String[] SC_var = B_VarD[B_VarD.Length - 1].Split(',');
                                m_size.Add(SC_var.Length);
                                for (int x = 0; x < SC_var.Length; x++)
                                {
                                    if (x == SC_var.Length - 1)
                                    {
                                        String[] split_BVar1 = SC_var[x].Split(')');
                                        VarB = VarB + split_BVar1[0] + "\n";
                                    }
                                    else
                                    {
                                        VarB = VarB + SC_var[x] + "\n";
                                    }
                                }
                                m_split.Add(VarB);
                            }
                            else
                            {
                                String[] SC_var = B_VarD[B_VarD.Length - 1].Split(')');
                                if (SC_var[0] == " " || SC_var[0] == null || SC_var[0] == "")
                                {
                                    m_size.Add(0);
                                    m_split.Add(" ");
                                }
                                else
                                {
                                    m_size.Add(1);
                                    VarB = VarB + SC_var[0] + "\n";
                                    m_split.Add(VarB);
                                }
                            }
                        cmnd_method.Add(B_VarD[0].ToLower());
                        }
                        else
                        {
                            VarA = VarA + SM_Command[i] + "\n";
                        }
                    }
                    
                textBox1.Text = "Method Saved";
                method_body.Add(VarA);
                    method_valA.Add(VarA.Split('\n'));
                bool_method = true;


            }else if (line == "endmethod")
            {

            }
            else
            {
                textBox1.Text = " Command doesn't Exist in line: " + l_Counter;
                return false;
            }


                return true;
            }
        /// <summary>
        ///  checking the first syntax of command
        /// </summary>
        /// <param name="b_line"></param>
        /// <returns></returns>
        public bool checkLoop(string b_line)
        {
            if (b_line.StartsWith("loop"))
                return true;

            return false;

        }
        /// <summary>
        /// checking the if condition
        /// </summary>
        /// <param name="if_val1"></param>
        /// <returns></returns>
        public string[] getIfParameter(string if_val1)
        {

            int start = if_val1.IndexOf("(") + 1;
            int end = if_val1.IndexOf(")", start);

            string result = if_val1.Substring(start, end - start);
            string[] parameterList = result.Split(new Char[] { '>','<','=' },2,StringSplitOptions.RemoveEmptyEntries);

            return parameterList;


        }
        /// <summary>
        /// checking the increment or decrement
        /// </summary>
        /// <param name="chk_cmnd"></param>
        /// <returns></returns>
        public bool checkVariableOperation(string chk_cmnd)
        {
            if (chk_cmnd.Contains("+") || chk_cmnd.Contains("-"))
            {
                return true;
            }
            return false;
        }
        /// <summary>
        /// parameter checking
        /// </summary>
        /// <param name="g_par"></param>
        /// <returns></returns>
        public string[] getParameter(string g_par)
        {

            int start = g_par.IndexOf("(") + 1;
            int end = g_par.IndexOf(")", start);

            string result = g_par.Substring(start, end - start);
            string[] parameterList = result.Split(new Char[] { ','}, 2, StringSplitOptions.RemoveEmptyEntries);

            return parameterList;


        }
        /// <summary>
        /// checking the wither first value is start from if or not
        /// </summary>
        /// <param name="check_varA"></param>
        /// <returns></returns>
        public bool checkIfElse(string check_varA)
        {
            if (check_varA.StartsWith("if"))
            {
                return true;
            }
            return false;
        }
        /// <summary>
        /// checking the first value of method and returning the true or false
        /// </summary>
        /// <param name="chk_cmndA"></param>
        /// <returns></returns>
        public bool checkMethod(string chk_cmndA)
        {
            if (chk_cmndA.StartsWith("method"))
            {
                return true;
            }
            return false;
        }
        /// <summary>
        /// multi line command checking the first value to run all command
        /// if, method and loop
        /// </summary>
        /// <param name="chk_varDes"></param>
        /// <returns></returns>
        public bool checkVariableDec(string chk_varDes)
        {
            if (chk_varDes.Contains("=") && !chk_varDes.StartsWith("if") && !chk_varDes.StartsWith("method") && !chk_varDes.StartsWith("loop"))
            {
                return true;
            }
            return false;
        }

        /// <summary>
        /// adding the parameter after the braces
        /// </summary>
        /// <param name="w_VarA"></param>
        /// <returns></returns>
        public bool withVariable(string[] w_VarA)
        {
            string VarZ = "(" + w_VarA[1];
            string[] parameters = getParameter(VarZ);

            foreach (string param in parameters)
            {
                Console.WriteLine(param);
            }
                bool variableCheck = false;

            foreach(string param in parameters)
            {
                bool isNumeric = int.TryParse(param, out _);

                if (!isNumeric)
                {
                    variableCheck = true;
                    if (!data_dictionary.ContainsKey(param))
                    {
                        return false;
                    }
                    else
                    {
                        VarZ = VarZ.Replace(param, data_dictionary[param]);
                    }
                }
            }



            if (!variableCheck)
                return false;

            VarZ = w_VarA[0] + VarZ;
            Console.WriteLine(VarZ);
            caseRun(VarZ);
          

            return true;
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="multi_comand"></param>
        /// <param name="line"></param>
        /// <returns></returns>
        public bool runShape(string[] multi_comand, String line)
        {
           
            if (!bool_method)
            {
                if (withVariable(multi_comand))
                {
                    return true;

                }
            }


            try
            {
                
                if (!bool_method)
                {
                    if (cmnd_method.Contains(multi_comand[0].ToLower()))
                    {
                        String h_line = line;
                       
                        String br_split = h_line.Split('(')[0].Trim();
                        if (cmnd_method.Contains(br_split.Trim()))
                        {
                            int count = 0;
                            String[] LBr_split = h_line.Split('(');
                            List<int> Cr_List = new List<int>();
                            if (LBr_split[LBr_split.Length - 1].Contains(','))
                            {
                                String[] Co_Split = LBr_split[LBr_split.Length - 1].Split(',');
                                count = Co_Split.Length;
                                for (int q = 0; q < Co_Split.Length; q++)
                                {
                                    if (q != Co_Split.Length - 1)
                                    {
                                        Cr_List.Add(int.Parse(Co_Split[q]));
                                    }
                                    else
                                    {
                                        String[] ClBr_Split = Co_Split[q].Split(')');
                                       
                                       // textBox1.Text = " variable declaration failed in line: " + l_Counter;

                                        if (ClBr_Split[0] != "" && ClBr_Split[0] != " " && ClBr_Split[0] == null)
                                            Cr_List.Add(int.Parse(ClBr_Split[0]));
                                        else
                                            Cr_List.Add(int.Parse(ClBr_Split[0]));
                                    }
                                }
                               
                                for (int k = 0; k < Cr_List.Count(); k++) {
                                   
                                }
                            }
                            else
                            {
                                String[] SC_var = LBr_split[LBr_split.Length - 1].Split(')');
                                if (SC_var[0] == " " || SC_var[0] == null || SC_var[0] == "")
                                {
                                    count = 0;
                                }
                                else
                                {
                                    Cr_List.Add(int.Parse(SC_var[0]));
                                    count = 1;
                                }
                            }
                            if (count == m_size[cmnd_method.IndexOf(br_split.Trim())])
                            {
                                String[] zz = method_body[cmnd_method.IndexOf(br_split.Trim())].Split('\n');
                                String za = m_split[cmnd_method.IndexOf(br_split.Trim())];

                                for (int ss = 0; ss < zz.Length; ss++)
                                {
                                    if (!string.IsNullOrEmpty(zz[ss]))
                                    {
                                        if (za == " ")
                                        {
                                            
                                            caseRun(zz[ss]);
                                        }
                                        else
                                        {
                                            String[] io = za.Split('\n');
                                            for (int ui = 0; ui < io.Length; ui++)
                                            {
                                                if (!string.IsNullOrEmpty(io[ui]))
                                                {
                                                    if (zz[ss].Contains(io[ui].Trim()))
                                                    {
                                                        
                                                        zz[ss] = zz[ss].Replace(io[ui].Trim(), Cr_List[ui].ToString());
                                                       
                                                    }
                                                }
                                                else {
                                                    caseRun(zz[ss]);
                                                }
                                            }
                                            caseRun(zz[ss]);
                                        }
                                    }
                                }
                            }
                            else
                            {
                                
                                textBox1.Text = "wrong Parameter pass it doesn't Match ";
                            }
                        }
                        else
                        {
                            
                            textBox1.Text = "error !!! anything not found";
                        }
                    }
                    //executes if "moveto" command is triggered
                    else if (string.Compare(multi_comand[0].ToLower(), "moveto") == 0)
                    {
                        String[] para1 = multi_comand[1].Split(',');
                        if (para1.Length != 2)
                            throw new Exception("MoveTo command takes 2 parameter");
                        else if (!para1[para1.Length - 1].Contains(')'))
                            throw new Exception(" " + "Paranthesis is Missing");
                        else
                        {
                            String[] para2 = para1[1].Split(')');
                            String point1 = para1[0];
                            String point2 = para2[0];
                            pentomove(int.Parse(point1), int.Parse(point2));
                            if (para1.Length > 1 && para1.Length < 3)
                                pentomove(int.Parse(point1), int.Parse(point2));
                            else
                                throw new ArgumentException("MoveTo command takes 2 parameter");

                        }
                    }
                    else if (multi_comand[0].Equals("\n"))
                    {

                    }
                    //executes if "drawto" command is triggered
                    else if (string.Compare(multi_comand[0].ToLower(), "drawto") == 0)
                    {

                        String[] para1 = multi_comand[1].Split(',');
                        if (para1.Length != 2)
                            throw new Exception("DrawTo command takes 2 parameter");
                        else if (!para1[para1.Length - 1].Contains(')'))
                            throw new Exception(" " + "Paranthesis is Missing");
                        else
                        {
                            String[] para2 = para1[1].Split(')');
                            String point1 = para1[0];
                            String point2 = para2[0];
                            pentodraw(int.Parse(point1), int.Parse(point2));
                            if (para1.Length == 2)
                                pentodraw(int.Parse(point1), int.Parse(point2));

                            else
                            {
                                throw new ArgumentException("DrawTo command takes 2 parameter");
                            }
                        }

                    }
                    
                    else if (string.Compare(multi_comand[0].ToLower(), "clear") == 0)
                    {
                        clear();
                    }
                   
                    else if (string.Compare(multi_comand[0].ToLower(), "reset") == 0)
                    {
                        reset();
                    }
                    
                    else if (string.Compare(multi_comand[0].ToLower(), "rectangle") == 0)
                    {
                        String[] para1 = multi_comand[1].Split(',');
                        if (para1.Length != 2)
                            throw new Exception("Rectangle command takes 2 parameter");
                        else if (!para1[para1.Length - 1].Contains(')'))
                            throw new Exception(" " + "Paranthesis is Missing");
                        else
                        {
                            String[] para2 = para1[1].Split(')');
                            String point1 = para1[0];
                            String point2 = para2[0];
                            if (para1.Length > 1 && para1.Length < 3)
                                rectangle_draw(XCoordinate, YCoordinate, int.Parse(point1), int.Parse(point2));
                            else
                                throw new ArgumentException("Rectangle command takes 2 parameter");
                        }
                    }

                    else if (string.Compare(multi_comand[0].ToLower(), "rotate") == 0)
                    {
                        String test = multi_comand[1];
                        String[] parameter2 = multi_comand[1].Split(')');
                        if (!test.Contains(')'))
                            throw new Exception(" " + "Missing Paranthesis!!");
                        else
                        {
                            String p2 = parameter2[0];
                            if (p2 != null || p2 != "" || p2 != " ")
                                rotate(float.Parse(p2));
                            else
                                throw new ArgumentException("Rotate Takes Only 1 Parameter");

                        }
                    }

                    else if (string.Compare(multi_comand[0].ToLower(), "circle") == 0)
                    {
                        String tester_V = multi_comand[1];
                        String[] para2 = multi_comand[1].Split(')');
                        if (!tester_V.Contains(')'))
                            throw new Exception(" " + "Paranthesis is Missing");
                        else
                        {
                            String point2 = para2[0];
                            if (point2 != null || point2 != "" || point2 != " ")
                                circle_draw(XCoordinate, YCoordinate, int.Parse(point2));
                            else
                                throw new ArgumentException("Circle command takes 1 parameter");

                        }
                    }
                    else if (string.Compare(multi_comand[0].ToLower(), "triangle") == 0)
                    {
                        String[] para1 = multi_comand[1].Split(',');
                        if (para1.Length != 2)
                            throw new Exception("Triangle command takes 2 parameter");
                        else if (!para1[para1.Length - 1].Contains(')'))
                            throw new Exception(" " + "Paranthesis is Missing");
                        else
                        {
                            String[] para2 = para1[1].Split(')');
                            String point1 = para1[0];
                            String point2 = para2[0];
                            if (para1.Length > 1 && para1.Length < 3)
                                triangle_draw(XCoordinate, YCoordinate, int.Parse(point1), int.Parse(point2));
                            else
                                throw new ArgumentException("Triangle command takes 2 parameter");
                        }
                    }
                    return true;
                }
                else
                {
                    return true;
                }
            }
            catch (ArgumentException ecp)
            {
                textBox1.Text = "Error found!!! in Line:" + (l_Counter ) + " " + ecp.Message;
                panel1.Refresh();
                return false;
            }

            catch (Exception ee)
            {
                textBox1.Text = "parameter error in line: " + l_Counter + ee.Message;
                panel1.Refresh();
                return false;
            }
           
        }
        /// <summary>
        /// this method is trigerred when clear button is clicked.
        /// this clears text box as well as panel where drawing is 
        /// drawn
        /// </summary>
        public void clear()
        {
            clear_bool = false;
            panel1.Refresh();
            textBox1.Clear();
            clear_bool = true;
        }
        /// <summary>
        /// this button reset the point of reference or origin to (0,0)
        /// </summary>
        public void reset()
        {
            b_reset = false;
            XCoordinate = 0;
            YCoordinate = 0;
            b_reset = true;
        }
        /// <summary>
        /// the a and b is assigned as point of origin which is given (0,0)
        /// at first which can replaced using moveto command. the c and d is 
        /// given for the width and height of the rectangle. this method is to d_shape 
        /// rectangle.
        /// </summary>
        /// <param name="a">x co ordinate of origin</param>
        /// <param name="b">y co ordinate of origin</param>
        /// <param name="c">width of the rectangle</param>
        /// <param name="d">height of the rectangle</param>
        public void rectangle_draw(int a, int b,int c, int d )
        {
            d_shape = false;
            Rectangle Rect1 = new Rectangle();
            Rect1.saved_values(a, b, c, d);
            Graphics gp = panel1.CreateGraphics();
            gp.RotateTransform(rotation);
            Rect1.Draw_shape(gp);
            d_shape = true;
        }
        /// <summary>
        /// the a and b is assigned as point of origin which is given (0,0)
        /// at first which can replaced using moveto command. the c is given to
        /// radius of circle.this is to d_shape circle
        /// </summary>
        /// <param name="a">x co ordinate of origin</param>
        /// <param name="b">y co ordinate of origin</param>
        /// <param name="c">radius of circle</param>
        public void circle_draw(int a, int b, int c)
        {
            d_shape = false;
            Circle circ1 = new Circle();
            circ1.saved_values(a, b, c);
            Graphics gp = panel1.CreateGraphics();
            gp.RotateTransform(rotation);
            circ1.Draw_shape(gp);
            d_shape = true;
        }

        public void rotate(float a)
        {
            d_shape = false;
            rotation = a;
            d_shape = true;
        }

        /// <summary>
        /// the a and b is assigned as point of origin which is given (0,0)
        /// at first which can replaced using moveto command. the c and d is 
        /// given for the base and hypotenuse of the triangle. this method is to d_shape 
        /// triangle.
        /// </summary>
        /// <param name="a"></param>
        /// <param name="b"></param>
        /// <param name="c"></param>
        /// <param name="d"></param>
        public void triangle_draw(int a, int b, int c, int d)
        {
            d_shape = false;
            Triangle Tri1 = new Triangle();
            Tri1.saved_values(a, b, c, d);
            Graphics gp = panel1.CreateGraphics();
            gp.RotateTransform(rotation);
            Tri1.Draw_shape(gp);
            d_shape = true;
        }

        /// <summary>
        /// triggered when reset button is clicked
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        public void button1_Click(object sender, EventArgs e)
        {
            reset();
        }
        /// <summary>
        /// triggered when clear button is clicked
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void button3_Click(object sender, EventArgs e)
        {
            clear();
            
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }
        /// <summary>
        /// method to b_load a file which is created and saved before.
        /// </summary>
        /// <param name="sender">where event came from</param>
        /// <param name="e">what is in the event</param>
        public void loadToolStripMenuItem_Click(object sender, EventArgs e)
        {
            b_load= false;
            OpenFileDialog loadFileDialog = new OpenFileDialog();
            loadFileDialog.Filter = "Text File (.txt)|*.txt";       
            loadFileDialog.Title = "Open File...";

            if (loadFileDialog.ShowDialog() == DialogResult.OK)
            {
                System.IO.StreamReader streamReader = new System.IO.StreamReader(loadFileDialog.FileName);
                textBox2.Text = streamReader.ReadToEnd();
                streamReader.Close();
            }
            b_load = true;
        }
        /// <summary>
        /// to save the file written in coding text box to the given drive with
        /// the given name
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        public void saveToolStripMenuItem_Click(object sender, EventArgs e)
        {
            save = true;
            SaveFileDialog saveFileDialog = new SaveFileDialog();
            saveFileDialog.Filter = "Text File (.txt)| *.txt";
            saveFileDialog.Title = "Save File...";
            if (saveFileDialog.ShowDialog() == DialogResult.OK)
            {
                StreamWriter fWriter = new StreamWriter(saveFileDialog.FileName);
                fWriter.Write(textBox2.Text);
                fWriter.Close();
                

            }
            save = true;
            textBox1.Text = "command saved";
        }
        /// <summary>
        /// trigerrred when exit button is clicked
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Close();
        }
        /// <summary>
        /// trigerrred when about button is clicked
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
       

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

       
    }
}
    