﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ASE_Component_I
{
    class Triangle:Shape
    {
        
        private int x, y, b_val1, p_val2;

        public void saved_values(int a, int b, int c, int d)
        {
            x = a;
            y = b;
            b_val1 = c;
            p_val2 = d;
            

        }
        public override void Draw_shape(Graphics Gp)
        {
            Pen pen_val = new Pen(Color.OrangeRed, 3);
            PointF A = new PointF(x, y);
            PointF B = new PointF(x+p_val2, y);
            PointF C = new PointF(B.X, B.Y+p_val2) ;
            PointF[] val1= { A, B, C };
            Gp.DrawPolygon (pen_val,val1);
        }


    }
}

