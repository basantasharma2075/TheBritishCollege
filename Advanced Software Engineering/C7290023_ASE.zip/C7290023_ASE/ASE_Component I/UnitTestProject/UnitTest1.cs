﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using ASE_Component;
namespace UnitTestProject
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestMethod1()
        {
            var form = new Form1();
            var a = form.cordinateX;
            var b = form.cordinateX;
            form.toMovePen(10, 10);
            bool ex = false;
            if (a != form.XaxisPosition && b != form.YaxisPosition)
                ex = true;
            Assert.IsTrue(ex);
        }
    }
}
