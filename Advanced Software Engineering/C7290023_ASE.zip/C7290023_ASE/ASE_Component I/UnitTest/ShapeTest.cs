﻿using System;
using ASE_Component_I;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace unittest
{
    [TestClass]
    public class ShapeTest
    {

        Form1 form;
        [TestInitialize]
        public void Initialize()
        {
            string[] Command_Line = { "drawto", "moveto", "rectangle", "circle", "triangle" };
            form = new Form1();

        }
        [TestMethod]
        public void checkCommandTest()
        {
            //Arrange

            string line = "circle(10)";
            //act

            bool result = form.checkCommand(line);
            //Assert

            Assert.IsTrue(result);
        }

        [TestMethod]
        public void runShape()
        {
            //Arrange

            string line = "circle(30)";
            string[] multi_command = { "circle", "30)" };
            //act

            bool result = form.runShape(multi_command, line);
            //Assert

            Assert.IsTrue(result);
        }


    }
}