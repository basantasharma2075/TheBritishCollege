﻿using System;
using ASE_Component_I;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace unittest
{
    [TestClass]
    public class UnitTest2
    {
        [TestMethod]
        public void getParameterTestMethod()
        {
            Form1 form = new Form1();
            //arrange
            string line = "rectangle(40,60)";
            string[] expectedArray = { "40", "60" };

            //act
            string[] actualArray = form.getParameter(line);

            //assert
            CollectionAssert.AreEqual(expectedArray, actualArray);


        }
    }
}
