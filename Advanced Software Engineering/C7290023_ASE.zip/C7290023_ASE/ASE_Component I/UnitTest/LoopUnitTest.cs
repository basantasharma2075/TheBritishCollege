﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace unittest
{
    [TestClass]
    public class LoopUnitTest
    {
        [TestMethod]
        public void TestMethod1()
        {
        }
    }
}
