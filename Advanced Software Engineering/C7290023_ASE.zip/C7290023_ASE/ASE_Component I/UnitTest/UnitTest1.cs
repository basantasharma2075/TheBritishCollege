﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using ASE_Component_I;
using System.Windows.Forms;
namespace unittest
{
    [TestClass]
    public class UnitTest1
    {

        Form1 form;
        [TestInitialize]
        public void Initialize()
        {
            string[] Command_Line = { "drawto", "moveto", "rectangle", "circle", "triangle" };
            form = new Form1();

        }
        [TestMethod]
        public void checkCommandTest()
        {
            //Arrange

            string line = "circle(10)";
            //act

            bool result = form.checkCommand(line);
            //Assert

            Assert.IsTrue(result);
        }

        
        [TestMethod]
        public void runShape()
        {
            //Arrange

            string line = "circle(10)";
            string[] multi_command = { "circle", "10)" };
            //act

            bool result = form.runShape(multi_command, line);
            //Assert

            Assert.IsTrue(result);
        }

    }
}
