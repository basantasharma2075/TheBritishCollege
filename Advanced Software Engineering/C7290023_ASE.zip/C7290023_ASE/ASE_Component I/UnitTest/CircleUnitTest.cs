﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using ASE_Component_I;
namespace UnitTest
{
    [TestClass]
    public class CircleUnitTest
    {
        [TestMethod]
        public void TestMethod1()
        {
            var form = new ASE_Component_I.Circle();
            var a = form.val1;
            var b = form.val2;
            var c = form.val3;
            form.saved_values(1, 2, 3);
            bool test = false;
            if (a != form.val1 && b != form.val2 && c != form.val3)
                test = true;
            Assert.IsTrue(test);
        }

        
        
    }
}
