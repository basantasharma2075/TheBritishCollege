﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using ASE_Component_I;
namespace UnitTest
{
    [TestClass]
    public class DrawToUnitTest
    {
        [TestMethod]
        public void draw()
        {
            var form = new Form1();
            var a = form.cordinateX;
            var b = form.cordinateY;
            form.pentodraw(10, 20);
            bool eql = false;
            if (a != form.cordinateX && b != form.cordinateY)
                eql = true;
            Assert.IsTrue(eql);


        }
    }
}
