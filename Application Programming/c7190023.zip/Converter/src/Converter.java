import javax.swing.JFrame;

public class Converter {
	 
    public static void main(String[] args) {
    	
    
        JFrame frame = new JFrame("Converter");//making the new objects in jframe
        
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        
        MainPanel panel = new MainPanel();//creating the new pannel

        CurrencyPanel panel2 = new CurrencyPanel();
     
        frame.setJMenuBar(panel.setupMenu());
        
        frame.getContentPane().add(panel2);
        
        frame.getContentPane().add(panel);
       
        frame.setSize(800,400);//setting the size of the frame
        panel2.setBounds(0,100,800,100);//setting the boundary
        
        frame.setVisible(true);//seting the frame visible
    }
}

