
public class Currency {

	private String currency_name;
	private double currency_amt;
	private String currency_symbol;
	
	Currency(String cn, String ca, String cs){
		currency_name = cn;
		try {
			currency_amt = Double.parseDouble(ca);
		}catch(NumberFormatException e){
		
		}
		currency_symbol = cs;
	}
	
	public String getName() {
		return currency_name;
	}
	public double getAmount() {
		return currency_amt;
	}
	public String getSymbol() {
		return currency_symbol;
	}
	
}
