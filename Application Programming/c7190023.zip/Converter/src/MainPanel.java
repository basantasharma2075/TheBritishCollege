import java.awt.Color;
import java.awt.Dimension;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.text.DecimalFormat;

import javax.swing.Action;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;


// Indicates that the named compiler warnings should be suppressed.
@SuppressWarnings({ "serial", "unused" })

public class MainPanel extends JPanel {


	private final static String[] list = { "Inches/Centimeter", "Miles/Kilometres", "Pounds/Kilograms",
			"Gallons/Litres", "Feet/Metres", "Celsius/Kelvin", "Acres/Hectare" };//combo box variable
	private JTextField textField;//declaring the textfield 
	private JLabel label, labelFinal;//declaring the result field
	private static JLabel vcount;//declaring the label to cout
	private JComboBox<String> combo;//declaring the combo box
	private JButton clearButton;//declaring the button
	private JButton convertButton;//declaring the conversion button
	private Action panel;
	public static int count = 0;//declaring the variable
	public static JCheckBox reverse;//declaring the checkbox
	private JLabel input;//declaring the result jlabel

	JMenuBar setupMenu() {

		JMenuBar menu = new JMenuBar();//creating the new object

		JMenu menu1 = new JMenu("File");//creating the object in menubar
		menu1.setMnemonic(KeyEvent.VK_F); //giving shortcut to file
		JMenu menu2 = new JMenu("Help");//creating the object in menubar
		menu2.setMnemonic(KeyEvent.VK_H);  //giving shortcut to help
		
		JMenu menu3 = new JMenu("Upload");//creating the object in menubar
		menu3.setMnemonic(KeyEvent.VK_U);  //giving shortcut to help

		menu.add(menu1); //ading menu on menubar
		menu.add(menu2);//adding the menu on menubar
		menu.add(menu3);//adding the menu on menubar

		JMenuItem item1 = new JMenuItem("");//creating the object in menuitem		
		//creating the image icon and its size on menubar
		ImageIcon img = new ImageIcon(new ImageIcon("abuie.png"
				+ ""
				+ "").
				getImage().getScaledInstance(20,20,Image. //declaring size of image
						SCALE_DEFAULT));
		JMenuItem item2 = new JMenuItem("ABOUT",img);//passing ther images on menuitem
		item2.setMnemonic(KeyEvent.VK_A);  //giving shortcut to exit		
		
		//creating the image icon and defining its size
		ImageIcon img1 = new ImageIcon(new ImageIcon("hello.jpg").
				getImage().getScaledInstance(20,20,Image.
						SCALE_DEFAULT));//declaring size of image
		item1 = new JMenuItem("Exit",img1);//adding the images on menuitems
		item1.setMnemonic(KeyEvent.VK_E);  //giving shortcut to exit
				
		//adding menu item
		menu1.add(item1); 
		menu3.add(CurrencyPanel.FileButton);//adding the button to the file menubar
		menu2.add(item2);//adding item on menu 2
		
		//displaying the message on about
			item2.addActionListener(new ActionListener() {//adding the listener listener
				//it terminate the program to execute when about is clicked
			public void actionPerformed(ActionEvent e) {
				//dialogue boxes appears when about is clicked
                JOptionPane.showMessageDialog(null, 
                    "This program is used to converted the "
                    + "mathemtical measurement" + "\n" 
                    + "This all code belongs to Mr. Basanta Timilsena" + "\n" +
                    "Copyright (c) 2018" + "\n" + 
                    "All Rights Reserved", 
                    "",
                    JOptionPane.PLAIN_MESSAGE);
            }
		});
		
		//exit button to exit  		
		item1.addActionListener(new ActionListener() {//adding the actionlistener
			public void actionPerformed(ActionEvent e){//program terminates to execute when exit is clicked
		          System.exit(0);//exit when exit is clicked
		      }
		});

		return menu;
	}



	MainPanel() {


		ActionListener listener = new ConvertListener();//declaring the new object of actionlistener


		combo = new JComboBox<String>(list);//creating the new combo box


		combo.addActionListener(listener); // add action listener when combo box is selected


		combo.setToolTipText("click to select the conversion");//seting the tooltips


		input = new JLabel("Enter a Integer:");//creating the new input label field


		convertButton = new JButton("Result");//creating the new convertbutton


		convertButton.addActionListener(listener); // converts the value 


		clearButton = new JButton("Clear");//adding the new clear button


		clearButton.addActionListener(listener);//adding action listener to the clearbutton


		clearButton.setToolTipText("click here to clear");//adding the tooltips 


		convertButton.setToolTipText("click here to convert");//tooltips for convert button


		label = new JLabel(" ");//adding the new jlabel

		textField = new JTextField(5);//adding the value field


		textField.addActionListener(listener);//actionlistener is added in textfield


		textField.setToolTipText("Enter a value.");//tooltips for actionlistener




		add(input);//adding the input field
		
		add(textField);//adding the value field


		add(combo);//adding the combo box





		add(convertButton);//adding the button


		add(clearButton);//adding the button


		add(label);//adding the label


		setPreferredSize(new Dimension(800, 80));//size of the panel


		setBackground(Color.green);//seting the panel color


		vcount = new JLabel("0");//creating the new object which value is zero

		labelFinal = new JLabel("Counter = ");//creating the new object jlabel counter


		reverse = new JCheckBox(" Reverse");//creating the new checkbox


		add(labelFinal);//adding the result label


		add(vcount);//adding the counting label


		add(reverse);//adding the checkbox

//adding the tooltips
		reverse.setToolTipText("check here to reverse the conversion");

		labelFinal.setToolTipText("counting the number of conversion");

		label.setToolTipText("final value");

	}
	
	public static void Counter(){

		count++;//increasing the conversion

		vcount.setText(Integer.toString(count));//changing rhe value to the string
	}

	private class ConvertListener implements ActionListener {


		@Override
		public void actionPerformed(ActionEvent event) {


			try {

				String userInput = textField.getText().trim();//getting the user input value
				
				//we can click the convert or a press enter to get result
				if (event.getSource() == textField || event.getSource() == convertButton) {

					if (userInput.length() == 0) {//checking wither it is empty or not

						JOptionPane.showMessageDialog(null, "please insert a value for conversion");//error handling dialog boxes
					}

					if (userInput.isEmpty() == false) {//setting the condition if the user input is not empty


						double Value = Double.parseDouble(userInput);//changing string to the double

						double Factors = 0;//declaring the factor as a zero

						double Offset = 0;//declaring the offset as zero

						switch (combo.getSelectedIndex()) {//combo box selection

						case 0://condition for inches to cm or vice-versa
							if (reverse.isSelected()) {
								Factors = 0.393701;
							} else {
								Factors = 2.54;
							}
							break;

						case 1://condition for miles to km or viceverse
							if (reverse.isSelected()) {
								Factors = 0.621371;
							} else {
								Factors = 1.60934;
							}
							break;

						case 2://condition for pound to kg or vice-versa
							if (reverse.isSelected()) {
								Factors = 2.20462;
							} else {
								Factors = 0.453592;
							}
							break;

						case 3://condition for gallon to litre or vice-versa
							if (reverse.isSelected()) {
								Factors = 0.264172;
							} else {
								Factors = 3.78541;
							}
							break;

						case 4://condition for feet to meter or vice-versa
							if (reverse.isSelected()) {
								Factors = 3.28084;
							} else {
								Factors = 0.3048;
							}
							break;

						case 5://condition for celcius to kelvin or vice-versa
							if (reverse.isSelected()) {
								Factors = -272.15;
							} else {
								Factors = 274.15;
							}
							break;

						case 6://condition for acres to hactres or vice-versa
							if (reverse.isSelected()) {
								Factors = 2.47105;
							} else {
								Factors = 0.404686;
							}
							break;
						}

						double result = Factors * Value + Offset;//calculating the final results

						DecimalFormat decimalValue = new DecimalFormat("0.00");//upto 2 decimalformat accepts

						String answer = decimalValue.format(result);//changing the format to the string
						label.setText(answer);
						Counter();
					}
				}

				if (event.getSource() == clearButton) {//if the clearbutton cis pressed or not

					count = 0;//declaring the count variable if clearbutton is pressed

					textField.setText(null);//clearing the textfield if clearbutton is pressed

					vcount.setText(" " + count);//clearing the no.of count to zeo if clearbutton is pressed

					label.setText(null);//clearing the label if clearbutton is pressed
					CurrencyPanel.ResultLabel.setText("");//currencypanel resul is empty
					CurrencyPanel.textField.setText(null);//textfield is empty
				}

			} catch (NumberFormatException e) {//checking wither it is no. or string

				JOptionPane.showMessageDialog(null, "please insert a number ot convert");

			}
		}

	}

}
