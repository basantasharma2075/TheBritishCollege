import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.text.DecimalFormat;
import java.util.LinkedList;
import java.util.Scanner;
import java.util.Vector;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.Action;
import javax.swing.DefaultComboBoxModel;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JFileChooser;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;


// Indicates that the named compiler warnings should be suppressed.
@SuppressWarnings({ "serial", "unused" })

public class CurrencyPanel extends JPanel {
	
	public static JLabel ResultLabel;  //declaring the variable as static to share the all instance in same class
	public static JTextField textField;//declaring the text field
	JButton convertButton;//declaring the convert button
	public static JMenuItem FileButton;//jbutton which can be acess from any instance of same class
	String[] combo = { "Null" };//declaring combo as a null
	JComboBox<String> comboBox;//declaring the combobox
	
	int noLine = 0;//declaring no of line as zero
	DefaultComboBoxModel<String> boxModel = new DefaultComboBoxModel<String>();//giving default combo box at the begining
	public Currency[] Money;//declaring the array
	int count = 0;//declaring the count variable
	int Line = 0;//declaring the variable to count
	LinkedList<String> linkList;//can have duplicate and null values.
	private Component input;
	CurrencyPanel(){
		ResultLabel = new JLabel();//Creates a JLabel instance with an empty string for the result.
		textField = new JTextField(5);//Creates a textfield to insert the variable
		convertButton = new JButton("Result");//convert button for the conversion
		comboBox = new JComboBox<String>(combo);//selection of the string from combo
		FileButton = new JMenuItem("Load");//declaring the file button
		FileButton.setMnemonic(KeyEvent.VK_L);
		
		//adding the tooltips 
		convertButton.setToolTipText("press here to convert");
		comboBox.setToolTipText("select the currency to convert");
		textField.setToolTipText("enter a number to convert");
		
		
		try {//Constructs an UnsupportedEncodingException 
			//class is used to read the text from a file
			BufferedReader fileReader = new BufferedReader(new InputStreamReader(new FileInputStream("currency.txt"), "UTF8"));
			String Word;//declaring the string
			try {//checking wither there is null value or not
				while((Word = fileReader.readLine())!=null) {// method read a line of text. 
	
					String[] splitArray = Word.split(",",-1);//passing delimeter
					try {//checking number format exceptions
						if(splitArray.length == 3) {//declaring the size of array
							double du = Double.parseDouble(splitArray[1]);//changing string to the double
							Line++;//increasing the line
							if(splitArray[0].isEmpty()) {//checking wither the value is empty or not
								JOptionPane.showMessageDialog(null,"currency-name is missing");//if the currency-name is not found
							}
							if(splitArray[1].isEmpty()) {//checking wither a currency is empty or not
								JOptionPane.showMessageDialog(null,"currency is missing");//if the currency is missing
							}
							if(splitArray[2].isEmpty()) {//checking wither it is empty or not
								JOptionPane.showMessageDialog(null,"currency-symbol is missing");//dialogue box if it is missing
							}
						}
					}catch(NumberFormatException e) {//checking wither it is number or not
						JOptionPane.showMessageDialog(null,"it is not in number format");//message dialogue boxes 
					}
				}
			} catch (IOException e) {//if there is null value

				JOptionPane.showMessageDialog(null,"please insert a integer to process!!!");//dialogue boxes if it is empty
			}
			try {
				fileReader.close();//Unless the constructor to BufferedReader throws an exception.
			} catch (IOException e) {//if there is null value

				JOptionPane.showMessageDialog(null,"file Not Found Error!!!");//dialogue boxes if there is some error
			}
		} catch (UnsupportedEncodingException e) {//Constructs an Unsupported Encoding Exception

			JOptionPane.showMessageDialog(null,"unsupported file encoding error.");//dialogue box appear if there is error
		} catch (FileNotFoundException e) {//if there is not currency.txt file it through the error

			JOptionPane.showMessageDialog(null,"file is missing!!!");//dialogue box appear
		}
		
	
		Money = new Currency[Line];//next line
	
		try {
			//class is used to read the text from a file
			BufferedReader fileReader = new BufferedReader(new InputStreamReader(new FileInputStream("currency.txt"), "UTF8"));
			String Word;//declaring the string
			int a = 0;//declaring the integer
			try {//if there is null value
				while((Word = fileReader.readLine())!=null) {//checking wither the word is empty or not
					String[] stmt = Word.split(",",-1);//splitting the array by delimeter
					if(stmt.length == 3) {//checking wither a line has sufficent data or not
						try {//checking wither given value is number or not
							try {
								double v = Double.parseDouble(stmt[1]);//changing to the double
								a++;//increasing the value of a
							}catch(NumberFormatException e) {//number format exception
								JOptionPane.showMessageDialog(null,"invalid number");//dialogue box throughing the exception errors
							}
							
						}catch(NumberFormatException e) {//number format exception
							JOptionPane.showMessageDialog(null,"insert a integer");//dialogue message box
						}
						
					}
					
				}
			} catch (IOException e) {//if there is null value
				JOptionPane.showMessageDialog(null,"file Not Found Error!!!");//dialogue boxes
			}
		} catch (UnsupportedEncodingException e) {//Constructs an Unsupported Encoding Exception

			JOptionPane.showMessageDialog(null,"unsupported file encoding error!!!");//dialogue box printing the error message
		} catch (FileNotFoundException e) {//file missing error

			JOptionPane.showMessageDialog(null,"file is missing!!!");//error message
		}
			try {
				//class is used to read the text from a file
			BufferedReader fileReader = new BufferedReader(new InputStreamReader(new FileInputStream("currency.txt"), "UTF8"));
			String Word;//declaring the variable
			try {//checking wither it is number or not
				int a = 0;//declaring the variable
				while((Word = fileReader.readLine())!=null) {//reading file line by line
					String[] statement = Word.split(",",-1);//spliting by the delimeter
					if(statement.length == 3) {//checking the length of array
						try {//checking wither number exception error or not
							double stmt = Double.parseDouble(statement[1]);//converting string to the double
					
							Money[a] = new Currency(statement[0],statement[1],statement[2]);//storing the value in array
							a++;//increment
						}catch(NumberFormatException e) {//number exception error through
							JOptionPane.showMessageDialog(null,"invalid number!!! ");//error message
						}
					
					}else {
						//Dialogue BOX
						JOptionPane.showMessageDialog(null,"insufficent data!!!");//error message
					}
					noLine++;//increment
		
				}
			} catch (NumberFormatException e) {//if the string is given instead of int

				JOptionPane.showMessageDialog(null,"currency format error!!!");//dialogue box 
			} catch (IOException e) {//if there is null value

				JOptionPane.showMessageDialog(null,"file Not Found Error!!!");//dialogue box
			} catch(NullPointerException e) {//checking wither given value is empty or not 
				JOptionPane.showMessageDialog(null,"please insert a value to convert!!!");//dialogue box
			}
			try {
				fileReader.close();//closing the file reader
			} catch (IOException e) {//if there is null value
	
				JOptionPane.showMessageDialog(null,"file Not Found Error!!!");//dialogue box
			}
		} catch (UnsupportedEncodingException e) {//Constructs an Unsupported Encoding Exception
	
			JOptionPane.showMessageDialog(null,"unsupported file encoding error!!!");//dialogue box
		} catch (FileNotFoundException e) {//file missing error
	
			JOptionPane.showMessageDialog(null,"file is missing!!!");//dialogue box
		}
		
		comboBox.removeAllItems();//removing all the items from combo box
		for(int statement = 0;statement<Line;statement++) {//checking the condition
			boxModel.addElement(Money[statement].getName());//giving the new value to the combo box
		}
		comboBox.setModel(boxModel);//seting the commbo box model

		
		for(int i = 0;i<Line;i++) {
		
		}
		conListener listener = new conListener();//new action listener
		convertButton.addActionListener(listener);//adding action listener to the convertbutton
		FileButton.addActionListener(listener);//adding action listener to the filebutton
		textField.addActionListener(listener);//adding action listener to the textfield
		input = new JLabel("Enter a Currency:");//creating the new input label field
		add(input);
		add(textField);//adding the textfield
		add(convertButton);//adding the convert button
		add(comboBox);//adding the combo box
		add(FileButton);//adding the file button
		add(ResultLabel);//adding label
		setBackground(Color.green);//setting the background color to green
	}
	
	private class conListener implements ActionListener {//implementing the action listener

	
		@Override
		public void actionPerformed(ActionEvent event) {//action performed
			String text = textField.getText();//geting the value of textfield to the text
			
  //           if (text.isEmpty() == false) {
				
				try {//checking wither it is in string or integer format
			
			if(event.getSource() == convertButton || event.getSource()==textField) {//result can be acess by clicking or pressing enter
				
				double result ;//declaring the variable
				String cboxy ;//declaring the variable
				
				double value = Double.parseDouble(text);//changing the string to the double
				boolean reverse = MainPanel.reverse.isSelected();//declaring the boolean to the reverse
				if(!reverse) {//if reverse is select or not
						result = value * Money[comboBox.getSelectedIndex()].getAmount();//geting the final value
						cboxy = Money[comboBox.getSelectedIndex()].getSymbol();//giving the symbol

				}else {

						result = value / Money[comboBox.getSelectedIndex()].getAmount();//final currency result
						cboxy = Money[comboBox.getSelectedIndex()].getSymbol();//giving the symbol to the final value
	
				}
	
				DecimalFormat decimalValue = new DecimalFormat("0.00");//decimal format which accept upto 2 decimal value only

	

					String r = decimalValue.format(result);//converting to the string
					ResultLabel.setText(cboxy + r);//output to the final value 
					count++;//increment
					MainPanel.Counter();//increasing the count value
				
			}
		
		}catch (NumberFormatException e) {//checking the number format error
			
			//displaying message dialog box
			JOptionPane.showMessageDialog(null, 
                    "It accepts only integer"
                    + " value", 
                    " ",
                    JOptionPane.PLAIN_MESSAGE);//dialogue box
	    	
			
			
			
		}
		

			
			

			if (event.getSource() == FileButton) {//giving the option to upload the file

					JFileChooser chooser = new JFileChooser();//choosing option 
					chooser.showOpenDialog(null);//giving null to the combo box
					File selected = chooser.getSelectedFile();//choosing option
					if(selected != null) {//checking wither it is null or not
						Line = 0;//declaring the value of line to the zero
						noLine = 0;//declaring the value of noline to zero
						boxModel.removeAllElements();//removing all element of combobox
						try {
							//class is used to read the text from a file
							BufferedReader fileReader = new BufferedReader(new InputStreamReader(new FileInputStream(chooser.getSelectedFile().getAbsolutePath()), "UTF8"));
							String g;
							try {
								while((g = fileReader.readLine()) != null) {
									String[] stmt = g.split(",",-1);
									if(stmt.length == 3) {
										try {
											if(!stmt[0].isEmpty() && !stmt[2].isEmpty()) {
												double v = Double.parseDouble(stmt[1]);
												Line++;
											}
											if(stmt[0].isEmpty()) {
												JOptionPane.showMessageDialog(null,"currency-name is missing!!!");//dialogue box
											}
											if(stmt[1].isEmpty()) {
												JOptionPane.showMessageDialog(null,"currency is missing!!!");//dialogue box
											}
											if(stmt[2].isEmpty()) {
												JOptionPane.showMessageDialog(null,"currency-symbol is missing!!!");//dialogue box
											}
											
										}catch(NumberFormatException e) {
											JOptionPane.showMessageDialog(null,"invalid data entry!!!");//dialogue box
										}
									}
									else {
										JOptionPane.showMessageDialog(null,"Delimeter is missing!!!");//dialogue box
									}
								}
							} catch (IOException e) {//if there is null value

								JOptionPane.showMessageDialog(null,"file Not Found Error!!!");//dialogue box
							}
							try {
								fileReader.close();
							} catch (IOException e) {//if there is null value

								JOptionPane.showMessageDialog(null,"file Not Found Error!!!");//dialogue box
							}
						} catch (UnsupportedEncodingException e) {//Constructs an Unsupported Encoding Exception

							JOptionPane.showMessageDialog(null,"unsupported file encoding error!!!");//dialogue box
						} catch (FileNotFoundException e) {

							JOptionPane.showMessageDialog(null,"file is missing!!!");//dialogue box
						}
						
						Money = new Currency[Line];
						
						try {
							BufferedReader fileReader = new BufferedReader(new InputStreamReader(new FileInputStream(chooser.getSelectedFile().getAbsolutePath()), "UTF8"));
							String define;
							int statement=0;
							try {
								while((define = fileReader.readLine()) != null) {
									String[] currencyArray = define.split(",",-1);
									if(currencyArray.length == 3) {
										try {
											double stmt = Double.parseDouble(currencyArray[1]);
											Money[statement] = new Currency(currencyArray[0],currencyArray[1],currencyArray[2]);
											statement++;
										}catch(NumberFormatException e) {
											
										}
									}else {
										//DIALOGUE BOX
									}
									noLine++;
								}
							} catch (IOException e) {//if there is null value

								JOptionPane.showMessageDialog(null,"file Not Found Error!!!");//dialogue box
							}
							try {
								fileReader.close();
							} catch (IOException e) {//if there is null value

								JOptionPane.showMessageDialog(null,"file Not Found Error!!!");//dialogue box
							}
						} catch (UnsupportedEncodingException e) {//Constructs an Unsupported Encoding Exception

							JOptionPane.showMessageDialog(null,"unsupported file encoding error!!!");//dialogue box
						} catch (FileNotFoundException e) {

							JOptionPane.showMessageDialog(null,"file is missing!!!");//dialogue box
						}
						for(int statement = 0;statement<Line;statement++) {
							boxModel.addElement(Money[statement].getName());
						}

						comboBox.setModel(boxModel);
				
						for(int i = 0;i<Line;i++) {
				
						}
					}
		}
	}
	
}
}
