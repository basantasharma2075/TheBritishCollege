
import java.awt.Color;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.ImageIcon;
import java.awt.*;
import java.awt.event.*;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.ImageIcon;
import java.awt.event.KeyEvent;
import javax.swing.JOptionPane;

/**
 * The main graphical panel used to display conversion components.
 * 
 * This is the starting point for the assignment.
 * 
 * The variable names have been deliberately made vague and generic, and most comments have been removed.
 * 
 * You may want to start by improving the variable names and commenting what the existing code does.
 * 
 * @author mdixon
 */
@SuppressWarnings("serial")
public class MainPanel extends JPanel {

	private final static String[] list = { "inches/cm","Miles/Kilometres","Pounds/Kilograms","Gallons/Litres","Feet/Metres","Celsius/Kelvin","Acres/Hectare" };
	private JTextField textField;
	private JLabel label, vcount;
	private JComboBox<String> combo;
	private JCheckBox reverse;
	int count=0;

	JMenuBar setupMenu() {

		JMenuBar menu = new JMenuBar();

		JMenu menu1 = new JMenu("File");
		menu1.setMnemonic(KeyEvent.VK_F); //giving shortcut to file
		JMenu menu2 = new JMenu("Help");
		menu2.setMnemonic(KeyEvent.VK_H);  //giving shortcut to help		

		menu.add(menu1); //ading menu on menubar
		menu.add(menu2);

		JMenuItem item1 = new JMenuItem("");		
		
		ImageIcon img = new ImageIcon(new ImageIcon("abuie.png"
				+ ""
				+ "").
				getImage().getScaledInstance(20,20,Image. //declaring size of image
						SCALE_DEFAULT));
		JMenuItem item2 = new JMenuItem("ABOUT",img);
		item2.setMnemonic(KeyEvent.VK_A);  //giving shortcut to exit		
		
		ImageIcon img1 = new ImageIcon(new ImageIcon("hello.jpg").
				getImage().getScaledInstance(20,20,Image.
						SCALE_DEFAULT));//declaring size of image
		item1 = new JMenuItem("Exit",img1);
		item1.setMnemonic(KeyEvent.VK_E);  //giving shortcut to exit
				
		//adding menu item
		menu1.add(item1); 
		menu2.add(item2);
		
		//displaying the message on about
			item2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
                JOptionPane.showMessageDialog(null, 
                    "This program is used to converted the "
                    + "mathemtical measurement" + "\n" 
                    + "This all code belongs to Mr. Basanta Timilsena" + "\n" +
                    "Copyright (c) 2018" + "\n" + 
                    "All Rights Reserved", 
                    "",
                    JOptionPane.PLAIN_MESSAGE);
            }
		});
		
		//exit button to exit  
		
		item1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e){
		          System.exit(0);
		      }
		});

		return menu;
	}


	MainPanel() {
		JButton aButton;

		ActionListener listener = new ConvertListener();
		
		

		combo = new JComboBox<String>(list);
		combo.addActionListener(listener); //convert values when option changed
		


		JLabel inputData = new JLabel("Enter value:"); //giving value
		

		JButton resultButton = new JButton("Result");
		resultButton.addActionListener(listener); // convert values when pressed
		
			
		
		JButton clearButton = new JButton("Clear");
		
		//clearing the textfield & count
		
		clearButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				textField.setText("");
				label.setText(null);
				label.setText("Answer: ");
				count=0;
				vcount.setText("Count: "+count);
				
            }
		});
		
		
		
		label = new JLabel("Answer: ");
		vcount=new JLabel("count: ");
		textField = new JTextField(5);
		
		
		reverse = new JCheckBox("Reverse");
		reverse.addActionListener(listener);
		reverse.setSelected(false);	
		
	
		
		add(combo);
		add(inputData);
		add(textField);
		add(resultButton);
		add(clearButton);
		add(label);
		add(vcount);
		add(reverse);
		textField.addActionListener(new ConvertListener());
		

		setPreferredSize(new Dimension(800, 80));
		setBackground(Color.LIGHT_GRAY);
		
		//tooltips
		
		combo.setToolTipText("choices on dropdown");
		textField.setToolTipText("input in int");
		resultButton.setToolTipText("click convert");
		clearButton.setToolTipText("click clear");
		reverse.setToolTipText("reverse the process");
		
		
				
	}
	
	
	
		
	private class ConvertListener implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent event) {
			
			

			String text = textField.getText().trim();

			if (text.isEmpty() == false) {
				
				try {
					
					
					
					double value = Double.parseDouble(text);

					// the factor applied during the conversion
					double factor = 0;

					// the offset applied during the conversion.
					double offset = 0;

					// Setup the correct factor/offset values depending on required conversion
					
					
					if(reverse.isSelected()) {
					
					
					switch (combo.getSelectedIndex()) {

					case 0: // inches to cm
						factor = 2.54;
						
						break;
						
					case 1://miles to Kilometres
						factor=1.60;
						
						break;
						
					case 2: //Pounds to Kilograms
						factor = 0.45;
						
						break;
						
					case 3://Gallons to litres
						factor= 3.78;
						
						break;
						
					case 4: // Feet to Metres
						factor = 0.3;
						
						break;
						
					case 5://Celcius to Kelvin
						factor = 1;
						offset = 274.15;
						
						break;
						
					case 6://Acres to Hectare
						
						factor = 0.4;
						
						
						break;
						
					}
					
					double result = value / factor + offset;//result

					
					
					count++;

					Double.toString(result);//converting to string
					
					//giving only 2 value after decimal
					label.setText(String.format("Answer: %.2f", result));
					
					
					
				}
					
					else {
						
						
						
						switch (combo.getSelectedIndex()) {

						case 0: // inches to cm
							factor = 2.54;
							
							break;
							
						case 1://miles to Kilometres
							factor=1.60;
							
							break;
							
						case 2: //Pounds to Kilograms
							factor = 0.45;
							
							break;
							
						case 3://Gallons to litres
							factor= 3.78;
							
							break;
							
						case 4: // Feet to Metres
							factor = 0.3;
							
							break;
							
						case 5://Celcius to Kelvin
							factor = 1;
							offset = 274.15;
							
							break;
							
						case 6://Acres to Hectare
							
							factor = 0.4;
							
							
							break;
							
						}

						
						double result = factor * value + offset;//result
						count++;//count no of task performed
						Double.toString(result);//converting to string
						label.setText(String.format("Answer: %.2f", result));//giving 2 decimal only after point
						

						
						
					}
				vcount.setText("Conversion count:" +count);//displaying count
					
					//through the string and other unaceptable value
				}catch (NumberFormatException e) {
					
					//displaying message dialog box
					JOptionPane.showMessageDialog(null, 
		                    "It accepts only integer value not a string"
		                    + " or any other.", 
		                    " ",
		                    JOptionPane.PLAIN_MESSAGE);
			    	
					
					
					
				}
				

			
			
			}
			//if we give blank it will display the error dialog box
			else {
				JOptionPane.showMessageDialog(null, 
	                    "It is blank. enter a integer value to process", 
	                    " ",
	                    JOptionPane.PLAIN_MESSAGE);
			}
			
			
		}
		
	}

}
