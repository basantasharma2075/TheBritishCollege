<?php

//require_once("../resource/connect.php");
require_once("resource/config.php");
//include (TEMPLATE_FRONT . DS . "header.php");
include ("resource/templates/front/header_outside.php");

?>



    <!-- Page Content -->
    <div class="container">

        <div class="row">

            <!--categories-->

            <?php
            //include (TEMPLATE_FRONT . DS . "side_nav.php");
            include ("resource/templates/front/side_nav_outside.php");

            ?>


            <div class="col-md-9">

                <div class="row carousel-holder">

                    <div class="col-md-12">
                         <?php
            //include (TEMPLATE_FRONT . DS . "slide_nav.php");
            include ("resource/templates/front/slide_nav_outside.php");

            ?>
<!-- slider-->

                    </div>

                </div>

                <div class="row">

                 

                    <?php

                    get_product_outside();

                    ?>

                   

                   

                    
                    

                   

                </div>

            </div>

            

        </div>

    </div>
    <!-- /.container -->

    




<?php 
//include (TEMPLATE_FRONT . DS . "footer.php");
//include ("../resource/templates/front/header.php");
include (TEMPLATE_FRONT . DS . "footer_outside.php");

?>
