<?php


if (isset($_GET['id'])) {
  # code...
  $query = query("SELECT * FROM GOODS WHERE PRODUCT_ID = " .($_GET['id']) . " ");
  oci_execute($query);

  while ($row = oci_fetch_array($query) ) {
    # code...

    $PRODUCT_TITLE       = $row['PRODUCT_TITLE'];
    $PRODUCT_CAT_ID      = $row['CAT_ID'];
    $PRODUCT_PRICE       = $row['PRODUCT_PRICE'];
    $PRODUCT_LD          = $row['PRODUCT_LD'];
    $PRODUCT_SD          = $row['PRODUCT_SD'];
    $PRODUCT_QUANTITY    = $row['PRODUCT_QUANTITY'];
    $PRODUCT_IMAGE       = $row['PRODUCT_IMAGE'];


  }

update_product();


}

?>




<div class="col-md-12">

<div class="row">
<h1 class="page-header">
   Edit Product
</h1>
</div>
               


<form action="" method="post" enctype="multipart/form-data">


<div class="col-md-8">

<div class="form-group">
    <label for="PRODUCT_TITLE">Product Title </label>
        <input type="text" name="PRODUCT_TITLE" class="form-control" value="<?php echo $PRODUCT_TITLE;?>">
       
    </div>


    <div class="form-group">
           <label for="product-title">Product Description</label>
      <textarea name="PRODUCT_LD" id="" cols="30" rows="10" class="form-control"><?php echo $PRODUCT_LD;?></textarea>
    </div>



    <div class="form-group row">

      <div class="col-xs-3">
        <label for="product-price">Product Price</label>
        <input type="number" name="PRODUCT_PRICE" class="form-control" size="60" value="<?php echo $PRODUCT_PRICE;?>">
      </div>
    </div>


    <div class="form-group">
           <label for="product-title">Product Short Description</label>
      <textarea name="PRODUCT_SD" id="" cols="30" rows="3" class="form-control"><?php echo $PRODUCT_SD;?></textarea>
    </div>




    
    

</div><!--Main Content-->


<!-- SIDEBAR-->


<aside id="admin_sidebar" class="col-md-4">

     
     <div class="form-group">
       <input type="submit" name="draft" class="btn btn-warning btn-lg" value="Draft">
        <input type="submit" name="update" class="btn btn-primary btn-lg" value="Update">
    </div>


     <!-- Product Categories-->

    <div class="form-group">
         <label for="product-title">Product Category</label>
          <hr>
        <select name="PRODUCT_CAT_ID" id="" class="form-control">
            <option value="<?php echo $PRODUCT_CAT_ID; ?>"><?php echo show_product_category_title($PRODUCT_CAT_ID);?></option>
            <?php show_categories_add_product_page(); ?>
           
        </select>


</div>





    <!-- Product Brands-->


    <div class="form-group">
      <label for="product-title">Product Quantity</label>
         <input type="number" class="form-control" name="PRODUCT_QUANTITY" value="<?php echo $PRODUCT_QUANTITY;?>">
    </div>


<!-- Product Tags 


    <div class="form-group">
          <label for="product-title">Product Keywords</label>
          <hr>
        <input type="text" name="product_tags" class="form-control">
    </div> -->

    <!-- Product Image -->
    <div class="form-group">
        <label for="product-title">Product Image</label>
        <input type="file" name="file"><br>

      
    </div>



</aside><!--SIDEBAR-->


    
</form>

