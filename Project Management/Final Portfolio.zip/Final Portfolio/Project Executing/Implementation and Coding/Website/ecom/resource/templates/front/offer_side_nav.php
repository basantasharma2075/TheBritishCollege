 <div class="col-md-3">
                
                <div class="list-group">

                    

                <img src="../resource/templates/front/image/HotLogo.png" alt="Smiley face" height="200" width="240" style="border-radius: 10px;">

                    <br><br><br>
                    <p class="lead" style="color: red;" >Shop Name</p>
                    <?php
                    get_categories();
                    ?>


                    
                    
                </div>
            </div>


           