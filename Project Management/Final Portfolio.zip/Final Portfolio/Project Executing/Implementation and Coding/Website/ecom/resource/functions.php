<?php


$upload_directory = "uploads";

//helper functions
function s_message($message){

    if (!empty($message)) {
        # code...
        $_SESSION['message'] = $message;
    } else{
        $message="";
    }
  

}

function d_message(){
    if (isset($_SESSION['message'])) {
        echo $_SESSION['message'];
        unset($_SESSION['message']);

        # code...
    }
}  

function redirects(){
	header("Location: $location");

}

//making the connection function
function query($sql){

	global $connection;
	return oci_parse($connection, $sql);

}

function confirm($result){

	global $connection;
//	return oci_parse($connection, $sql);

	if (!$result) {
                	  	die("query fail". oci_error($connection));
                	  	# code...
                	  }

}

function escape_string($string){

	global $connection;
	return oci_real_escape_string($connection, $string);
//	return oci_bind_by_name($connection, $string);
	//addslashes() pg_escape
	//oci_bind_by_name()

}


function fetch_array($result){

	return oci_fetch_array($result);

}

////////////////////////////////////////////////////FRONT END FUNCTIONS

//functions to display the products
function get_products(){

//	oci_execute($query);


	$query = query(" SELECT * FROM GOODS WHERE PRODUCT_QUANTITY >=1");
	oci_execute($query);

//	confirm($query);//to confirm the query is working

	while ($row = fetch_array($query)) {

        $product_image = display_image($row['PRODUCT_IMAGE']);


		echo "<div class='col-sm-12 col-lg-4 col-md-4'>
                        <div class='thumbnail' style = 'height:400px;'>
                            <a href='item.php?id={$row['PRODUCT_ID']}'><img src='../resource/{$product_image}'></a>
                            <div class='caption'>
                                <h4 class='pull-right'>&pound{$row['PRODUCT_PRICE']}</h4>
                                <h4><a href='item.php?id={$row['PRODUCT_ID']}'>{$row['PRODUCT_TITLE']}</a>
                                </h4>
                                <p>{$row['PRODUCT_SD']}</p>
                                
                                <a class='btn btn-primary' target='_blank' href='../resource/cart.php?add={$row['PRODUCT_ID']}' style = 'background: #DC8C14;'>Add to cart</a>
                            </div>
                            
                        </div>
                    </div>";
	}




}


function get_categories(){

	                $query = query("SELECT * FROM CAT");
                	oci_execute($query);
                	while ($row = fetch_array($query)) {
                		# code...
                		$category_links=<<<SPLIT

                		<a href='category.php?id={$row['CAT_ID']}' class='list-group-item' style='background:#EEE8AA; font-size: 20px;'>{$row['CAT_TITLE']}</a>
 
SPLIT;
echo $category_links;

                	}

}






function get_categories_outside(){

                    $query = query("SELECT * FROM CAT");
                    oci_execute($query);
                    while ($row = fetch_array($query)) {
                        # code...
                        $category_links=<<<SPLIT

                        <a href='public/category_outside.php?id={$row['CAT_ID']}' class='list-group-item' style='border:3px #EEE8AA; background:#EEE8AA; font-size: 20px;'>{$row['CAT_TITLE']}</a>
 
SPLIT;
echo $category_links;

                    }

}







//functions to display the products
function get_category(){

//	oci_execute($query);

	$query = query(" SELECT * FROM GOODS WHERE CAT_ID='$_GET[id]' AND PRODUCT_QUANTITY >=1");
	oci_execute($query);

//	confirm($query);//to confirm the query is working

	while ($row = fetch_array($query)) {

        $product_image = display_image($row['PRODUCT_IMAGE']);


		echo "<div class='col-md-3 col-sm-6 hero-feature'>
                <div class='thumbnail'>
                        <a href='item.php?id={$row['PRODUCT_ID']}'><img src='../resource/{$product_image}' alt=''></a>                    
                        <div class='caption'>
                        <h3><a href='item.php?id={$row['PRODUCT_ID']}'>{$row['PRODUCT_TITLE']}</a></h3>
                        <p>short description</p>
                        <p>
                            <a href='../resource/cart.php?add={$row['PRODUCT_ID']}' class='btn btn-primary'>Buy Now!</a> <a href='item.php?id={$row['PRODUCT_ID']}' class='btn btn-default'>More Info</a>
                        </p>
                    </div>
                </div>
            </div>";

	}




}


		
//		<div class='col-sm-4 col-lg-4 col-md-4'>
  #                      <div class='thumbnail'>
   #                         <a href='item.php?id={$row['PRODUCT_ID']}'><img src='http://placehold.it/320x150' alt=''></a>
    #                        <div class='caption'>
     #                           <h4 class='pull-right'>&pound{$row['PRODUCT_PRICE']}</h4>
      #                          <h4><a href='item.php?id={$row['PRODUCT_ID']}'>{$row['PRODUCT_TITLE']}</a>
       #                         </h4>
        #                        <p> short description </p>
         #                       <a class='btn btn-primary' target='_blank' href='item.php?id={$row['PRODUCT_ID']}'>Add to cart</a>
          #                  </div>
                            
           #             </div>
            #        </div>";



function get_category_outside(){

//  oci_execute($query);

    $query = query(" SELECT * FROM GOODS WHERE CAT_ID='$_GET[id]' AND PRODUCT_QUANTITY >=1");
    oci_execute($query);

//  confirm($query);//to confirm the query is working

    while ($row = fetch_array($query)) {

        $product_image = display_image($row['PRODUCT_IMAGE']);


        echo "<div class='col-md-3 col-sm-6 hero-feature'>
                <div class='thumbnail'>
                        <a href='item.php?id={$row['PRODUCT_ID']}'><img src='../resource/{$product_image}' alt=''></a>                    
                        <div class='caption'>
                        <h3><a href='item.php?id={$row['PRODUCT_ID']}'>{$row['PRODUCT_TITLE']}</a></h3>
                        <p>short description</p>
                        
                    </div>
                </div>
            </div>";

    }




}






function get_shop(){

//	oci_execute($query);

	$query = query(" SELECT * FROM GOODS WHERE PRODUCT_QUANTITY >=1");
	oci_execute($query);

//	confirm($query);//to confirm the query is working

	while ($row = fetch_array($query)) {
        $product_image = display_image($row['PRODUCT_IMAGE']);
		echo "<div class='col-md-3 col-sm-6 hero-feature'>
                <div class='thumbnail'>
                        <a href='item.php?id={$row['PRODUCT_ID']}'><img src='../resource/{$product_image}' alt=''></a>                    
                        <div class='caption'>
                        <h3><a href='item.php?id={$row['PRODUCT_ID']}'>{$row['PRODUCT_TITLE']}</a></h3>
                        <p>short description</p>
                        <p>
                            <a href='../resource/cart.php?add={$row['PRODUCT_ID']}' class='btn btn-primary'>Buy Now!</a> <a href='item.php?id={$row['PRODUCT_ID']}' class='btn btn-default'>More Info</a>
                        </p>
                    </div>
                </div>
            </div>";

	}




}





function get_login(){
    $v = 0;
    global $v;

	if (isset($_POST['submit'])) {
		$EMAIL=$_POST['EMAIL'];
		$PASSWORD=$_POST['PASSWORD'];

		$query=query("SELECT * FROM REGISTER WHERE USER_EMAIL='$EMAIL' AND USER_PASSWORD='$PASSWORD' ");
		oci_execute($query);

         while($row = oci_fetch_array($query)){

            $s=$row['ROLE'];

         }

         $query=query("SELECT * FROM TRADER WHERE TRADER_EMAIL='$EMAIL' AND TRADER_PASSWORD='$PASSWORD' ");
        oci_execute($query);

         while($row = oci_fetch_array($query)){

            $s=$row['ROLE'];
            $t=$row['CAT_ID'];
            $tri=$row['TRADER_ID'];
            $ver=$row['VERIFY'];

         }

         $query=query("SELECT * FROM CUSTOMER WHERE CUSTOMER_EMAIL='$EMAIL' AND CUSTOMER_PASSWORD='$PASSWORD' ");
        oci_execute($query);

         while($row = oci_fetch_array($query)){

            $s=$row['ROLE'];
            $ver=$row['VERIFY']; 

         }


         $query=query("SELECT * FROM CAT");
        oci_execute($query);


         while($row = oci_fetch_array($query)){

            $u=$row['CAT_ID'];

            if ($u == $t) {
                # code...
                $a=1;
                $v=$u;
            }

            

         }


       



		if ($s==2 && $a==1 && $ver==1){

            $_SESSION['EMAIL']=$EMAIL;

            $st = "UPDATE TRADER SET SESS_ID = '4' WHERE CAT_ID = '$v' and TRADER_ID = '$tri'";
            $qry = query($st);
            oci_execute($qry);



		header("Location: trader");

			//echo "trader";
        //   echo $v;
          // that.value = $v;
            //echo $u;

			//include("login.php");


		}else if ($s==1) {
            # code...
            $_SESSION['EMAIL']=$EMAIL;
        //    s_message("welcome {$EMAIL}");
            header("Location: admin");
        }else if ($s==3 && $ver ==1) {
            # code...
            $_SESSION['EMAIL']=$EMAIL;
        //    s_message("welcome {$EMAIL}");

            $st = "UPDATE CUSTOMER SET SEE = '4' WHERE CUSTOMER_EMAIL='$EMAIL' AND CUSTOMER_PASSWORD='$PASSWORD' ";
            $qry = query($st);
            oci_execute($qry);


            header("Location: index.php");
           // echo "customer";
        } else{
            s_message("your username and password is wrong");
            header("Location: login.php");

		}
		# code...
        echo "value";

	}

    

}


function send_message(){
    if(isset($_POST['submit'])){ 

        $to          =   $_POST['email'];;
        $from_name   =   $_POST['name'];
        $subject     =   $_POST['subject'];
        //$email       =   $_POST['email'];
        $message     =   $_POST['message'];


        $headers = "From: atnasab.dimond@gmail.com";


        $result = mail($to, $subject, $message,$headers);

        if(!$result) {

            echo "not sent";

//            set_message("Sorry we could not send your message");
    //        redirect("contact.php");
        } else {

  //          set_message("Your Message has been sent");
  //          redirect("contact.php");

            echo "sent";
        }




    }






}





////////////////////////////////////////////////////BACK END FUNCTIONS

function display_order(){

    $query = query("SELECT * FROM CUSTOMER_ORDER");
    oci_execute($query);

    while ($row = fetch_array($query)) {
        # code...
        $orders = <<<SPLIT


        <tr>

        <td>{$row['ORDER_ID']}</td>
        <td>{$row['PRODUCT_NAME']}</td>
        <td>{$row['PRICE']}</td>
        <td>{$row['QUANTITY']}</td>
        

        <td><a class = "btn btn-danger" href ="../../resource/templates/back/delete_order.php?id={$row['ORDER_ID']}"><span class="glyphicon-remove"></span></td>
        </tr>

SPLIT;
echo $orders;

    }
}



################ADMIN PRODUCTS#######3


function get_products_in_admin(){

//  oci_execute($query);


    $query = query(" SELECT * FROM GOODS");
    oci_execute($query);

//  confirm($query);//to confirm the query is working

    while ($row = fetch_array($query)) {

        $category = show_product_category_title($row['CAT_ID']);

        $product_image = display_image($row['PRODUCT_IMAGE']);


        $product = <<<SPLIT

         <tr>
            <td>{$row['PRODUCT_ID']}</td>
            <td>{$row['PRODUCT_TITLE']} <br>
            <a href="index.php?edit_product&id={$row['PRODUCT_ID']}">
             <img width='100' src="../../resource/{$product_image}" alt=""></a> 
            </td>
            <td>{$category}</td>
            <td>{$row['PRODUCT_PRICE']}</td>
            <td>{$row['PRODUCT_QUANTITY']}</td>
            

            <td><a class="btn btn-danger" href="../../resource/templates/back/products_delete.php?id={$row['PRODUCT_ID']}"><span class="glyphicon glyphicon-remove"></span></a></td>
        </tr>

SPLIT;

//             <img src='http://placehold.it/320x150' alt=''>

echo $product;
    }




}


function show_product_category_title($CAT_ID){

    $category_query = query("SELECT * FROM CAT WHERE CAT_ID = '{$CAT_ID}'");
    confirm($category_query);
    oci_execute($category_query);

    while ($category_row = oci_fetch_array($category_query)) {
        # code...
        return $category_row['CAT_TITLE'];
    }



}



###################ADD PRODUCTS IN ADMIN##############


function display_image($picture){

    global $upload_directory;

    return $upload_directory .DS . $picture;
}



function add_product(){

    if(isset($_POST['publish'])){

    $PRODUCT_TITLE       = $_POST['PRODUCT_TITLE'];
    $PRODUCT_PRICE       = $_POST['PRODUCT_PRICE'];
    $PRODUCT_SD          = $_POST['PRODUCT_SD'];
    $PRODUCT_IMAGE       = $_FILES['file']['name'];
    $image_temp_location = $_FILES['file']['tmp_name'];

    
    $PRODUCT_LD          = $_POST['PRODUCT_LD'];
    $PRODUCT_QUANTITY    = $_POST['PRODUCT_QUANTITY'];
    $PRODUCT_CAT_ID      = $_POST['PRODUCT_CAT_ID'];
    
    

    move_uploaded_file($image_temp_location, UPLOAD_DIRECTORY . DS . $PRODUCT_IMAGE);
//$stid = oci_parse($conn,"INSERT INTO mytab (id, text) VALUES(:id_bv, :text_bv)");


    $qry = query("SELECT * FROM TRADER WHERE SESS_ID = '4'");
    oci_execute($qry);
    while ($row = fetch_array($qry)) {
        $ti = $row['TRADER_ID'];
    }





    $query = query("INSERT INTO GOODS (PRODUCT_TITLE, PRODUCT_PRICE, PRODUCT_SD, PRODUCT_IMAGE,  PRODUCT_LD,  PRODUCT_QUANTITY, CAT_ID, TRADER_ID) VALUES('{$PRODUCT_TITLE}', '{$PRODUCT_PRICE}', '{$PRODUCT_SD}', '{$PRODUCT_IMAGE}', '{$PRODUCT_LD}',  '{$PRODUCT_QUANTITY}' , '{$PRODUCT_CAT_ID}', '{$ti}')");

    oci_execute($query);


    


//    confirm ($query);
  //  oci_execute($query);
   // $last_id = last_id();
    s_message("new product has been added");
    //redirect("index.php?products");
    header("Location: index.php?products");

//$stid = oci_parse($conn,"INSERT INTO mytab (id, text) VALUES(:id_bv, :text_bv)");

//$id = 1;
//$text = "Data to insert";
//oci_bind_by_name($stid, ":id_bv", $id);
//oci_bind_by_name($stid, ":text_bv", $text);
//oci_execute($stid);



    }
}




function show_categories_add_product_page(){

                    $query = query("SELECT * FROM CAT");
                    oci_execute($query);
                    while ($row = fetch_array($query)) {
                        # code...
                        $category_options=<<<SPLIT
                        <option value="{$row['CAT_ID']}">{$row['CAT_TITLE']}</option>
 
SPLIT;
echo $category_options;

                    }

}

###################updating product code###########

function update_product(){

    if(isset($_POST['update'])){

    $PRODUCT_TITLE       = $_POST['PRODUCT_TITLE'];
    $PRODUCT_CAT_ID      = $_POST['PRODUCT_CAT_ID'];
    $PRODUCT_PRICE       = $_POST['PRODUCT_PRICE'];
    $PRODUCT_LD          = $_POST['PRODUCT_LD'];
    $PRODUCT_SD          = $_POST['PRODUCT_SD'];
    $PRODUCT_QUANTITY    = $_POST['PRODUCT_QUANTITY'];
    $PRODUCT_IMAGE       = $_FILES['file']['name'];
    $image_temp_location = $_FILES['file']['tmp_name'];


    if (empty($PRODUCT_IMAGE)) {
        # code...

        $get_pic = query("SELECT PRODUCT_IMAGE FROM GOODS WHERE PRODUCT_ID =" .($_GET['id']). " ");
        oci_execute($get_pic);
        while ($pic = fetch_array($get_pic)) {
            # code...
            $PRODUCT_IMAGE = $pic['PRODUCT_IMAGE'];
        }
    }




    move_uploaded_file($image_temp_location, UPLOAD_DIRECTORY . DS . $PRODUCT_IMAGE);
//$stid = oci_parse($conn,"INSERT INTO mytab (id, text) VALUES(:id_bv, :text_bv)");


$st = "UPDATE GOODS SET PRODUCT_TITLE = '$PRODUCT_TITLE', CAT_ID = '$PRODUCT_CAT_ID', PRODUCT_PRICE = '$PRODUCT_PRICE', PRODUCT_LD = '$PRODUCT_LD', PRODUCT_SD = '$PRODUCT_SD', PRODUCT_QUANTITY = '$PRODUCT_QUANTITY', PRODUCT_IMAGE = '$PRODUCT_IMAGE'  WHERE PRODUCT_ID = '$_GET[id]'";
$qry = query($st);
oci_execute($qry);


//    confirm ($query);
  //  oci_execute($query);
   // $last_id = last_id();
    s_message("Product has been updated");
    //redirect("index.php?products");
    header("Location: index.php?products");

//$stid = oci_parse($conn,"INSERT INTO mytab (id, text) VALUES(:id_bv, :text_bv)");

//$id = 1;
//$text = "Data to insert";
//oci_bind_by_name($stid, ":id_bv", $id);
//oci_bind_by_name($stid, ":text_bv", $text);
//oci_execute($stid);



    }
}

######################category in admin######################

function show_categories_in_admin(){

    $query = "SELECT * FROM CAT";
    $category_query = query($query);
    oci_execute($category_query);

    while ($row = fetch_array($category_query)) {
        # code...
        $CAT_ID = $row['CAT_ID'];
        $CAT_TITLE = $row['CAT_TITLE'];

        $category = <<<SPLIT

        <tr>
            <td>{$CAT_ID}</td>
            <td>{$CAT_TITLE}</td>
<td><a class="btn btn-danger" href="../../resource/templates/back/delete_category.php?id={$row['CAT_ID']}"><span class="glyphicon glyphicon-remove"></span></a></td>        </tr>

SPLIT;
echo $category;
    }
}

function add_category(){

    if (isset($_POST['add_category'])) {
        # code...
        $CAT_TITLE = $_POST['CAT_TITLE'];

        if (empty($CAT_TITLE) || $CAT_TITLE == " ") {
            # code...
            echo "<p class = 'bg-danger'>This cannot be empty </p>";
        } else{

        $query = query("INSERT INTO CAT (CAT_TITLE) VALUES ('{$CAT_TITLE}')");
        oci_execute($query);

       s_message("Category has been added");

        }  
    }
}



################## admin user#####################


function display_user(){

    $query = "SELECT * FROM CUSTOMER";
    $category_query = query($query);
    oci_execute($category_query);

    while ($row = fetch_array($category_query)) {
        # code...
          
        $CUSTOMER_ID = $row['CUSTOMER_ID'];
        $CUSTOMER_NAME = $row['CUSTOMER_NAME'];
        $CUSTOMER_EMAIL = $row['CUSTOMER_EMAIL'];
        $CUSTOMER_PASSWORD = $row['CUSTOMER_PASSWORD'];
        $STATUS = $row['STATUS'];

        $user = <<<SPLIT

        <tr>
            <td>{$CUSTOMER_ID}</td>
            <td>{$CUSTOMER_NAME}</td>
            <td>{$CUSTOMER_EMAIL}</td>
            <td>{$STATUS}</td>
<td><a class="btn btn-danger" href="../../resource/templates/back/delete_user.php?id={$row['CUSTOMER_ID']}"><span class="glyphicon glyphicon-remove"></span></a></td>        </tr>

SPLIT;
echo $user;
    }
}

function add_user(){

    if (isset($_POST['add_user'])) {
        # code...
        $USER_NAME = $_POST['USER_NAME'];
        $EMAIL = $_POST['USER_EMAIL'];
        $PASSWORD = $_POST['USER_PASSWORD'];
//        $USER_PHOTO = $_FILES['file']['name'];
  //      $photo_temp = $_FILES['file']['tmp_name'];

    //    move_uploaded_file($photo_temp, UPLOAD_DIRECTORY . DS . $USER_PHOTO);

        $query = query("INSERT INTO CUSTOMER (CUSTOMER_NAME, CUSTOMER_EMAIL, CUSTOMER_PASSWORD, ROLE) VALUES ('$USER_NAME', '$EMAIL','$PASSWORD','3')");

        oci_execute($query);

        s_message("user created");

        header("Location: index.php?users");

    }
}

function display_trader(){

    $query = "SELECT * FROM TRADER";
    $category_query = query($query);
    oci_execute($category_query);

    while ($row = fetch_array($category_query)) {
        # code...
       //   TRADER_ID TRADER_NAME TRADER_EMAIL    TRADER_PASSWORD SHOP_NAME   CAT_ID  ROLE
        $TRADER_ID = $row['TRADER_ID'];
        $TRADER_NAME = $row['TRADER_NAME'];
        $TRADER_EMAIL = $row['TRADER_EMAIL'];
        $TRADER_PASSWORD = $row['TRADER_PASSWORD'];
        $SHOP_NAME = $row['SHOP_NAME'];
        $CAT_ID = $row['CAT_ID'];

        $trader = <<<SPLIT

        <tr>
            <td>{$TRADER_ID}</td>
            <td>{$TRADER_NAME}</td>
            <td>{$TRADER_EMAIL}</td>
            <td>{$SHOP_NAME}</td>
            <td>{$CAT_ID}</td>
<td><a class="btn btn-danger" href="../../resource/templates/back/delete_trader.php?id={$row['TRADER_ID']}"><span class="glyphicon glyphicon-remove"></span></a></td>        </tr>

SPLIT;
echo $trader;
    }
}





function get_reports(){

//  oci_execute($query);


    $query = query(" SELECT * FROM CUSTOMER_ORDER");
    oci_execute($query);

//  confirm($query);//to confirm the query is working

    while ($row = fetch_array($query)) {

      $report = <<<SPLIT

         <tr>
            <td>{$row['PRODUCT_ID']} </td>
            <td>{$row['ORDER_ID']} </td>
            <td>{$row['PRICE']} </td>
            <td>{$row['PRODUCT_NAME']} </td>
            <td>{$row['QUANTITY']}</td>


            
           
        </tr>

SPLIT;

//             <img src='http://placehold.it/320x150' alt=''>

echo $report;
    }




}


####################GET SLIDES FUNCTION##############
function add_slides(){

    if (isset($_POST['add_slide'])) {
        # code...
        $slide_title = $_POST['slide_title'];
        $slide_image = $_FILES['file']['name'];
        $slide_image_loc = $_FILES['file']['tmp_name'];

        if(empty($slide_title) || empty($slide_image)){
            echo "<p class = 'bg_danger'> This field could not be empty</p>";
        }else{
            move_uploaded_file($slide_image_loc, UPLOAD_DIRECTORY. DS. $slide_image);
            $query = query("INSERT INTO SLIDES (SLIDE_TITLE, SLIDE_IMAGE) VALUES ('{$slide_title}' , '{$slide_image}')"); 
            oci_execute($query);
            s_message('slide added');
            header("Location: index.php?slides");

        }
    }
    
}
function get_active_slide(){


     $query = query("SELECT * FROM SLIDES WHERE ROWNUM = 1");
    oci_execute($query);
    while ($row = fetch_array($query)) {

        $slide_image = display_image($row['SLIDE_IMAGE']);

        # code...
        $slide_active = <<<DELIMETER
<div class="item active">
<img class="slide-image" src="../resource/{$slide_image}" alt="">

</div>


DELIMETER;
echo $slide_active;
    }



//     $query = query("SELECT * FROM SLIDES WHERE ROWNUM = 1");
//     oci_execute($query);
//     while ($row = fetch_array($query)) {

//         $slide_image = display_image($row['SLIDE_IMAGE']);

//         # code...
//         $slide_active = <<<DELIMETER
// <div class="item active">
// <img class="slide-image" src="../resource/{$slide_image}" alt="">

// </div>


// DELIMETER;
// echo $slide_active;
//     }



    
}

function get_current_slide_in_admin(){

    $query = query("SELECT * FROM SLIDES WHERE ROWNUM = 1");
    oci_execute($query);
    while ($row = fetch_array($query)) {

        $slide_image = display_image($row['SLIDE_IMAGE']);

        # code...
        $slide_active_admin = <<<DELIMETER
<img class="img-responsive" src="../../resource/{$slide_image}" alt="">




DELIMETER;
echo $slide_active_admin;
    }
    
}


function get_slides(){

    $query = query("SELECT * FROM SLIDES");
    oci_execute($query);
    while ($row = fetch_array($query)) {

        $slide_image = display_image($row['SLIDE_IMAGE']);

        # code...
        $slides = <<<DELIMETER
<div class="item">
<img class="slide-image" src="../resource/{$slide_image}" alt="">
</div>


DELIMETER;
echo $slides;
    }

}


function get_slide_thumbnails(){

    $query = query("SELECT * FROM SLIDES ORDER BY SLIDE_ID ASC");
    oci_execute($query);
    while ($row = fetch_array($query)) {

        $slide_image = display_image($row['SLIDE_IMAGE']);

        # code...
        $slide_thumb_admin = <<<DELIMETER

<div class="col-xs-6 col-md-3 image_container">

    <a href="index.php?delete_slide_id={$row['SLIDE_ID']}">

        <img class="img-responsive slide_image" src="../../resource/{$slide_image}" alt="">
        
    </a>
    <div class = "caption">
    <p>{$row['SLIDE_TITLE']}</p>
    </div>
    
</div>




DELIMETER;
echo $slide_thumb_admin;
    }
    
}
















###########################outside login#####################################

function get_product_outside(){

//  oci_execute($query);


    $query = query(" SELECT * FROM GOODS WHERE PRODUCT_QUANTITY >=1");
    oci_execute($query);

//  confirm($query);//to confirm the query is working

    while ($row = fetch_array($query)) {

        $product_image = display_image($row['PRODUCT_IMAGE']);


        echo "<div class='col-sm-4 col-lg-4 col-md-4'>
                        <div class='thumbnail' style = 'border: 5px solid #DC8C14; height:400px; background:transparent;'>
                            <a ><img src='resource/{$product_image}'></a>
                            <div class='caption'>
                                <h4 class='pull-right'>&pound{$row['PRODUCT_PRICE']}</h4>
                                <h4><a>{$row['PRODUCT_TITLE']}</a>
                                </h4>
                                <p>{$row['PRODUCT_SD']}</p>
                               

                            </div>
                            
                        </div>
                    </div>";

                   
    }




}



function get_active_slide_outside(){

    $query = query("SELECT * FROM SLIDES WHERE ROWNUM = 1");
    oci_execute($query);
    while ($row = fetch_array($query)) {

        $slide_image = display_image($row['SLIDE_IMAGE']);

        # code...
        $slide_active = <<<DELIMETER
<div class="item active">
<img class="slide-image" src="resource/{$slide_image}" alt="">

</div>


DELIMETER;
echo $slide_active;
    }



    
}




function get_slides_outside(){

    $query = query("SELECT * FROM SLIDES");
    oci_execute($query);
    while ($row = fetch_array($query)) {

        $slide_image = display_image($row['SLIDE_IMAGE']);

        # code...
        $slides = <<<DELIMETER
<div class="item">
<img class="slide-image" src="resource/{$slide_image}" alt="">
</div>


DELIMETER;
echo $slides;
    }

}



function get_shop_outside(){

//  oci_execute($query);

    $query = query(" SELECT * FROM GOODS WHERE PRODUCT_QUANTITY >=1");
    oci_execute($query);

//  confirm($query);//to confirm the query is working

    while ($row = fetch_array($query)) {
        $product_image = display_image($row['PRODUCT_IMAGE']);
        echo "<div class='col-md-3 col-sm-6 hero-feature'>
                <div class='thumbnail'>
                        <a href='item.php?id={$row['PRODUCT_ID']}'><img src='../resource/{$product_image}' alt=''></a>                    
                        <div class='caption'>
                        <h3><a href='item.php?id={$row['PRODUCT_ID']}'>{$row['PRODUCT_TITLE']}</a></h3>
                        <p>short description</p>
                        
                    </div>
                </div>
            </div>";

    }




}



























#########################for trader######################


     //   TRADER_PASSWORD SHOP_NAME   
function get_products_in_trader(){

$query=query("SELECT * FROM TRADER WHERE SESS_ID='4' ");
        oci_execute($query);

         while($row = oci_fetch_array($query)){


            $a=$row['TRADER_ID'];

         }


    $query = query(" SELECT * FROM GOODS WHERE TRADER_ID = '$a'");
    oci_execute($query);

//  confirm($query);//to confirm the query is working

    while ($row = fetch_array($query)) {

        $category = show_product_category_title($row['CAT_ID']);

        $product_image = display_image($row['PRODUCT_IMAGE']);


        $product = <<<SPLIT

         <tr>
            <td>{$row['PRODUCT_ID']}</td>
            <td>{$row['PRODUCT_TITLE']} <br>
            <a href="index.php?edit_product&id={$row['PRODUCT_ID']}">
             <img width='100' src="../../resource/{$product_image}" alt=""></a> 
            </td>
            <td>{$category}</td>
            <td>{$row['PRODUCT_PRICE']}</td>
            <td>{$row['PRODUCT_QUANTITY']}</td>
            

            <td><a class="btn btn-danger" href="../../resource/templates/back/products_delete_trader.php?id={$row['PRODUCT_ID']}"><span class="glyphicon glyphicon-remove"></span></a></td>
        </tr>

SPLIT;

//             <img src='http://placehold.it/320x150' alt=''>

echo $product;
    }





}



function show_categories_add_product_page_trader(){

    $query=query("SELECT * FROM TRADER WHERE SESS_ID='4' ");
        oci_execute($query);

         while($row = oci_fetch_array($query)){


            $a=$row['CAT_ID'];

         }

                    $query = query("SELECT * FROM CAT WHERE CAT_ID = '$a' ");
                    oci_execute($query);
                    while ($row = fetch_array($query)) {
                        # code...
                        $category_options=<<<SPLIT
                        <option value="{$row['CAT_ID']}">{$row['CAT_TITLE']}</option>
 
SPLIT;
echo $category_options;

                    }

}




function update_customer_detail(){

    if(isset($_POST['submit'])){

    $CUSTOMER_NAME           = $_POST['CUSTOMER_NAME'];
    $CUSTOMER_PASSWORD       = $_POST['CUSTOMER_PASSWORD'];
    $STATUS                  = $_POST['STATUS'];
    

$st = "UPDATE CUSTOMER SET CUSTOMER_NAME = '$CUSTOMER_NAME', CUSTOMER_PASSWORD = '$CUSTOMER_PASSWORD', STATUS = '$STATUS' WHERE SEE = '4' ";
  $qry = query($st);
oci_execute($qry);
    s_message("Customer details has been updated");

    if ($STATUS == 'Active') {
        # code...
        header("Location: index.php");
    }else{

        header("Location: ../index.php");


    }


    

    }
}






function offer_product(){

    if(isset($_POST['publish'])){

    $PRODUCT_TITLE       = $_POST['PRODUCT_TITLE'];
    $PRODUCT_PRICE       = $_POST['PRODUCT_PRICE'];
    $PRODUCT_SD          = $_POST['PRODUCT_SD'];
    $PRODUCT_IMAGE       = $_FILES['file']['name'];
    $image_temp_location = $_FILES['file']['tmp_name'];

    
    $PRODUCT_LD          = $_POST['PRODUCT_LD'];
    $PRODUCT_QUANTITY    = $_POST['PRODUCT_QUANTITY'];
    $PRODUCT_CAT_ID      = $_POST['PRODUCT_CAT_ID'];
    
    

    move_uploaded_file($image_temp_location, UPLOAD_DIRECTORY . DS . $PRODUCT_IMAGE);
//$stid = oci_parse($conn,"INSERT INTO mytab (id, text) VALUES(:id_bv, :text_bv)");


    $qry = query("SELECT * FROM TRADER WHERE SESS_ID = '4'");
    oci_execute($qry);
    while ($row = fetch_array($qry)) {
        $ti = $row['TRADER_ID'];
    }





    $query = query("INSERT INTO OFFER (OFFER_AMOUNT, OFFER_NAME, CAT_ID, LD,  SD,  IMAGE, QUANTITY, TRADER_ID) VALUES('{$PRODUCT_PRICE}', '{$PRODUCT_TITLE}', '{$PRODUCT_CAT_ID}', '{$PRODUCT_LD}', '{$PRODUCT_SD}', '{$PRODUCT_IMAGE}', '{$PRODUCT_QUANTITY}' ,  '{$ti}')");

    oci_execute($query);


    


//    confirm ($query);
  //  oci_execute($query);
   // $last_id = last_id();
    s_message("new product has been added");
    //redirect("index.php?products");
    header("Location: index.php?products");

//$stid = oci_parse($conn,"INSERT INTO mytab (id, text) VALUES(:id_bv, :text_bv)");

//$id = 1;
//$text = "Data to insert";
//oci_bind_by_name($stid, ":id_bv", $id);
//oci_bind_by_name($stid, ":text_bv", $text);
//oci_execute($stid);



    }
}






function get_products_in_trader_offer(){

$query=query("SELECT * FROM TRADER WHERE SESS_ID='4' ");
        oci_execute($query);

         while($row = oci_fetch_array($query)){


            $a=$row['TRADER_ID'];

         }


    $query = query(" SELECT * FROM OFFER WHERE TRADER_ID = '$a'");
    oci_execute($query);

//  confirm($query);//to confirm the query is working

    while ($row = fetch_array($query)) {

        $category = show_product_category_title($row['CAT_ID']);

        $product_image = display_image($row['IMAGE']);


        $product = <<<SPLIT

         <tr>
            <td>{$row['OFFER_ID']}</td>
            <td>{$row['OFFER_NAME']} <br>

             <img width='100' src="../../resource/{$product_image}" alt=""> 
            </td>
            <td>{$category}</td>
            <td>{$row['OFFER_AMOUNT']}</td>
            <td>{$row['QUANTITY']}</td>
            

            <td><a class="btn btn-danger" href="../../resource/templates/back/products_delete_offer.php?id={$row['OFFER_ID']}"><span class="glyphicon glyphicon-remove"></span></a></td>
        </tr>

SPLIT;

//             <img src='http://placehold.it/320x150' alt=''>

echo $product;
    }





}


function get_products_offer(){

//  oci_execute($query);


    $query = query(" SELECT * FROM OFFER WHERE QUANTITY >=1");
    oci_execute($query);

//  confirm($query);//to confirm the query is working

    while ($row = fetch_array($query)) {

        $product_image = display_image($row['IMAGE']);


        echo "<div class='col-sm-12 col-lg-4 col-md-4'>
                        <div class='thumbnail' style = 'height:400px; width: 240px;'>
                            <img src='../resource/{$product_image}'>
                            <div class='caption'>
                                <h4 class='pull-right'>&pound{$row['OFFER_AMOUNT']}</h4>
                                <h4>{$row['OFFER_NAME']}
                                </h4>
                                <p>{$row['SD']}</p>
                                
                                <a class='btn btn-primary' target='_blank' href='../public' style = 'background: #DC8C14;'>Add to cart</a>
                            </div>
                            
                        </div>
                    </div>";
    }




}






?>


