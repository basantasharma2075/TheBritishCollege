           <!-- Sidebar Menu Items - These collapse to the responsive navigation menu on small screens -->
            <div class="collapse navbar-collapse navbar-ex1-collapse">
                <ul class="nav navbar-nav side-nav">
                    <li class="active">
                        <a href="index.php"><i class="fa fa-fw fa-dashboard"></i> Dashboard</a>
                    </li>

                    

                    <li>
                        <a href="index.php?products_trader"><i class="fa fa-fw fa-bar-chart-o"></i> View Products</a>
                    </li>
                    <li>
                        <a href="index.php?add_product_trader"><i class="fa fa-fw fa-table"></i> Add Product</a>
                    </li>
                    <li>
                        <a href="index.php?offer_product_trader"><i class="fa fa-fw fa-desktop"></i> Offer Product</a>
                    </li>
                    <li>
                        <a href="index.php?view_offer"><i class="fa fa-fw fa-bar-chart-o"></i>View Offer</a>
                    </li>
                    
                    
                
                </ul>
            </div>