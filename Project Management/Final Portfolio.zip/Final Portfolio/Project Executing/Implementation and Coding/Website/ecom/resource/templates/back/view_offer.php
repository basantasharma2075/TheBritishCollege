             <div class="row">

<h1 class="page-header">
   Offer Products

</h1>
<h3 class="bg-success"><?php //d_message(); ?></h3>
<table class="table table-hover">


    <thead>

      <tr>
           <th>Id</th>
           <th>Title</th>
           <th>Category</th>
           <th>Price</th>
           <th>Quantity</th>
      </tr>
    </thead>
    <tbody>

     <?php

     get_products_in_trader_offer();
  //   get_login();

     ?>
      


  </tbody>
</table>











                
                 


             </div>
