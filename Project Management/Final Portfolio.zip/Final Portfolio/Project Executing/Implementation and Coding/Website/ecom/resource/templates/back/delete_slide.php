<?php require_once("../../resource/config.php");


if(isset($_GET['delete_slide_id'])) {


$query = query("DELETE FROM SLIDES WHERE SLIDE_ID = " . ($_GET['delete_slide_id']) . " ");
oci_execute($query);
//"SELECT * FROM PRODUCT WHERE PRODUCT_ID ='$_GET[id]'"
//confirm($query);

//echo "deleted";

//redirect("");
s_message("slide deleted");
header("Location:index.php?slides");



} else {

echo("not deleted");
//redirect("../../../public/admin/index.php?categories");


}






 ?>