        <div class="container">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded = "true">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="index.php" style='font-size:35px;'>Shop-Mart</a>
            </div>
            <!-- Collect the nav links, forms, and other content for toggling -->
            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                <ul class="nav navbar-nav">
                    <li>
                        <a href="shop.php" style='font-size:25px;'>Shop</a>
                    </li>

                   <li>
                        <a href="signup.php" style='font-size:25px;'>Sign In</a>
                    </li>  
                     <li>
                        <a href="checkout.php" style='font-size:25px;'>Checkout</a>
                    </li>
                    <li>
                        <a href="contact.php" style='font-size:25px;'>Contact</a>
                    </li>
                    <li>
                        <a href="customer_detail.php" style='font-size:25px;'>Account Setting</a>
                    </li>
                    <li>
                        <a href="paypal_order.php" style='font-size:25px;'>Order</a>
                    </li>

                </ul>

                <ul class="nav navbar-nav" style="float: right;">


                <li>
                        <a href="../resource/templates/front/logout.php" style='font-size:25px;'>Logout</a>
                    </li>

            </ul>
            </div>
            <!-- /.navbar-collapse -->
        </div>
        <!-- /.container -->


