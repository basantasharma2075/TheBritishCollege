<?php

ob_start();

session_start();

$connection=oci_connect('ecom','9845634510','//localhost/xe');
if(!$connection){
	$m=oci_error();
	echo $m['message'],"\n";
	exit;} else{}
//	print"Connected to Oracle!";}

require_once ("functions.php");

	?>
	