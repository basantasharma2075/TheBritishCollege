<?php require_once("../../config.php");


if(isset($_GET['id'])) {


$query = query("DELETE FROM TRADER WHERE TRADER_ID = '$_GET[id]' ");
oci_execute($query);
//"SELECT * FROM PRODUCT WHERE PRODUCT_ID ='$_GET[id]'"
//confirm($query);

//echo "deleted";

//redirect("");
header("Location: ../../../public/admin/index.php?trader");



} else {

echo("not deleted");
//redirect("../../../public/admin/index.php?categories");


}






 ?>