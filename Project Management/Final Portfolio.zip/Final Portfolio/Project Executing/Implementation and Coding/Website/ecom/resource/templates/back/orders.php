


                


        <div class="col-md-12">
<div class="row">
<h1 class="page-header">
   All Orders

</h1>
</div>

<div class="row">
<table class="table table-hover">
    <thead>
      <tr>
           <th>I.D</th>
           <th>PRODUCT_NAME</th>
           <th>PRICE</th>
           <th>QUANTITY</th>
           
      </tr>
    </thead>
    <tbody>
       <?php

       display_order();

       ?>

    </tbody>
</table>
</div>




