<?php #require_once("../../config.php");
#if(isset($_GET['id'])) {
#$query = query("DELETE FROM PRODUCT WHERE PRODUCT_ID = '$_GET[id]' ");
#s_message("Product Deleted");
#header("Location: ../../../public/admin/index.php?products");
#} else {
#header("Location: ../../../public/admin/index.php?products");
#}
?>

 <?php require_once("../../config.php");


if(isset($_GET['id'])) {


$query = query("DELETE FROM GOODS WHERE PRODUCT_ID = " .($_GET['id']) . " ");
confirm($query);
oci_execute($query);

s_message("Product Deleted");
header("Location: ../../../public/trader/index.php?products");


} else {

header("Location: ../../../public/trader/index.php?products");


}






 ?>