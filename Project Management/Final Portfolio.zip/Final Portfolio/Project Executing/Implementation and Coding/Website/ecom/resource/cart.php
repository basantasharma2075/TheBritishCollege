 <?php

//require_once("../resource/connect.php");
require_once("config.php");
?>



<?php

if (isset($_GET['add'])) {
    # code...

    $query = query("SELECT * FROM GOODS WHERE PRODUCT_ID=" .($_GET['add']) );
    oci_execute($query);

    while ($row = fetch_array($query)) {
        # code...

        if(3 != $_SESSION['PRODUCT_' . $_GET['add']]){

            $_SESSION['PRODUCT_' . $_GET['add']] +=1;
            header("Location: ../public/checkout.php");
        } else{

            s_message("Maximum 3 quantity allowed");

            header("Location: ../public/checkout.php");


        }


    }


   // $_SESSION['PRODUCT_' . $_GET['add']] +=1;
    // header("Location: index.php");
}


if (isset($_GET['remove'])) {
    # code...
    $_SESSION['PRODUCT_' . $_GET['remove']]--;
    if($_SESSION['PRODUCT_' . $_GET['remove']] < 1){
        unset($_SESSION['item_total']);
unset($_SESSION['item_quantity']);

                    header("Location: ../public/checkout.php");


    }else{

                    header("Location: ../public/checkout.php");


    }

}







if (isset($_GET['delete'])){

$_SESSION['PRODUCT_' . $_GET['delete']] = '0';
unset($_SESSION['item_total']);
unset($_SESSION['item_quantity']);

header("Location: ../public/checkout.php");
}



function cart(){

    $total=0;
    $item_quantity=0;
    $item_name = 1;
    $item_number = 1;
    $amount = 1;
    $quantity = 1;

   foreach ($_SESSION as $name => $value) {
       # code...

    if($value>0){


    



        if (substr($name, 0, 8) == "PRODUCT_") {

            $len = strlen($name );
            $length = ($len - 8);
            $id = substr($name, 8 , $length);
        # code...

        $qry = "SELECT * FROM GOODS WHERE PRODUCT_ID = " . ($id) ;
        $query = query($qry);

    oci_execute($query);
    echo $id;

    while ($row = oci_fetch_array($query)) {
        # code...
        $sub = $row['PRODUCT_PRICE']*$value;

        $item_quantity +=$value;
        $product_image = display_image($row['PRODUCT_IMAGE']);


        $product = <<<DELIMETER

        <tr>
                <td>{$row['PRODUCT_TITLE']}<br>

                <img width = '100' src='../resource/{$product_image}'>


                </td>
                <td>&pound;{$row['PRODUCT_PRICE']}</td>
                <td>{$value}</td>
                <td>&pound;{$sub}</td>
                <td>
                <a class='btn btn-warning' href="../resource/cart.php?remove={$row['PRODUCT_ID']}">
                <span class='glyphicon glyphicon-minus'>
                </span>
                </a>
                <a class='btn btn-success' href="../resource/cart.php?add={$row['PRODUCT_ID']}">
                <span class='glyphicon glyphicon-plus'>
                </span>
                </a>

                <a class='btn btn-danger'href="../resource/cart.php?delete={$row['PRODUCT_ID']}">
                <span class='glyphicon glyphicon-remove'>
                </span>
                </a>
                </td>
                  
              
        </tr>

        <input type="hidden" name="item_name_{$item_name}" value="{$row['PRODUCT_TITLE']}">
  <input type="hidden" name="item_number_{$item_number}" value="{$row['PRODUCT_ID']}">
  <input type="hidden" name="amount_{$amount}" value="{$row['PRODUCT_PRICE']}">
    <input type="hidden" name="quantity_{$quantity}" value="{$value}">



DELIMETER;
echo $product;

    $item_name ++;
    $item_number ++;
    $amount ++;
    $quantity ++;
  }

$_SESSION['item_total'] = $total += $sub;
$_SESSION['item_quantity'] = $item_quantity;




    }
  



    }


   

   }


    
}






















function order_customer(){
error_reporting(0);
    $total=0;
    $item_quantity=0;
    $item_name = 1;
    $item_number = 1;
    $amount = 1;
    $quantity = 1;
    $randome=mt_rand(10,1000000);
   foreach ($_SESSION as $name => $value) {
    if($value>0 && $value<4){

        //echo "*$name:= $value\n"; 

//echo " 1st value: $value   " ;
        if (substr($name, 0, 8) == "PRODUCT_") {

            $len = strlen($name );
            //$length = ($len - 8);
            $id = substr($name, 8 , $len);
        # code...

  //             $qry = query("SELECT CUSTOMER_ID FROM CUSTOMER WHERE SEE = '4' ");
  // oci_execute($qry);
  // while ($row = oci_fetch_array($qry) ) {

  //   $a=$row['CUSTOMER_ID'];

  // }




        $qry = "SELECT * FROM GOODS WHERE PRODUCT_ID = " . ($id) . " ";

        //echo $id;

confirm($qry);
      $qry_goods=query($qry);
    oci_execute($qry_goods);


    while ($row = oci_fetch_array($qry_goods)) {
        # code...
        $sub = $row['PRODUCT_PRICE']*$value;

        $item_quantity +=$value;
        $product_image = display_image($row['PRODUCT_IMAGE']);



if (isset($_GET['CUSTOMER_ID'])) {
    # code...
    //echo "hard";
    $pp= $row['PRODUCT_PRICE'];
    $pt= $row['PRODUCT_TITLE'];
    $pi= $row['PRODUCT_ID'];
    
    $a = $_GET['CUSTOMER_ID'];
    $cust_date = date("Y/m/d");
    

     $query = query("INSERT INTO CUSTOMER_ORDER (PRODUCT_NAME, PRICE, QUANTITY, CUSTOMER_ID,  PRODUCT_ID, IMAGE, INVOICE, ORDER_DATE) VALUES('{$pt}', '{$pp}', '{$value}', '{$a}', '{$pi}', '{$product_image}', '{$randome}', '{$cust_date}')");

    oci_execute($query);

    

    $query = query(" SELECT * FROM GOODS WHERE PRODUCT_ID = '$pi'");
    oci_execute($query);

//  confirm($query);//to confirm the query is working

    while ($row = fetch_array($query)) {

        $pro = $row['PRODUCT_QUANTITY'];
        $project = $row['PRODUCT_ID'];
    }

    
//echo $pro;
//echo $project;

                $val = $pro-$value;
  //              echo $val;
    //            echo $pi;
                $st = "UPDATE GOODS SET PRODUCT_QUANTITY = '$val' WHERE PRODUCT_ID = '$project' ";
                $qry = query($st);

                oci_execute($qry);
           



} 



  
    $item_name ++;
    $item_number ++;
    $amount ++;
    $quantity ++;
  }

$_SESSION['item_total'] = $total += $sub;
$_SESSION['item_quantity'] = $item_quantity;

session_destroy();



    }
  



    }


   

   }





    
}



function order_display(){




    $query = query(" SELECT * FROM CUSTOMER WHERE SEE=4");
    oci_execute($query);

//  confirm($query);//to confirm the query is working

    while ($row = fetch_array($query)) {

        $any = $row['CUSTOMER_ID'];

    }


       

     $query = query(" SELECT * FROM CUSTOMER_ORDER WHERE CUSTOMER_ID = $any");
    oci_execute($query);

//  confirm($query);//to confirm the query is working

    while ($row = fetch_array($query)) {

    $pr = $row['PRICE'];
    $qty = $row['QUANTITY'];
    $tot = $pr * $qty ;
    $prod = $row['PRODUCT_ID'];
    $img = $row['IMAGE'];
    $cust_date = $row['ORDER_DATE'];



    $product = <<<DELIMETER

        <tr>
                <td>{$row['PRODUCT_NAME']}<br>
                <img width = '100' src='../resource/{$img}'>


                </td>
                <td>&pound;{$row['PRICE']}</td>
                <td>{$row['QUANTITY']}</td>
                <td>{$tot}</td>
                <td>{$cust_date}</td>
                
              
        </tr>


DELIMETER;
echo $product;

echo $pro;

    }









}




















function report(){


    if(isset($_GET['tx'])) {

        $amount = $_GET['amt'];
        $currency = $_GET['cc'];
        $transaction = $_GET['tx'];
        $status = $_GET['st'];


        
        $send_order = query("INSERT INTO BOOK (ORDER_AMOUNT, ORDER_TRANSACTION, ORDER_STATUS, ORDER_CURRENCY) VALUES('{$amount}', '{$transaction}','{$status}','{$currency}')");

                    oci_execute($send_order);





    $total=0;
    $item_quantity=0;
    

   foreach ($_SESSION as $name => $value) {
       # code...

    if($value>0){


        if (substr($name, 0, 8) == "PRODUCT_") {

            $len = strlen($name );
            $length = ($len - 8);
            $id = substr($name, 8 , $length);
        # code...

        $query = query("SELECT * FROM GOODS WHERE PRODUCT_ID = " . ($id));
    oci_execute($query);

    while ($row = fetch_array($query)) {
        # code...
        $sub = $row['PRODUCT_PRICE']*$value;
        $product_price = $row['PRODUCT_PRICE'];
        $product_title = $row['PRODUCT_TITLE'];

        $item_quantity +=$value;

        $insert_report = query("INSERT INTO REPORT (PRODUCT_ID, PRODUCT_PRICE, PRODUCT_QUANTITY, PRODUCT_TITLE) VALUES('{$id}', '{$product_price}','{$value}','{$product_title}')");

                    oci_execute($insert_report);
 }
 $total += $sub;
 $item_quantity;

   


}
    }
  


    }

   //    session_destroy();

   }else{
        header("Location: index.php");
    }


    
}






function collection(){
    date_default_timezone_set("Asia/Kathmandu");

$a = date("Y/m/d");
$b = date("l");
$c = date("h:i:sa");

//echo "Today is " . $a . "<br>";
//echo "Today is " . $b . "<br>";
//echo "The time is " . $c;

if ($b == "Sunday" || $b == "Monday" || $b =="Tuesday") {
  # code...
//echo $f; 
    $day1=<<<SPLIT
                        <option value="Wednesday">Wednesday</option>
                        <option value="Thursday">Thursday</option>
                        <option value="Friday">Friday</option>
 
SPLIT;
echo $day1;

} else if($b == "Wednesday") {
  # code...
  $day2=<<<SPLIT
                        
                        <option value="Thursday">Thursday</option>
                        <option value="Friday">Friday</option>
 
SPLIT;
echo $day2;
} else if($b == "Thursday") {
  # code...
  $day1=<<<SPLIT
                        <option value="Friday">Friday</option>
                        <option value="Wednesday">Wednesday</option>
                        
 
SPLIT;
echo $day1;
} else if($b == "Friday") {
  # code...
  $day1=<<<SPLIT
                        <option value="Wednesday">Wednesday</option>
                        <option value="Thursday">Thursday</option>
                        
                        
                         
SPLIT;
echo $day1;
} else{
$day1=<<<SPLIT
                        <option value="Wednesday">Wednesday</option>
                        <option value="Thursday">Thursday</option>
                        <option value="Friday">Friday</option>
 
SPLIT;
echo $day1;
}

}



function timer(){

    $b = date("l");
    $c = date("h G");

    if ($b == "Sunday" || $b == "Monday" || $b =="Tuesday" || $b == "Saturday") {

        $d5=<<<SPLIT
                        <option value="10 to 13">10 a.m to 1 p.m</option>
                        <option value="13 to 16">1 p.m to 4 p.m</option>
                        <option value="16 to 19">4 p.m to 7p.m</option>
 
SPLIT;
echo $d5;

    } else{

        if ($c > "18" || $c < "10"){

    $d1=<<<SPLIT
                        <option value="10 to 13">10 a.m to 1 p.m</option>
                        <option value="13 to 16">1 p.m to 4 p.m</option>
                        <option value="16 to 19">4 p.m to 7p.m</option>
 
SPLIT;
echo $d1;

} elseif ($c < 13) {
    # code...
     $d2=<<<SPLIT
                        <option value="13 to 16">1 p.m to 4 p.m</option>
                        <option value="16 to 19">4 p.m to 7p.m</option>
 
SPLIT;
echo $d2;
}elseif ($c < 16) {
    # code...
    $d3=<<<SPLIT
                        <option value="16 to 19">4 p.m to 7p.m</option>
 
SPLIT;
echo $d3;
}
    }

  

}


function data_collection(){
    if(isset($_POST['collection'])){

    $day       = $_POST['day'];
    $time       = $_POST['timing'];
    $query = query("SELECT * FROM CUSTOMER WHERE SEE = '4' ");
    oci_execute($query);

    while ($row = oci_fetch_array($query)) {
        $asd = $row['CUSTOMER_ID'];
    
    }   
    
    $query = query("INSERT INTO COLLECTION_SLOT (COLLECTION_DAY, COLLECTION_TIME, CUSTOMER_ID) VALUES ('$day', '$time', '$asd')");
    oci_execute($query);
    } 

}



function invoice_customer(){


        if (isset($_GET['INVOICE'])) {
    # code...

             $s=$_GET['CUSTOMER_ID'];
             $t=$_GET['INVOICE'];
$qry = "SELECT * FROM CUSTOMER_ORDER WHERE INVOICE = '$t' ";
$query=query($qry);
oci_execute($query);
while ($row = fetch_array($query)) {

        $invoice_id = $row['INVOICE'];
        $invoice_d = $row['ORDER_ID'];

        }

        $qry = "SELECT * FROM CUSTOMER WHERE CUSTOMER_ID = $s";
$query=query($qry);
oci_execute($query);
while ($row = fetch_array($query)) {

        $in = $row['CUSTOMER_NAME'];
        $inv = $row['CUSTOMER_EMAIL'];

        }


 


   $detail = <<<DELIMETER

        <tr>
                <td style="font-weight: bold;">Invoice: {$invoice_id}</td>
                <td style="font-weight: bold;">Customer Name: {$in}</td>
                <td style="font-weight: bold;">Customer Email: {$inv}</td>
                
              
        </tr>


DELIMETER;
echo $detail;




//echo $s;
// echo $cust_id;
// echo "string";
// echo $invoice_d;
//header("Location: invoice.php");

        

    }else{
        echo "fail!!! Please try again";
    }


//         $query = query("SELECT * FROM CUSTOMER WHERE SEE = '4'");
// while ($row = fetch_array($query)) {

//         $cust_id = $row['CUSTOMER_ID'];

//         }
// echo $cust_id;

       

}



function invoice_customer_filling(){


        if (isset($_GET['INVOICE'])) {
    # code...
$item_total=0;
$total=0;
             $s=$_GET['CUSTOMER_ID'];
             $t=$_GET['INVOICE'];
$qry = "SELECT * FROM CUSTOMER_ORDER WHERE INVOICE = '$t'";
$query=query($qry);
oci_execute($query);
while ($row = fetch_array($query)) {

        $pro_id = $row['PRODUCT_ID'];
        $qty = $row['QUANTITY'];
        $pn = $row['PRODUCT_NAME'];
        $pr = $row['PRICE'];
        $mul = $qty * $pr;
        

        $total+=$mul;
        


   $detail = <<<DELIMETER

        <tr>
                <td >{$pn}</td>
                <td >{$pr}</td>
                <td >{$qty}</td>
                <td >{$mul}</td>
                
              
        </tr>
        
        


DELIMETER;
echo $detail;

        
}

 $details = <<<DELIMETER

        <tr>
                <td style="font-weight: bold;">Total</td>
                <td ></td>
                <td ></td>
                <td style="font-weight: bold;" >{$total}</td>
                
              
        </tr>
        
        


DELIMETER;
echo $details;

//echo $total;
    }else{
        echo "fail!!! Please try again";
    }
   

}



function invoice_date(){

$cust_date = date("Y/m/d");

   $detail = <<<DELIMETER

        <tr>
                <td style="font-weight: bold;"></td>
                <td style="font-weight: bold;"></td>
                <td style="font-weight: bold;"></td>
                <td style="font-weight: bold;"></td>
                <td style="font-weight: bold;"></td>
                <td style="font-weight: bold;"></td>
                                <td style="font-weight: bold;"></td>
                <td style="font-weight: bold;"></td>
                <td style="font-weight: bold;"></td>
                                <td style="font-weight: bold;"></td>
                <td style="font-weight: bold;"></td>
                <td style="font-weight: bold;"></td>
                                <td style="font-weight: bold;"></td>
                <td style="font-weight: bold;"></td>
                <td style="font-weight: bold;"></td>                
                <td style="font-weight: bold;">Issue Date: {$cust_date}</td>
                
              
        </tr>


DELIMETER;
echo $detail;
        

}


?>
