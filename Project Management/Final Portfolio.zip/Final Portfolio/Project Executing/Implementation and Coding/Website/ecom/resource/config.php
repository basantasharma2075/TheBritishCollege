 <?php

ob_start();

session_start();
//session_destroy();


defined("DS") ? null : define ("DS", DIRECTORY_SEPARATOR);

defined("TEMPLATE_BACK") ? null : define ("TEMPLATE_BACK", __DIR__ .DS. "templates/back");
defined("TEMPLATE_FRONT") ? null : define ("TEMPLATE_FRONT", __DIR__ .DS. "templates/front");


defined("UPLOAD_DIRECTORY") ? null : define ("UPLOAD_DIRECTORY", __DIR__ .DS. "uploads");


defined("DB_HOST") ? null : define ("DB_HOST", "localhost");
defined("DB_USER") ? null : define ("DB_USER", "ADMIN");
defined("DB_PASS") ? null : define ("DB_PASS", "9845634510");
defined("DB_NAME") ? null : define ("DB_NAME", "ECOM_DATABASE");

$connection=oci_connect('ECOM_DATABASE','9845634510','//localhost/xe');
require_once ("functions.php");
require_once ("cart.php");



?>