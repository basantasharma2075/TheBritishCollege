
                    <div class="col-lg-12">
                      

                        <h1 class="page-header">
                            Traders
                         
                        </h1>
                          <p class="bg-success">
                         
                        </p>



                        <div class="col-md-12">

                            <table class="table table-hover">
                                <thead>
                                    <tr>

                                        <th>Id</th>
                                        <th>Trader Name</th>
                                        <th>Email</th>
                                        <th>Shop Name</th>
                                        <th>Categories</th>
                            
                                    </tr>
                                </thead>
                                <tbody>

                                        <?php display_trader(); ?>


                                    
                                </tbody>
                            </table> <!--End of Table-->
                        

                        </div>

                        
                    </div>
    


