    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="js/bootstrap.min.js" rel="stylesheet">
    <link href="js/jquery.js" rel="stylesheet">


<link rel="stylesheet" type="text/css" href="foot.css">

<div class="container well" style="background-color: #FFE4B5;" >
    <h2><center>Contact Info</center></h2>
</div>
<div id="footer" style="background-color: #EEE8AA;">
    <div class="container">
        <div class="row">
            <h3 class="footertext">About Us:</h3>
            <br>
              <div class="col-md-3">
                <center>
                  <img src="../resource/templates/front/image/AddressIcon.png" style="height: 80px;">
                  <br>
                  <h4 class="footertext">Address</h4>
                  <p class="footertext">Everest Hotel<br></p>
                  <p class="footertext">New Baneshwor<br></p>
                  <p class="footertext">Xaku Baku<br></p>
                  <p class="footertext">Marga<br></p>
                </center>
              </div>
              <div class="col-md-3">
                <center>
                  <img src="../resource/templates/front/image/team.jpg" style="height: 80px;">
                  <br>
                  <h4 class="footertext">Prepared Team</h4>
                  <p class="footertext">Basanta Timilsena<br></p>
                  <p class="footertext">Dipesh Panjiyar Tharu<br></p>
                  <p class="footertext">Sanjaya Sujaku<br></p>
                  <p class="footertext">Renu Dahal<br></p>
                </center>
              </div>
              <div class="col-md-3">
                <center>
                  <img src="../resource/templates/front/image/contact.jpg" style="height: 80px;">
                  <br>
                  <h4 class="footertext">Contact Information</h4>
                  <p class="footertext">Email: atnasab.dimond@gmail.com<br></p>
                  <p class="footertext">Phone: 9845634510<br></p>
                  <p class="footertext">Email: chari.atnasab@gmail.com<br></p>
                </center>



              </div>
              <div class="col-md-3">
                <center>
                  <img src="../resource/templates/front/image/follow.jpg" style="height: 80px;">
                  <br>
                  <h4 class="footertext">Follow Us</h4>
                  <p class="footertext"><a href="www.facebook.com">Facebook<br></a></p>
                  <p class="footertext"><a href="www.facebook.com">Instagram<br></a></p>
                  <p class="footertext"><a href="www.facebook.com">Twitter<br></a></p>
                  <p class="footertext"><a href="www.facebook.com">Linkidein<br></a></p>
                </center>
              </div>
            </div>
            <div class="row">
            <p><center> <p class="footertext">Copyright 2019</p></center></p>
        </div>
    </div>
</div>