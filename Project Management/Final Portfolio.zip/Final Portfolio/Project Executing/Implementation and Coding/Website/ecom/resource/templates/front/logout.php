<?php require_once("../../config.php"); ?>

<?php
//include("../../public/checkout.php");
session_start();

$st = "UPDATE CUSTOMER SET SEE = '0' ";
$qry = query($st);
oci_execute($qry);

session_destroy();
header("Location: ../../../index.php");


?>