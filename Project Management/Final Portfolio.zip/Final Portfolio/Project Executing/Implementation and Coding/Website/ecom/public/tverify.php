
<?php require_once("../resource/config.php"); ?>
<?php include(TEMPLATE_FRONT . DS . "header.php"); ?>


<?php

if (isset($_GET['key'])) {
    # code...
		$st = "UPDATE TRADER SET VERIFY = '1' WHERE TRADER_ID = (SELECT max(TRADER_ID) FROM TRADER) ";

		$qry = query($st);
		oci_execute($qry);
		header("Location: ../index.php");

    }else{
    	echo "fail!!! Please try again";
    }

?>