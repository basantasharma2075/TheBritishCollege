<?php

//require_once("../resource/connect.php");
require_once("../resource/config.php");
include (TEMPLATE_FRONT . DS . "header.php");
//include ("../resource/templates/front/header.php");

?>


<?php

  if (isset($_POST['submit'])){

  //retriving the form data


  $UserName=$_POST['UserName'];
  $pass=$_POST['Password'];
  $cpass=$_POST['CPassword'];
  //$role = 1;
  $Email=$_POST['Email'];
  $shop = $_POST['shop'];
  $sn = $_POST['sn'];
  
  
extract($_POST);

  if (isset($_POST['tcheck'])) {

  if(!empty($UserName) && !empty($Password) && !empty($CPassword) && !empty($Email) && !empty($sn)){


    if(strcasecmp($pass, $cpass) != 0) //|| (strcasecmp($Password, $UserName) != 0)
    {
      

      echo "Please confirm the password";

    }

    else{
      
           $query=query("INSERT INTO TRADER (TRADER_NAME, TRADER_PASSWORD, TRADER_EMAIL, SHOP_NAME,
           CAT_ID, ROLE, SESS_ID) VALUES ('$UserName', '$pass','$Email', '$sn', '$shop', '2', '0')");
      //require_once("../resource/config.php");
      $q = oci_execute($query);
      echo "Data Submitted"; 

      if($q){

        $to = $Email;
        $subject = 'Signup | confirmation';
        $message = 'Thanks for being Trader of our S-Mart
        <a href="http://localhost/ecom/public/tverify.php?key=$to"></a>

        ';

        $head='from: atnasab.dimond@gmail.com';
        $z=mail($to,$subject,$message,$head);


      }


      }
}


 } else {
                $confirm = 'Terms and Condition not Agreed<br />';
                echo  $confirm;

            }
  


}

?>



<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    

    <title>Signup</title>

    <!-- Bootstrap core CSS 
    <link href="dist/css/bootstrap.min.css" rel="stylesheet">


    Custom styles for this template 
    <link href="navbar.css" rel="stylesheet">-->
  </head>

  <body>
 <div class="container">
   <form method="POST" name="regUser" action="" enctype="multipart/form-data">
  <fieldset>
    <legend>Register Form for Trader</legend>

    
    <div class="form-group">


    <label>TraderName</label>
    <input class="form-control" type="text" name="UserName" value ="<?php if(isset($_POST['submit']) && $_POST['UserName'])echo $_POST['UserName']?>">

    <div>
      <?php
        if(isset($_POST['submit'])){
          if(empty($_POST['UserName'])){
            echo "User Name is missing";
          }
        }
       ?>
    
    </div>


</div>
    <div class="form-group">

    <label>Password</label>
    <input class="form-control" type="password" name="Password">

    <div>
      <?php
        if(isset($_POST['submit'])){
          if(empty($_POST['Password'])){
            echo "Password is missing";
          }
        }
       ?>
    
    </div>
    

</div>
    <div class="form-group">

    <label>Confirm Password</label>
    <input class="form-control" type="password" name="CPassword">

    <div>
      <?php
        if(isset($_POST['submit'])){
          if(empty($_POST['CPassword'])){
            echo "Confirm Password is missing";
          }
        }
       ?>
    
    </div>
    
  
</div>
    <div class="form-group">
    <label>Email</label>
    <input class="form-control" type="email" name="Email" value ="<?php if(isset($_POST['submit']) && $_POST['Email'])echo $_POST['Email']?>">

    <div>
      <?php
        if(isset($_POST['submit'])){
          if(empty($_POST['Email'])){
            echo "Email is missing";
          }
        }
       ?>
    
    </div>
    
</div>

    <div class="form-group">
    <label>Shop Name</label>
    <input class="form-control" type="text" name="sn" value ="<?php if(isset($_POST['submit']) && $_POST['sn'])echo $_POST['sn']?>">

    <div>
      <?php
        if(isset($_POST['submit'])){
          if(empty($_POST['sn'])){
            echo "Shop Name is missing";
          }
        }
       ?>
    
    </div>
    
</div>


 <div class="form-group">

    <label>Shop Type </label>


  <select name="shop" class="form-control">
    <option value="">Select Category</option>
            <?php show_categories_add_product_page(); ?>
    
  </select> 
            
  
  </div>



    
<label for="">Terms and condition: </label>
    <input type="checkbox" name="tcheck" value="agree"><br />

    
  

  <br>
  <br>

  <button class="btn btn-primary" type="submit" name="submit" value="Register">Submit</button>

  </fieldset>

</form>

 </div>
 
</div>
  </body>
</html>