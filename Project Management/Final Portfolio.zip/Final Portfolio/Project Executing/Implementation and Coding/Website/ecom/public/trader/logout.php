<?php require_once("../../resource/config.php"); ?>
<?php
session_start();

$st = "UPDATE TRADER SET SESS_ID = '0' ";
$qry = query($st);
oci_execute($qry);

session_destroy();
header("Location: ../../../ecom");

?>