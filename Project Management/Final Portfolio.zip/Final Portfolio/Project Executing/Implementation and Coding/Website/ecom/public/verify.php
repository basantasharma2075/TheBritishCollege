
<?php require_once("../resource/config.php"); ?>
<?php include(TEMPLATE_FRONT . DS . "header.php"); ?>


<?php

if (isset($_GET['key'])) {
    # code...
		$st = "UPDATE CUSTOMER SET VERIFY = '1' WHERE CUSTOMER_ID = (SELECT max(CUSTOMER_ID) FROM CUSTOMER) ";

		$qry = query($st);
		oci_execute($qry);
		header("Location: ../index.php");

    }else{
    	echo "fail!!! Please try again";
    }

?>