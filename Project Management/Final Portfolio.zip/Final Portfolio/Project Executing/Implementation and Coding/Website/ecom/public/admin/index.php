 
<?php require_once("../../resource/config.php"); ?>
<?php
include (TEMPLATE_BACK . "/header.php");
?>

<?php

if (!isset($_SESSION['EMAIL'])) {
    # code...
    header("Location: ../../public");
//    header("Location: admin");
}

?>



        <div id="page-wrapper">

            <div class="container-fluid">

                <!-- Page Heading -->
                <div class="row">
                    <div class="col-lg-12">
                        <h1 class="page-header">
                            Dashboard <small>Admin Management</small>
                        </h1>
                        <ol class="breadcrumb">
                            <li class="active">
                                <i class="fa fa-dashboard"></i> Dashboard
                            </li>
                        </ol>
                    </div>
                </div>
                <!-- /.row -->

                <?php

                if($_SERVER['REQUEST_URI'] == "/ecom/public/admin/" || $_SERVER['REQUEST_URI'] == "/ecom/public/admin/index.php"){

                    include (TEMPLATE_BACK . "/admin_content.php");

                }

                if (isset($_GET['orders'])) {
                    # code...

                    include (TEMPLATE_BACK . "/orders.php");


                }

                if (isset($_GET['categories'])) {
                    # code...

                    include (TEMPLATE_BACK . "/categories.php");


                }

                if (isset($_GET['products'])) {
                    # code...

                    include (TEMPLATE_BACK . "/products.php");


                }

                if (isset($_GET['add_product'])) {
                    # code...

                    include (TEMPLATE_BACK . "/add_product.php");


                }

                if (isset($_GET['edit_product'])) {
                    # code...

                    include (TEMPLATE_BACK . "/edit_product.php");


                }

                if (isset($_GET['users'])) {
                    # code...

                    include (TEMPLATE_BACK . "/users.php");


                }



                if (isset($_GET['add_user'])) {
                    # code...

                    include (TEMPLATE_BACK . "/add_user.php");


                }


                if (isset($_GET['edit_user'])) {
                    # code...

                    include (TEMPLATE_BACK . "/edit_user.php");


                }

                if (isset($_GET['trader'])) {
                    # code...

                    include (TEMPLATE_BACK . "/trader.php");


                }



                if (isset($_GET['add_trader'])) {
                    # code...

                    include (TEMPLATE_BACK . "/add_trader.php");


                }


                if (isset($_GET['edit_trader'])) {
                    # code...

                    include (TEMPLATE_BACK . "/edit_trader.php");


                }

                if (isset($_GET['slides'])) {
                    # code...

                    include (TEMPLATE_BACK . "/slides.php");


                }

                if (isset($_GET['reports'])) {
                    # code...

                    include (TEMPLATE_BACK . "/reports.php");


                }


                if (isset($_GET['delete_slide_id'])) {
                    # code...

                    include (TEMPLATE_BACK . "/delete_slide.php");


                }

                






                ?>

                <!-- /.row -->

            </div>
            <!-- /.container-fluid -->

        </div>
        <!-- /#page-wrapper -->

    <?php
include (TEMPLATE_BACK . "/footer.php");
?>