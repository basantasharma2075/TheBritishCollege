<?php

//require_once("../resource/connect.php");
require_once("../resource/config.php");
include (TEMPLATE_FRONT . DS . "header.php");
//include ("../resource/templates/front/header.php");

?>

<?php

$query = query("SELECT * FROM CUSTOMER WHERE SEE = '4' ");
  oci_execute($query);

  while ($row = oci_fetch_array($query) ) {
    # code...
        
    $CUSTOMER_NAME           = $row['CUSTOMER_NAME'];
    $CUSTOMER_EMAIL          = $row['CUSTOMER_EMAIL'];
    $CUSTOMER_PASSWORD       = $row['CUSTOMER_PASSWORD'];
    $STATUS                  = $row['STATUS'];


  }

update_customer_detail();



?>



<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    

    <title>Signup</title>

    <!-- Bootstrap core CSS 
    <link href="dist/css/bootstrap.min.css" rel="stylesheet">


    Custom styles for this template 
    <link href="navbar.css" rel="stylesheet">-->
  </head>

  <body>
 <div class="container">
   <form method="POST" name="regUser" action="" enctype="multipart/form-data">
  <fieldset>
    <legend>Update Form for Customer</legend>

    
    <div class="form-group">


    <label>UserName</label>
    <input class="form-control" type="text" name="CUSTOMER_NAME" value ="<?php echo $CUSTOMER_NAME;?>">

    <div>
         
    </div>


</div>
    <div class="form-group">

    <label>Password</label>
    <input class="form-control" type="password" name="CUSTOMER_PASSWORD" value="<?php echo $CUSTOMER_PASSWORD;?>">

    <div>
    
    </div>
    

</div>
    <div class="form-group">

    <label>Account </label>


  <select name="STATUS" class="form-control">
    <option value="">Select Category</option>
           <option value="Active">Active</option>
    <option value="Deactive">Deactive</option>
    
  </select> 
            
 
</div>
    <div class="form-group">
    <label>Email</label>
    <input class="form-control" type="email" name="CUSTOMER_EMAIL" value ="<?php echo $CUSTOMER_EMAIL;?>" disabled>

    
</div>
    

  <br>
  <br>

  <button class="btn btn-primary" type="submit" name="submit" value="Register">UPDATE</button>

  </fieldset>

</form>

 </div>
  </body>
</html>