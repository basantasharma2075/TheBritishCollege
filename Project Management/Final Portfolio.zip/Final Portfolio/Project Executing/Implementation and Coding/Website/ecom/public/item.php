<?php

//require_once("../resource/connect.php");
require_once("../resource/config.php");
include (TEMPLATE_FRONT . DS . "header.php");
//include ("../resource/templates/front/header.php");

?>

    <!-- Navigation -->
   
    <!-- Page Content -->
<div class="container">

       <!-- Side Navigation -->

            <?php
            include (TEMPLATE_FRONT . DS . "side_nav.php");
            ?>

        <!---    <?php
  //          $query = query(" SELECT * FROM PRODUCT  ");
  //  oci_execute($query);

//  confirm($query);//to confirm the query is working

 //   while ($row = fetch_array($query)) {
        
   //     echo $row['PRODUCT_PRICE'];


    


                    ?>
                -->


   <!--             <?php


           //     oci_execute($query);

                //$query = query(" SELECT * FROM PRODUCT WHERE PRODUCT_ID= ". escape_string($GET['id']) . "");
     //           oci_execute($query);


   //             while ($row = fetch_array($query)) {
        
 //               echo $row['PRODUCT_PRICE'];


  //}





                ?>-->

                <?php
    $sta = "SELECT * FROM GOODS WHERE PRODUCT_ID ='$_GET[id]'";//setting the value to the query
  //              $sta = query(" SELECT * FROM PRODUCT WHERE PRODUCT_ID= ". escape_string($_GET['id']) . "");
    require_once("../resource/config.php");
 //   include('connection.php');//connecting to the database table
    $qry = oci_parse($connection, $sta);//comparing to the two query
    oci_execute($qry);
   // if($qry){//either a query is right or not
      while($row = oci_fetch_array($qry))://fetching the array

   // }
//} 
    ?>





<div class="col-md-9">

<!--Row For Image and Short Description-->

<div class="row">

    <div class="col-md-7">
       <img class="img-responsive" src="../resource/<?php echo display_image($row['PRODUCT_IMAGE']); ?>" alt="">

    </div>

    <div class="col-md-5">

        <div class="thumbnail">
         

    <div class="caption-full">
        <h4><?php echo $row['PRODUCT_TITLE']; ?> </h4>
        <hr>
        <h4 class=""><?php echo "&pound" . $row['PRODUCT_PRICE']; ?></h4>

    
          
        <?php echo $row['PRODUCT_SD']; ?>

   
    <form action="">
        <div class="form-group">
            <a href="../resource/cart.php?add=<?php echo$row['PRODUCT_ID']; ?>" class="btn btn-primary">ADD TO CART</a>

                       

        </div>
    </form>

    </div>
 
</div>

</div>


</div><!--Row For Image and Short Description-->


        <hr>


<!--Row for Tab Panel-->

<div class="row">

<div role="tabpanel">

  <!-- Nav tabs -->
  <ul class="nav nav-tabs" role="tablist">
    <li role="presentation" class="active"><a href="#home" aria-controls="home" role="tab" data-toggle="tab">Description</a></li>
    

  </ul>

  <!-- Tab panes -->
  <div class="tab-content">
    <div role="tabpanel" class="tab-pane active" id="home">

<p></p>
           
<?php echo $row['PRODUCT_SD']; ?>
<?php echo $row['PRODUCT_LD']; ?>

    </div>
    <div role="tabpanel" class="tab-pane" id="profile">

  <div class="col-md-6">

       <h3>2 Reviews From </h3>

        <hr>

        <div class="row">
            <div class="col-md-12">
                <span class="glyphicon glyphicon-star"></span>
                <span class="glyphicon glyphicon-star"></span>
                <span class="glyphicon glyphicon-star"></span>
                <span class="glyphicon glyphicon-star"></span>
                <span class="glyphicon glyphicon-star-empty"></span>
                Anonymous
                <span class="pull-right">10 days ago</span>
                <p>This product was great in terms of quality. I would definitely buy another!</p>
            </div>
        </div>

        <hr>

        <div class="row">
            <div class="col-md-12">
                <span class="glyphicon glyphicon-star"></span>
                <span class="glyphicon glyphicon-star"></span>
                <span class="glyphicon glyphicon-star"></span>
                <span class="glyphicon glyphicon-star"></span>
                <span class="glyphicon glyphicon-star-empty"></span>
                Anonymous
                <span class="pull-right">12 days ago</span>
                <p>I've alredy ordered another one!</p>
            </div>
        </div>

        <hr>

        <div class="row">
            <div class="col-md-12">
                <span class="glyphicon glyphicon-star"></span>
                <span class="glyphicon glyphicon-star"></span>
                <span class="glyphicon glyphicon-star"></span>
                <span class="glyphicon glyphicon-star"></span>
                <span class="glyphicon glyphicon-star-empty"></span>
                Anonymous
                <span class="pull-right">15 days ago</span>
                <p>I've seen some better than this, but not at this price. I definitely recommend this item.</p>
            </div>
        </div>

    </div>


    <div class="col-md-6">
        <h3>Add A review</h3>

     <form action="" class="form-inline">
        <div class="form-group">
            <label for="">Name</label>
                <input type="text" class="form-control" >
            </div>
             <div class="form-group">
            <label for="">Email</label>
                <input type="test" class="form-control">
            </div>

        <div>
            <h3>Your Rating</h3>
            <span class="glyphicon glyphicon-star"></span>
            <span class="glyphicon glyphicon-star"></span>
            <span class="glyphicon glyphicon-star"></span>
            <span class="glyphicon glyphicon-star"></span>
        </div>

            <br>
            
             <div class="form-group">
             <textarea name="" id="" cols="60" rows="10" class="form-control"></textarea>
            </div>

             <br>
              <br>
            <div class="form-group">
                <input type="submit" class="btn btn-primary" value="SUBMIT">
            </div>
        </form>

    </div>

 </div>

 </div>

</div>


</div><!--Row for Tab Panel-->




</div>


<?php endwhile; ?>



</div>
    <!-- /.container -->

   <?php 
include (TEMPLATE_FRONT . DS . "footer.php");
//include ("../resource/templates/front/header.php");
?>