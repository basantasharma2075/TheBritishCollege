 
<?php require_once("../../resource/config.php"); ?>
<?php
include (TEMPLATE_BACK . "/header_trader.php");
?>

<?php

if (!isset($_SESSION['EMAIL'])) {
    # code...
    header("Location: ../../public");
//    header("Location: admin");
}

?>



        <div id="page-wrapper">

            <div class="container-fluid">

                <!-- Page Heading -->
                <div class="row">
                    <div class="col-lg-12">
                        <h1 class="page-header">
                            Dashboard <small>Trader Management</small>
                        </h1>
                        <ol class="breadcrumb">
                            <li class="active">
                                <i class="fa fa-dashboard"></i> Dashboard
                            </li>
                        </ol>
                    </div>
                </div>
                <!-- /.row -->

                <?php

                if($_SERVER['REQUEST_URI'] == "/ecom/public/admin/" || $_SERVER['REQUEST_URI'] == "/ecom/public/trader/index.php"){

                    include (TEMPLATE_BACK . "/admin_content.php");

                }

                

                

                if (isset($_GET['products_trader'])) {
                    # code...

                    include (TEMPLATE_BACK . "/products_trader.php");


                }

                if (isset($_GET['add_product_trader'])) {
                    # code...

                    include (TEMPLATE_BACK . "/add_product_trader.php");


                }

                if (isset($_GET['edit_product'])) {
                    # code...

                    include (TEMPLATE_BACK . "/edit_product.php");


                }

                if (isset($_GET['offer_product_trader'])) {
                    # code...

                    include (TEMPLATE_BACK . "/offer_product_trader.php");


                }

                if (isset($_GET['view_offer'])) {
                    # code...

                    include (TEMPLATE_BACK . "/view_offer.php");


                }

                


                ?>

                <!-- /.row -->

            </div>
            <!-- /.container-fluid -->

        </div>
        <!-- /#page-wrapper -->

    <?php
include (TEMPLATE_BACK . "/footer.php");
?>