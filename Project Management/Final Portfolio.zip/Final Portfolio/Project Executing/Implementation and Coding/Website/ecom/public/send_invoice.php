<?php

	//require_once("../resource/connect.php");
	require_once("../resource/config.php");
	include (TEMPLATE_FRONT . DS . "header.php");
	//include ("../resource/templates/front/header.php");


?>


<?php 
    if (isset($_GET['INVOICE'])) {
    $none =	$_GET['CUSTOMER_ID'];
	$qry = "SELECT * FROM CUSTOMER WHERE CUSTOMER_ID = '$none' ";
	$query = query($qry);
	oci_execute($query);
	while ($row = oci_fetch_array($query) ) {

	$a=$row['CUSTOMER_EMAIL'];


	}


$to = $a;
$subject = "Invoice";

$cust_date = date("Y/m/d");

$s=$_GET['CUSTOMER_ID'];
             $t=$_GET['INVOICE'];
$qry = "SELECT * FROM CUSTOMER_ORDER WHERE INVOICE = '$t' ";
$query=query($qry);
oci_execute($query);
while ($row = fetch_array($query)) {

        $invoice_id = $row['INVOICE'];
        $invoice_d = $row['ORDER_ID'];

        }

        $qry = "SELECT * FROM CUSTOMER WHERE CUSTOMER_ID = $s";
$query=query($qry);
oci_execute($query);
while ($row = fetch_array($query)) {

        $in = $row['CUSTOMER_NAME'];
        $inv = $row['CUSTOMER_EMAIL'];

        }

        $item_total=0;
$total=0;
             $s=$_GET['CUSTOMER_ID'];
             $t=$_GET['INVOICE'];
$qry = "SELECT * FROM CUSTOMER_ORDER WHERE INVOICE = '$t'";
$query=query($qry);
oci_execute($query);
while ($row = fetch_array($query)) {

        $pro_id = $row['PRODUCT_ID'];
        $qty = $row['QUANTITY'];
        $pn = $row['PRODUCT_NAME'];
        $pr = $row['PRICE'];
        $mul = $qty * $pr;
        

        $total+=$mul;
    


$htmlContent = <<<SPLIT


<html>
    <head>
        <title>Invoice</title>
    </head>
    <body>
        <h1>Thanks you for Shopping</h1>
        <table cellspacing="0" style="border: 2px dashed #FB4314; width: 900px; height: 200px;">
            <tr>
                <th>Issue Date:</th><td>{$cust_date}</td>
            </tr>
            <tr style="background-color: #e0e0e0;">
                <th>Invoice:</th><td>{$invoice_id}</td>
            </tr>
            <tr>
                <th>Customer Name:</th><td>{$in}</td>
            </tr>
            <tr style="background-color: #e0e0e0;">
                <th>Customer Email:</th><td>{$inv}</td>
            </tr>
            <tr>
           <th>Product</th>
           <th>Price</th>
           <th>Quantity</th>
           <th>Sub-total</th>
     
          </tr>
          <tr>
                <th >{$pn}</th>
                <th >{$pr}</th>
                <th >{$qty}</th>
                <th >{$mul}</th>
                
              
        </tr>


        </table>
    </body>
    </html>';







SPLIT;



$headers = "MIME-Version: 1.0" . "\r\n";
$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";

// Additional headers
$headers .= 'From: CodexWorld<atnasab.dimond@gmail.com>' . "\r\n";
$headers .= 'Cc: atnasab.dimond@gmail.com' . "\r\n";
$headers .= 'Bcc: atnasab.dimond@gmail.com' . "\r\n";


mail($to,$subject,$htmlContent,$headers);
// Send email

header("Location: paypal_order.php");


}
	
}


?>