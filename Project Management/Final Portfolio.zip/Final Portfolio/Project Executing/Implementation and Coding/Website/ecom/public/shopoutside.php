<?php

//require_once("../resource/connect.php");
require_once("../resource/config.php");
include (TEMPLATE_FRONT . DS . "header_login.php");
//include ("../resource/templates/front/header.php");

?>



    <!-- Page Content -->
    <div class="container">

        <!-- Jumbotron Header -->
        <header>

        	<h1>SHOP</h1>
            
        </header>

        <hr>

        <!-- Title -->
        
        <div class="row text-center">

            <?php
            get_shop_outside();
            ?>

            

            
            

        </div>
        <!-- /.row -->


        <!-- Footer -->
       

    </div>
    <!-- /.container -->
<?php 
include (TEMPLATE_FRONT . DS . "footer.php");
//include ("../resource/templates/front/header.php");
?>
