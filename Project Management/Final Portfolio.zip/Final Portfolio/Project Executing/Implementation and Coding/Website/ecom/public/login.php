<?php

//require_once("../resource/connect.php");
require_once("../resource/config.php");
include (TEMPLATE_FRONT . DS . "header_login.php");
//include ("../resource/templates/front/header.php");

?>


    <!-- Page Content -->
    <div class="container" >

      <header>
            
            <h3><?php d_message();?></h3>

        <div class="col-sm-4"></div>
        <div class="col-sm-4" style="background-color: #F0FFF0; margin-bottom: 100px; height: 400px;">    
        <h1 class="text-center">Login</h1>     
            <form class="" action="" method="post" enctype="multipart/form-data">
                <?php

                get_login();

                ?>
                <div class="form-group"><label for="" style="margin-top: 30px; margin-left: 70px;">
                    User Name<input type="text" name="EMAIL" class="form-control" style="margin-top: 10px;"></label>
                </div>
                 <div class="form-group"><label for="password" style="margin-top: 30px; margin-left: 70px;">
                    Password<input type="password" name="PASSWORD" class="form-control" style="margin-top: 10px;"></label>
                </div>

                <div class="form-group">
                  <input type="submit" name="submit" class="btn btn-primary" style="margin-top: 30px; margin-left: 150px;" >
                </div>
            </form>
        </div>  
                <div class="col-sm-4"></div>



    </header>


        </div>

    </div>
    <!-- /.container -->

    <div class="container">


    </div>
    <!-- /.container -->
<?php 
include (TEMPLATE_FRONT . DS . "footer.php");
//include ("../resource/templates/front/header.php");
?>

