<?php

//require_once("../resource/connect.php");
require_once("../resource/config.php");
include (TEMPLATE_FRONT . DS . "header.php");
//include ("../resource/templates/front/header.php");


?>




    <!-- Page Content -->
    <div class="container">


<!-- /.row --> 

<div class="row">
  <h4 class="text-center bg-danger"><?php d_message(); ?></h4>

      <h1>Checkout</h1>

<form action="https://www.sandbox.paypal.com/cgi-bin/webscr" method="post">

   <input type="hidden" name="upload" value="1">
  <input type="hidden" name="cmd" value="_cart">
  <input type="hidden" name="business" value="atnasab.dimond-facilitator@gmail.com">
  <input type="hidden" name="currency_code" value="GBP">
  <?php 
  $query = query("SELECT CUSTOMER_ID FROM CUSTOMER WHERE SEE = '4' ");
  oci_execute($query);
  while ($row = oci_fetch_array($query) ) {

    $a=$row['CUSTOMER_ID'];

  }

    ?>
  <input type="hidden" name="return" value="http://localhost/ecom/public/paypal_order.php?CUSTOMER_ID=<?php echo $a;?>">
  <input type="hidden" name="cancel_return" value="http://localhost/ecom/public/index.php">  



    <table class="table table-striped">
        <thead>
          <tr>
           <th>Product</th>
           <th>Price</th>
           <th>Quantity</th>
           <th>Sub-total</th>
     
          </tr>
        </thead>
        <tbody>
            <?php cart(); ?>
        </tbody>
    </table>

    




<input type="image" name="upload" border="0"
    src="https://www.paypalobjects.com/en_US/i/btn/btn_buynow_LG.gif"
    alt="PayPal - The safer, easier way to pay online">
</form>

<?php
data_collection();
?>

<div class="col-xs-4 pull-left ">
<form method="POST" name="regUser" action="" enctype="multipart/form-data" style="height: 400px; width: 300px; background-color: #FAFAD2">

  <h2 style="text-align: center;">Collection slots</h2>
  <h3 style="text-align: center;">Day and Time</h3>
  <select name="day" class="form-control">
    <?php collection(); ?>
  </select> 

  <select name="timing" class="form-control" style="margin-top: 10px;">
    <?php timer(); ?>
  </select> 

  <button class="btn btn-primary" type="submit" name="collection" value="" style="margin-top: 10px; margin-bottom: 10px;">Submit</button>

</form>
</div>




<!--  ***********CART TOTALS*************-->
            
<div class="col-xs-4 pull-right ">
<h2>Cart Totals</h2>

<table class="table table-bordered" cellspacing="0">

<tr class="cart-subtotal">
<th>Items:</th>
<td><span class="amount">
   <?php

  echo isset($_SESSION['item_quantity']) ? $_SESSION['item_quantity'] : $_SESSION['item_quantity'] = "0";

  ?>
</span></td>
</tr>
<tr class="shipping">
<th>Shipping and Handling</th>
<td>Free Shipping</td>
</tr>

<tr class="order-total">
<th>Order Total</th>
<td><strong><span class="amount">&pound;
  
  <?php

  echo isset($_SESSION['item_total']) ? $_SESSION['item_total'] : $_SESSION['item_total'] = "0";

  ?>



</span></strong> </td>
</tr>


</tbody>

</table>

</div><!-- CART TOTALS-->


 </div><!--Main Content-->


    </div>
    <!-- /.container -->

    <?php 
include (TEMPLATE_FRONT . DS . "footer.php");
//include ("../resource/templates/front/header.php");
?>

