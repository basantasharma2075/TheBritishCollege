<?php

//require_once("../resource/connect.php");
require_once("../resource/config.php");
include (TEMPLATE_FRONT . DS . "header.php");
//include ("../resource/templates/front/header.php");


?>

<?php order_customer(); 
// invoice_customer();
?>



    <!-- Page Content -->
    <div class="container">


<!-- /.row --> 

<div class="row">
  <h4 class="text-center bg-danger"></h4>

      <h1>Order</h1>

      <form action="" method="post">

    <table class="table table-striped">
        <thead>
          <tr>
           <th>Product</th>
           <th>Price</th>
           <th>Quantity</th>
           <th>Sub-total</th>
           <th>Date</th>
     
          </tr>
        </thead>
        <tbody>

          
            <?php order_display(); ?>
        </tbody>
    </table>



</form>

<?php 
  $query = query("SELECT CUSTOMER_ID FROM CUSTOMER WHERE SEE = '4' ");
  oci_execute($query);
  while ($row = oci_fetch_array($query) ) {

    $a=$row['CUSTOMER_ID'];

  }

    ?>

    <?php 
  $qry = "SELECT * FROM CUSTOMER_ORDER WHERE ORDER_ID = (SELECT max(ORDER_ID) FROM CUSTOMER_ORDER)";
$query=query($qry);
oci_execute($query);
  while ($row = oci_fetch_array($query) ) {

    $b=$row['INVOICE'];

  }

    ?>

<a href="invoice.php?CUSTOMER_ID=<?php echo $a;?> & INVOICE=<?php echo $b;?>">
<button class="btn btn-primary" type="submit" name="invoice" value="" style="margin-top: 10px; margin-bottom: 10px;">Click here to view Invoice</button>
</a> 


<!--  ***********CART TOTALS*************-->
            

</div><!-- CART TOTALS-->


 </div><!--Main Content-->


    </div>
    <!-- /.container -->

    <?php 
include (TEMPLATE_FRONT . DS . "footer.php");
//include ("../resource/templates/front/header.php");
?>

