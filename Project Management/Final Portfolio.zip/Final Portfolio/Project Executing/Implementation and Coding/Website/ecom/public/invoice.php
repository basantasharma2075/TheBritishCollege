<?php

//require_once("../resource/connect.php");
require_once("../resource/config.php");
include (TEMPLATE_FRONT . DS . "header.php");
//include ("../resource/templates/front/header.php");


?>




    <!-- Page Content -->
    <div class="container">


<!-- /.row --> 

<div class="row">
  <h4 class="text-center bg-danger"></h4>

      <h1>Invoice</h1> 

  <?php 
  $query = query("SELECT CUSTOMER_ID FROM CUSTOMER WHERE SEE = '4' ");
  oci_execute($query);
  while ($row = oci_fetch_array($query) ) {

    $a=$row['CUSTOMER_ID'];

  }

    ?>

    <table class="table table-striped" style="margin-top: 20px; margin-bottom: 25px;">
        <thead>
        <?php invoice_date(); ?>
        </thead>
        <tbody>
            
        </tbody>
    </table>


    <table class="table table-striped" style="margin-top: 20px; margin-bottom: 25px;">
        <thead>
        <?php invoice_customer(); ?>
        </thead>
        <tbody>
            
        </tbody>
    </table>





    <table class="table table-striped" style="margin-top: 20px; margin-bottom: 125px;">
        <thead>
          <tr>
           <th>Product</th>
           <th>Price</th>
           <th>Quantity</th>
           <th>Sub-total</th>
     
          </tr>
        </thead>
        <tbody>
            <?php invoice_customer_filling(); ?>
        </tbody>
    </table>
  
</form>

<?php 
  $query = query("SELECT CUSTOMER_ID FROM CUSTOMER WHERE SEE = '4' ");
  oci_execute($query);
  while ($row = oci_fetch_array($query) ) {

    $a=$row['CUSTOMER_ID'];

  }

    ?>

    <?php 
  $qry = "SELECT * FROM CUSTOMER_ORDER WHERE ORDER_ID = (SELECT max(ORDER_ID) FROM CUSTOMER_ORDER)";
$query=query($qry);
oci_execute($query);
  while ($row = oci_fetch_array($query) ) {

    $b=$row['INVOICE'];

  }

    ?>

<a href="send_invoice.php?CUSTOMER_ID=<?php echo $a;?> & INVOICE=<?php echo $b;?>">
<button class="btn btn-primary" type="submit" name="invoice" value="" style="margin-top: 10px; margin-bottom: 10px;">Click here to email Invoice</button>
</a> 


<!--  ***********CART TOTALS*************-->
            


 </div><!--Main Content-->


    </div>
    <!-- /.container -->

    <?php 
include (TEMPLATE_FRONT . DS . "footer.php");
?>

