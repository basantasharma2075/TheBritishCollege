CREATE TABLE  "CAT" 
   (	"CAT_ID" NUMBER(8), 
	"CAT_TITLE" VARCHAR2(50), 
	 CONSTRAINT "CAT_PK" PRIMARY KEY ("CAT_ID") ENABLE
   )
/

CREATE OR REPLACE TRIGGER  "BI_CAT" 
  before insert on "CAT"               
  for each row  
begin   
  if :NEW."CAT_ID" is null then 
    select "CAT_SEQ".nextval into :NEW."CAT_ID" from sys.dual; 
  end if; 
end; 

/
ALTER TRIGGER  "BI_CAT" ENABLE
/

CREATE TABLE  "REGISTER" 
   (	"USER_ID" NUMBER(8,0), 
	"USER_NAME" VARCHAR2(255), 
	"USER_EMAIL" VARCHAR2(255), 
	"USER_PASSWORD" VARCHAR2(255), 
	"ROLE" VARCHAR2(50), 
	"USER_PHOTO" VARCHAR2(255), 
	 CONSTRAINT "REGISTER_PK" PRIMARY KEY ("USER_ID") ENABLE
   )
/

CREATE OR REPLACE TRIGGER  "BI_REGISTER" 
  before insert on "REGISTER"               
  for each row  
begin   
  if :NEW."USER_ID" is null then 
    select "REGISTER_SEQ".nextval into :NEW."USER_ID" from sys.dual; 
  end if; 
end; 

/
ALTER TRIGGER  "BI_REGISTER" ENABLE
/



CREATE TABLE  "CUSTOMER" 
   (	"CUSTOMER_ID" NUMBER(8,0), 
	"CUSTOMER_NAME" VARCHAR2(250), 
	"CUSTOMER_EMAIL" VARCHAR2(250), 
	"CUSTOMER_PASSWORD" VARCHAR2(250), 
	"ROLE" NUMBER(8,0), 
	"SEE" NUMBER(8,0), 
	"STATUS" VARCHAR2(255), 
	"VERIFY" NUMBER(8,0), 
	 CONSTRAINT "CUSTOMER_PK" PRIMARY KEY ("CUSTOMER_ID") ENABLE
   )
/

CREATE OR REPLACE TRIGGER  "BI_CUSTOMER" 
  before insert on "CUSTOMER"               
  for each row  
begin   
  if :NEW."CUSTOMER_ID" is null then 
    select "CUSTOMER_SEQ".nextval into :NEW."CUSTOMER_ID" from sys.dual; 
  end if; 
end; 

/
ALTER TRIGGER  "BI_CUSTOMER" ENABLE
/


CREATE TABLE  "GOODS" 
   (	"PRODUCT_ID" NUMBER(8,0), 
	"PRODUCT_TITLE" VARCHAR2(250), 
	"PRODUCT_PRICE" VARCHAR2(250), 
	"PRODUCT_SD" VARCHAR2(250), 
	"PRODUCT_IMAGE" VARCHAR2(250), 
	"PRODUCT_LD" VARCHAR2(250), 
	"PRODUCT_QUANTITY" VARCHAR2(250), 
	"CAT_ID" NUMBER(8,0), 
	 CONSTRAINT "GOODS_PK" PRIMARY KEY ("PRODUCT_ID") ENABLE
   )
/
ALTER TABLE  "GOODS" ADD CONSTRAINT "GOODS_FK" FOREIGN KEY ("CAT_ID")
	  REFERENCES  "CAT" ("CAT_ID") ENABLE
/

CREATE OR REPLACE TRIGGER  "BI_GOODS" 
  before insert on "GOODS"               
  for each row  
begin   
  if :NEW."PRODUCT_ID" is null then 
    select "GOODS_SEQ2".nextval into :NEW."PRODUCT_ID" from sys.dual; 
  end if; 
end; 

/
ALTER TRIGGER  "BI_GOODS" ENABLE
/


CREATE TABLE  "SLIDES" 
   (	"SLIDE_ID" NUMBER(8,0), 
	"SLIDE_TITLE" VARCHAR2(250), 
	"SLIDE_IMAGE" VARCHAR2(250), 
	 CONSTRAINT "SLIDES_PK" PRIMARY KEY ("SLIDE_ID") ENABLE
   )
/

CREATE OR REPLACE TRIGGER  "BI_SLIDES" 
  before insert on "SLIDES"               
  for each row  
begin   
  if :NEW."SLIDE_ID" is null then 
    select "SLIDES_SEQ".nextval into :NEW."SLIDE_ID" from sys.dual; 
  end if; 
end; 

/
ALTER TRIGGER  "BI_SLIDES" ENABLE
/


CREATE TABLE  "TRADER" 
   (	"TRADER_ID" NUMBER(8,0), 
	"TRADER_NAME" VARCHAR2(250), 
	"TRADER_EMAIL" VARCHAR2(250), 
	"TRADER_PASSWORD" VARCHAR2(250), 
	"SHOP_NAME" VARCHAR2(250), 
	"CAT_ID" NUMBER(8,0), 
	"ROLE" NUMBER(8,0), 
	"SESS_ID" NUMBER(8,0), 
	"VERIFY" NUMBER(8,0), 
	 CONSTRAINT "TRADER_PK" PRIMARY KEY ("TRADER_ID") ENABLE
   )
/
ALTER TABLE  "TRADER" ADD CONSTRAINT "TRADER_FK" FOREIGN KEY ("CAT_ID")
	  REFERENCES  "CAT" ("CAT_ID") ENABLE
/

CREATE OR REPLACE TRIGGER  "BI_TRADER" 
  before insert on "TRADER"               
  for each row  
begin   
  if :NEW."TRADER_ID" is null then 
    select "TRADER_SEQ3".nextval into :NEW."TRADER_ID" from sys.dual; 
  end if; 
end; 

/
ALTER TRIGGER  "BI_TRADER" ENABLE
/

CREATE TABLE  "CUSTOMER_ORDER" 
   (	"ORDER_ID" NUMBER(8,0), 
	"PRODUCT_NAME" VARCHAR2(250), 
	"PRICE" VARCHAR2(250), 
	"QUANTITY" VARCHAR2(250), 
	"CUSTOMER_ID" NUMBER(8,0), 
	"PRODUCT_ID" NUMBER(8,0), 
	"IMAGE" VARCHAR2(255), 
	 CONSTRAINT "CUSTOMER_ORDER_PK" PRIMARY KEY ("ORDER_ID") ENABLE
   )
/
ALTER TABLE  "CUSTOMER_ORDER" ADD CONSTRAINT "CUSTOMER_ORDER_FK" FOREIGN KEY ("CUSTOMER_ID")
	  REFERENCES  "CUSTOMER" ("CUSTOMER_ID") ENABLE
/
ALTER TABLE  "CUSTOMER_ORDER" ADD CONSTRAINT "CUSTOMER_ORDER_GOODS_FK" FOREIGN KEY ("PRODUCT_ID")
	  REFERENCES  "GOODS" ("PRODUCT_ID") ENABLE
/

CREATE OR REPLACE TRIGGER  "BI_CUSTOMER_ORDER" 
  before insert on "CUSTOMER_ORDER"               
  for each row  
begin   
  if :NEW."ORDER_ID" is null then 
    select "CUSTOMER_ORDER_SEQ2".nextval into :NEW."ORDER_ID" from sys.dual; 
  end if; 
end; 

/
ALTER TRIGGER  "BI_CUSTOMER_ORDER" ENABLE
/