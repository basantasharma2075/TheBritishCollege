package Assignment;

import java.util.Scanner;
import java.text.NumberFormat;
public class Project2 {
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		int i=100;
		//declaring the variable
		String[] title = new String[i];
		String[] author = new String[i];
		String[] publisher= new String[i];
		double[] price = new double[i];
		int[] isbn = new int[i];
		
		int j=0;
		Scanner in = new Scanner(System.in);
		char m;
		
		int t=0;
		double co=0;
		double ma, mi;
		double av;
		
		do
		{
			//taking the input from the user	
	
	    	System.out.print("Enter the title of the book: ");
		    title[j] = in.next();
		
		    System.out.print("Enter the author of the book: ");
    		author[j] = in.next();
		
    		System.out.print("Enter the publisher of the book: ");
    		publisher[j] = in.next();
		
    		System.out.print("Enter the price of the book: ");
    		price[j] = in.nextDouble();
    		
    		co=co+price[j];//finding the total cost of the book
		
    		System.out.print("Enter the isbn of the book: ");
    		isbn[j] = in.nextInt();
    		
    		t=j+1;	//finding the total number of the books
    		av=(co/t);// finding the average
    		
    		System.out.print("if you want to continue press 'Y' or 'y' else press any key: ");
		    m=in.next().charAt(0);
			 in.nextLine();
			 j++;//increment
		 }
		//user wish to continue or not
		 while(m=='y'||m=='Y');
		 {
			 System.out.println("");
			 System.out.println("Total");
			 System.out.println("==============================================================");
			
		 }
		 ma=price[0];
		 mi=price[0];
		 //finding the maximum or minimum price of the books
		 for(int k=0;k<j;k++)
		 {
			 
	    		if (price[k]>ma)
	    			ma=price[k];
			
	    		
	    		
	    		if (mi>price[k])
	    			mi=price[k];
		 }	
		 //Displaying the user input as output
		 System.out.println("total number of books:-\t"+t);
	   	 System.out.println("total cost of books:-\t$"+co);
	   	 System.out.println("maximum cost of book:-\t$"+ma);
	   	 System.out.println("minimum cost of book:-\t$"+mi);
	     System.out.println("average cost of book:-\t$"+av);		 
	   		 
	   	 
		 
	}


}
