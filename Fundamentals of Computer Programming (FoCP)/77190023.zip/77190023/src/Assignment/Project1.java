package Assignment;
import java.util.Scanner;
public class Project1 {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		int i=100;
		//declaring the variable
		String[] title = new String[i];
		String[] author = new String[i];
		String[] publisher= new String[i];
		
		int[] price = new int[i];
		int[] isbn = new int[i];
		
		int j=0;
		Scanner in = new Scanner(System.in);
		char m;
		do
		{
		//taking the input from the user	
	
			System.out.print("Enter the title of the book: ");
		    title[j] = in.next();
		
		    System.out.print("Enter the author of the book: ");
    		author[j] = in.next();
		
    		System.out.print("Enter the publisher of the book: ");
    		publisher[j] = in.next();
		
    		System.out.print("Enter the price of the book: ");
    		price[j] = in.nextInt();
    		
    		
    		System.out.print("Enter the isbn of the book: ");
    		isbn[j] = in.nextInt();
    		
    		System.out.print("if you want to continue press 'Y' or 'y' else press any key: ");
		    
    		m=in.next().charAt(0);
			 in.nextLine();
			
			 j++;//increment
			 
		}
		//user wish to continue or not
		while(m=='y'||m=='Y');
		 {
			 System.out.println("\nTitle \t     Author \t     Publisher \t     Price \t     ISBN ");
			 
		     System.out.println("=======================================================================");
	   	 	 
		 }
		 //displaying the user inputs
		 for(int k=0;k<j;k++)
	   	 {
	   		 System.out.println(title[k]+" \t     "+author[k]+" \t     "+publisher[k]+" \t     �"+price[k]+" \t     "+isbn[k]  );
	   	 }
		 
	}
}
