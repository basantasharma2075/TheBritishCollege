package ProjectC7190023;
import java.util.Scanner;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.regex.Pattern;
public class JavaC7190023 {
 		
	
	public static void main(String[] args)
	{
		
		
		//declaring the variable
		String  line = "";
		String title="";
		String author="";
		float price=0;
		String publisher="";
		double ISBN=0;
		int book=0;
		int valid=0, invalid=0;
		float total=0;
		Scanner keyboard = new Scanner (System.in);
		
		
		float max = Float.MIN_VALUE;  //declaring the smallest minimum value using function
        float min = Float.MAX_VALUE;  //declaring the maximum value using function
        
        //declaring the variable for average
        float average=0;
        String search;  //for search intializing the data type
        int choice;
       
		// Allow the user to enter the name of text file that the data is stored in
		System.out.println("This program will try to read data from a text file ");
		System.out.print("Type in the file name: ");
		String fileName = keyboard.nextLine();
	
		File Fileobject = new File ("over.txt");  //file name
		if (!Fileobject.exists()) //checking the file name exit or not
		{
			System.out.println("Error - File does not exist");
			System.exit(0);
		}
		
		
		// list of choice user want 
		System.out.println("press 1 to read from file: ");
		System.out.println("press 2 to Search from a book by title  : ");
		System.out.println("press 3 to List books by a particular author  : ");
		System.out.println("press 4 to List the book by keyword  : ");
		System.out.println("press 5 to print from html  : ");
		
	    choice = keyboard.nextInt(); 
	    switch(choice)
        {
        case 1:
		try {
			Scanner fileReader  = new Scanner (Fileobject);
			
			System.out.format("%-45s%-45s%-45s%-45s%-45s\n","Title","Author","Price","Publisher","isbn");
			
			/*System.out.println("\n"+String.format("%-45s",  "Title") +
					String.format("%-45s", "Author")+
					String.format("%-45s", "price")+
					String.format("%-45s", "Publisher")+
					String.format("%-45s", "ISBN"));
			*/
			while(fileReader.hasNext())
			{
				
				int w=0, x=0, y=0, z=0, v=0;  // to find valid or invalid  we declare all the value 0
				 line = fileReader.nextLine();// Read a line of data from text file
				
				// The format of each line of data in the text file is as follow: 
				//  title - author - price - publisher - isbn 
				// Need to split each line read from file before can process it
				 
				String [] splitArray = line.split("-");
				
				 int delime = 0; //setting delimeter counter
                 String[] del = line.split(" ");
                 for(String dc:del)
                 {
                     if (dc.equals("-")){
                         delime++;
                         
                     }
                 }
                     if(delime!=4)//checking if delimeter equals to 4
                     {
                      
                    	
                    	 invalid=invalid+1; //counting the invalid delimeter
                         System.out.println("\n"+String.format("%-45s", "delimeter is misssing")); //printing the line for delimeter missing
                         continue;
                         
                         
                     }
			
				// check to make sure there are 5 parts in splitArray 
				if(splitArray.length == 5)
				{
					// removing the spaces from the data
					splitArray[0]= splitArray[0].trim();
					splitArray[1]= splitArray[1].trim();
					splitArray[2] = (splitArray[2].trim());
					splitArray[3]= splitArray[3].trim();
					splitArray[4] =(splitArray[4].trim()) ;
					
					if (!splitArray[0].equals("")) {  //checking the title is missing or not
						title=splitArray[0];
						System.out.print(""+String.format("%-45s",splitArray[0]));
						v=v+1;  //counting the valid number of title 
						
					}
					else {
						System.out.print("title is missing"+String.format("%-29s",splitArray[0])); // if title is missing
						
					}
					
					if (!splitArray[1].equals("")) {  // checking the author is missing or not
						author=splitArray[1];
						System.out.print(""+String.format("%-45s",splitArray[1]));
						w=w+1; //counting the title is valid or not
						
					}
					else {
						
						System.out.print("author is missing"+String.format("%-28s",splitArray[1]));//incase of author is missing
					}
					
					if (splitArray[2].length() > 0 ) //checking price is number or not
						
						{
							try{
								// convert price to float value
								price = Float.valueOf(splitArray[2]);
								System.out.print(
												String.format("%-45s", price));
								x=x+1;//counting to calculate valid or not
								
							}
							catch(NumberFormatException e) { //if the price is not number
							     System.out.print("it is not numeric value\t\t\t");
							  
							}
					}
					else {
						System.out.print("price is missing"+String.format("%-45s",splitArray[2])); //in case of price is missed 
						
					}
					if (!splitArray[3].equals("")) {// checking the publisher is missing or not
						publisher=splitArray[3];
						System.out.print(""+String.format("%-45s",splitArray[3]));//displaying the output in correct format
						y=y+1;
						
					}
					else {
						System.out.print("publisher is missing"+String.format("%-26s",splitArray[3]));//printing the message when publisher is missing
						
					}
					
					if (splitArray[4].length() > 0 ) //checking isbn is empty or not
						
					{
						try{
							// convert isbn to double value
							ISBN = Double.valueOf(splitArray[4]);
							System.out.println(""+String.format("%-26s",splitArray[4] ));
							z=z+1;
							
						}
						catch(NumberFormatException e) {//when isbn is not in numeric format
						     System.out.println("The book ISBN may not be a numeric value.");
						   
						}
						
						
				}
					else {//in case isbn is missing
						System.out.println("isbn is missing"+String.format("%-45s",splitArray[4]));
						
					}
					
				}
				

				if(v==w &&  w==x && x==y&&  y==z && z==v) {//checking the variable is equall or not to find validity of book
				valid=valid+1;           //counting valid number of book
				book=valid;              //total number of valid book
				total=total+price;       //total price of valid book
				min = Math.min(min, price); //finding maximum and minimum 
	            max = Math.max(max, price);
	            average=total/book;    //average of the book
				}
			else {
			
				invalid=invalid+1; //counting invalid book
				
			
			}
				
				
			}
			
		}
	
		
	
		catch (IOException e) {
		// IO error while reading from the file.
		System.err.println("Error while reading from file ");
		}
		
		//printing the details of the book
		System.out.println(" ");
		System.out.println("Totals ");
		System.out.println("---------------------------------");
		System.out.println("Total number of book is: "+book);
		System.out.println("total is: "+total);
		System.out.println("max value is: "+max);
		System.out.println("min value is: "+min);
		System.out.println("average is: "+average);
		System.out.println("Total number of valid book is: "+valid);
		System.out.println("Total number of invalid book is: "+invalid);
		break;
		
        case 2:
        	
        	//searching the book by title
        	//creating the scanner
        	Scanner my = new Scanner (System.in);
    		System.out.println("enter a title you want to display: ");//taking input from user to display the title which user want to search
    	    search = my.nextLine();
    	    if (search.isEmpty()) {
    	    	System.out.println("please write something");
    	    	System.exit(0);
    	    }
    		
    		
    		try {
    			Scanner fileReader  = new Scanner (Fileobject);
    			
    			
    			// displaying the title in correct format using string.format
    			System.out.println("\n"+String.format("%-25s",  "Title") +
    					String.format("%-25s", "Author")+
    					String.format("%-25s", "price")+
    					String.format("%-25s", "Publisher")+
    					String.format("%-25s", "ISBN"));
    			
    			while(fileReader.hasNext())
    			{
    				
    				int w=0, x=0, y=0, z=0, v=0;//Declaring the variable 0
    				 line = fileReader.nextLine();// Read a line of data from text file
    				
    				// The format of each line of data in the text file is as follow: 
    				//  title - author - price - publisher - isbn
    				// Need to split each line read from file before can process it
    				 
    				String [] splitArray = line.split("-");
    				
    				 int dcount = 0;//setting delimiter counter
                     String[] del = line.split(" ");
                     for(String dd:del)
                     {
                         if (dd.equals("-")){
                             dcount++;//counting the delimeter
                             
                         }
                     }
                         if(dcount!=4)//checking if delimeter equals to 4
                         {
                          continue;
                             
                             
                         }
    			
    				// check to make sure there are 5 parts in splitArray 
    				if(splitArray.length == 5)
    				{
    					// Removing the spaces
    					splitArray[0]= splitArray[0].trim();
    					splitArray[1]= splitArray[1].trim();
    					splitArray[2] = (splitArray[2].trim());
    					splitArray[3]= splitArray[3].trim();
    					splitArray[4] =(splitArray[4].trim()) ;
    					
    					if (!splitArray[0].equals("")) {//checking the expression match or not to the title
    						title=splitArray[0];
    						v=v+1;
    						
    					}
    					
    					
    					if (!splitArray[1].equals("")) {//checking author is missing or not
    						author=splitArray[1];
    						
    						w=w+1;
    						
    					}
    					
    					
    					if (splitArray[2].length() > 0 ) //checking price is missing or not
    						
    						{
    							try{
    								// convert price to float value
    								price = Float.valueOf(splitArray[2]);
    								
    								x=x+1;
    								
    							}
    							catch(NumberFormatException e) {
    							     continue;
    							  
    							}
    					}
    					
    					if (!splitArray[3].equals("")) {//publisher is missing or not
    						publisher=splitArray[3];
    					
    						y=y+1;
    						
    					}
    					
    				
    					if (splitArray[4].length() > 0 ) //isbn is missing or not
    						
    					{
    						try{
    							// convert isbn to float value
    							ISBN = Double.valueOf(splitArray[4]);
    							
    							z=z+1;
    							
    						}
    						catch(NumberFormatException e) {
    						    continue ;
    						   
    						}
    						
    						
    				}
    			
    					
    				}
    				
    				//if(v==0 &&  w==0 && x==0&&  y==0 && z==0) {// checking all the variable is equall or not
    					//continue;
    				//}

    				if(v==1 &&  w==1 && x==1&&  y==1 && z==1) {// checking all the variable is equall or not
    					if(title.indexOf(search) != -1) //title you searching is available or not 
    		            {
    						//displaying the details of your search
    						System.out.print(""+String.format("%-25s",splitArray[0]));
    						System.out.print(""+String.format("%-25s",splitArray[1]));
    						System.out.print(""+String.format("%-25s",splitArray[2]));
    						System.out.print(""+String.format("%-25s",splitArray[3]));
    						System.out.println(""+String.format("%-25s",splitArray[4]));
    		                
    		                
    		            }
    				}
    					
    					
    				
    	            	
    			}
    			
    		}
    		catch (IOException e) {
    		// IO error while reading from the file.
    		System.err.println("Error while reading from file ");
    		}
    		break;
        
        case 3:
    		Scanner dash = new Scanner (System.in);
    		System.out.println("Enter a name of author to display: ");//taking the input from the user to search
    	    search = dash.nextLine();
    	    if (search.isEmpty()) {//if the search is missing it gives warning to the user
    	    	System.out.println("please write something");
    	    	System.exit(0);
    	    }
    		
    		try {
    			Scanner fileReader  = new Scanner (Fileobject);
    			
    			//displaying the title at the bottom
    			
    			System.out.println("\n"+String.format("%-25s",  "Title") +
    					String.format("%-25s", "Author")+
    					String.format("%-25s", "price")+
    					String.format("%-25s", "Publisher")+
    					String.format("%-25s", "ISBN"));
    			
    			while(fileReader.hasNext())
    			{
    				
    				int w=0, x=0, y=0, z=0, v=0;//Initializing the variable 0
    				 line = fileReader.nextLine();// Read a line of data from text file
    				
    				// The format of each line of data in the text file is as follow: 
    				//  title - author - price - publisher - isbn
    				// Need to split each line read from file before can process it
    				 
    				String [] splitArray = line.split("-");
    				
    				 int delimetercount = 0;//setting delimeter counter
                     String[] delimeter = line.split(" ");
                     for(String dd:delimeter)
                     {
                         if (dd.equals("-")){
                             delimetercount++;
                             
                         }
                     }
                         if(delimetercount!=4)//checking if delimeter equals to 4
                         {
                          continue;
                             
                             
                         }
    			
    				// check to make sure there are 2 parts in splitArray 
    				if(splitArray.length == 5)
    				{
    					// remove spaces
    					splitArray[0]= splitArray[0].trim();
    					splitArray[1]= splitArray[1].trim();
    					splitArray[2] = (splitArray[2].trim());
    					splitArray[3]= splitArray[3].trim();
    					splitArray[4] =(splitArray[4].trim()) ;
    					
    					if (!splitArray[0].equals("")) {//display the title
    						title=splitArray[0];
    						v=v+1;
    						
    					}
    					
    					
    					if (!splitArray[1].equals("")) {//display author
    						author=splitArray[1];
    						
    						w=w+1;
    						
    					}
    					
    					
    					if (splitArray[2].length() > 0 ) //checking the inputs is missing or not
    						
    						{
    							try{
    								// converting price to float value
    								price = Float.valueOf(splitArray[2]);
    								
    								x=x+1;
    								
    							}
    							catch(NumberFormatException e) {//non numeric data
    							     continue;
    							  
    							}
    					}
    					
    					if (!splitArray[3].equals("")) {//checking the publisher 
    						publisher=splitArray[3];
    					
    						y=y+1;
    						
    					}
    				
    					if (splitArray[4].length() > 0 ) //finding the inputs id missing or not 
    						
    					{
    						try{
    							// convert isbn to double value
    							ISBN = Double.valueOf(splitArray[4]);
    							
    							z=z+1;
    							
    						}
    						catch(NumberFormatException e) {//non integer value
    						    continue ;
    						   
    						}
    						
    						
    				}
    			
    					
    				}
    				

    				if(v==w &&  w==x && x==y&&  y==z && z==v) {//checking the valid of the book
    					if(author.indexOf(search) != -1)//finding the search is matching or not
    		            {
    						//displaying details of the book if search is match
    						System.out.print(""+String.format("%-25s",splitArray[0]));
    						System.out.print(""+String.format("%-25s",splitArray[1]));
    						System.out.print(""+String.format("%-25s",splitArray[2]));
    						System.out.print(""+String.format("%-25s",splitArray[3]));
    						System.out.println(""+String.format("%-25s",splitArray[4]));
    		                
    		                
    		            }
    				}
    					
    					
    				
    	            	
    			}
    			
    		}
    		catch (IOException e) {
    		// IO error while reading from the file.
    		System.err.println("Error while reading from file ");
    		}
    		break;
    		
    		
        case 4:
        	
        	//searching the book details by keyword
        	
        	
        	Scanner ddsh = new Scanner (System.in);
    		System.out.println("Enter any keyword to search from file: ");//taking the input from user to search
    	    search = ddsh.nextLine();
    		
    		
    		try {
    			Scanner fileReader  = new Scanner (Fileobject);
    			
    			
    			// displaying the title in correct format using string.format
    			System.out.println("\n"+String.format("%-25s",  "Title") +
    					String.format("%-25s", "Author")+
    					String.format("%-25s", "price")+
    					String.format("%-25s", "Publisher")+
    					String.format("%-25s", "ISBN"));
    			
    			while(fileReader.hasNext())
    			{
    				
    				int w=0, x=0, y=0, z=0, v=0;//Declaring the variable 0
    				 line = fileReader.nextLine();// Read a line of data from text file
    				
    				// The format of each line of data in the text file is as follow: 
    				//  title - author - price - publisher - isbn
    				// Need to split each line read from file before can process it
    				 
    				String [] splitArray = line.split("-");
    				
    				 int dcount = 0;//setting delimiter counter
                     String[] del = line.split(" ");
                     for(String dd:del)
                     {
                         if (dd.equals("-")){
                             dcount++;//counting the delimeter
                             
                         }
                     }
                         if(dcount!=4)//checking if delimeter equals to 4
                         {
                          continue;
                             
                             
                         }
    			
    				// check to make sure there are 5 parts in splitArray 
    				if(splitArray.length == 5)
    				{
    					// Removing the spaces
    					splitArray[0]= splitArray[0].trim();
    					splitArray[1]= splitArray[1].trim();
    					splitArray[2] = (splitArray[2].trim());
    					splitArray[3]= splitArray[3].trim();
    					splitArray[4] =(splitArray[4].trim()) ;
    					
    					if (!splitArray[0].equals("")) {//checking the expression match or not to the title
    						title=splitArray[0];
    						v=v+1;
    						}
    					
    					
    					
    					
    					
    					
    					
    					
    					
    					
    					
    					if (!splitArray[1].equals("")) {//checking author is missing or not
    						author=splitArray[1];
    						
    						w=w+1;
    						
    					}
    					
    					
    					if (splitArray[2].length() > 0 ) //checking price is missing or not
    						
    						{
    							try{
    								// convert price to float value
    								price = Float.valueOf(splitArray[2]);
    								
    								x=x+1;
    								
    							}
    							catch(NumberFormatException e) {
    							     continue;
    							  
    							}
    					}
    					
    					if (!splitArray[3].equals("")) {//publisher is missing or not
    						publisher=splitArray[3];
    					
    						y=y+1;
    						
    					}
    					
    				
    					if (splitArray[4].length() > 0 ) //isbn is missing or not
    						
    					{
    						try{
    							// convert isbn to float value
    							ISBN = Double.valueOf(splitArray[4]);
    							
    							z=z+1;
    							
    						}
    						catch(NumberFormatException e) {
    						    continue ;
    						   
    						}
    						
    						
    				}
    			
    					
    				}
    				
    				 Pattern p = Pattern.compile(" ");  //compiles the title word by word
    			        String[] result = 
    			                 p.split(title);     //Splitting the title one by one word
    			       // for (int i=0; i<result.length; i++)
    			        if(v==1 &&  w==1 && x==1&&  y==1 && z==1) {
    			            if (title.indexOf(search) != -1) {//finding either keyword is matching or not
    			            	System.out.print(""+String.format("%-25s",splitArray[0]));
    							System.out.print(""+String.format("%-25s",splitArray[1]));
    							System.out.print(""+String.format("%-25s",splitArray[2]));
    							System.out.print(""+String.format("%-25s",splitArray[3]));
    							System.out.println(""+String.format("%-25s",splitArray[4]));
    			            }
    			        }
    	            	
    			}
    			
    		}
    		catch (IOException e) {
    		// IO error while reading from the file.
    		System.err.println("Error while reading from file ");
    		}
        	
        	
    		break;
    		
    		
    		
        case 5:
        	
        	String html ="<!DOCTYPE html>\r\n" + 
        			"<html>\r\n" + 
        			"<head>\r\n" + 
        			"<style>\r\n" + 
        			"body{background-color:#d5dcf2;}\r\n" + 
        			"</style>\r\n" + 
        			"\r\n" + 
        			"<title>Java</title>\r\n" + 
        			"\r\n" + 
        			"<link rel=\"stylesheet\" href=\"project.css\">\r\n" + 
        			"\r\n" + 
        			"\r\n" + 
        			"</head>\r\n" + 
        			"\r\n" + 
        			"<body>\r\n" + 
        			" <div class=\"mainpage\">\r\n" + 
        			"\r\n" + 
        			"\r\n" + 
        			" <div class=\"header\">\r\n" + 
        			"  \r\n" + 
        			"  <h2>Books Information</h2>\r\n" + 
        			" </div>\r\n" + 
        			" <div class=\"id1\">\r\n" + 
        			" </div>\r\n" + 
        			" <div>\r\n" + 
        			"  <ul>\r\n" + 
        			"   <li class=\"current\"><a href=\"home.html\">VALID-INVALID</a></li>\r\n" + 
        			"   <li><a href=\"valid.html\">VALID</a></li>\r\n" + 
        			"   <li><a href=\"invalid.html\">INVALID</a></li>\r\n" + 
        			"<li><input type=\"search\"placeholder=\"search\"</li>\r\n" + 
        			"   \r\n" + 
        			"  </ul>\r\n" + 
        			" </div>\r\n" + 
        			"\r\n" + 
        			"\r\n" + 
        			"<body>\r\n" + 
        			"\r\n" + 
        			"<div class=\"id2\">\r\n" + 
        			"<table border=\"1\">\r\n" + 
        			"<thead>\r\n" + 
        			"<caption><b>DETAILS OF BOOKS</b></caption>\r\n" + 
        			"<tr>\r\n" + 
        			"<th>Title</th>\r\n" + 
        			"<th>Author</th>\r\n" + 
        			"<th>Price</th>\r\n" + 
        			"<th>Publisher</th>\r\n" + 
        			"<th>ISBN</th>\r\n" + 
        			"</tr>\r\n" + 
        			"</thead>\r\n" + 
        			"<tbody>\r\n" + 
        			"<tr>\r\n" + 
        			"<td>Learning Java</td>\r\n" + 
        			"<td>William Lane </td>\r\n" + 
        			"<td>12.00</td>\r\n" + 
        			"<td>Wiley</td>\r\n" + 
        			"<td>0811234561</td>\r\n" + 
        			"</tr>\r\n" + 
        			"<tr>\r\n" + 
        			"<td>title is missing</td>\r\n" + 
        			"<td>William Stalling </td>\r\n" + 
        			"<td>25.00</td>\r\n" + 
        			"<td>Prentice Hall</td>\r\n" + 
        			"<td>1304086641</td>\r\n" + 
        			"</tr>\r\n" + 
        			"<tr>\r\n" + 
        			"<td>OOP programming </td>\r\n" + 
        			"<td>Graham Winter</td>\r\n" + 
        			"<td>32.50</td>\r\n" + 
        			"<td>O'Reilly</td>\r\n" + 
        			"<td>0471974555</td>\r\n" + 
        			"</tr>\r\n" + 
        			"\r\n" + 
        			"<tr>\r\n" + 
        			"<td>Windows XP Unwired</td>\r\n" + 
        			"<td>Wei Meng Lee</td>\r\n" + 
        			"<td>24.95</td>\r\n" + 
        			"<td>O'Reilly</td>\r\n" + 
        			"<td>0596005369</td>\r\n" + 
        			"</tr>\r\n" + 
        			"<tr>\r\n" + 
        			"<td>Programming with Perl</td>\r\n" + 
        			"<td>author is missing</td>\r\n" + 
        			"<td>19.99</td>\r\n" + 
        			"<td>Wiley</td>\r\n" + 
        			"<td>0476887021</td>\r\n" + 
        			"</tr>\r\n" + 
        			"\r\n" + 
        			"<tr>\r\n" + 
        			"<td>Multimedia Comms</td>\r\n" + 
        			"<td>Fred Halsall</td>\r\n" + 
        			"<td>53.99</td>\r\n" + 
        			"<td>Addison Wesley</td>\r\n" + 
        			"<td>0201398184</td>\r\n" + 
        			"</tr>\r\n" + 
        			"\r\n" + 
        			"<tr>\r\n" + 
        			"<td>Guide to Networks</td>\r\n" + 
        			"<td>Tamara Dean</td>\r\n" + 
        			"<td>34.50</td>\r\n" + 
        			"<td>Course Tech</td>\r\n" + 
        			"<td>1439055661</td>\r\n" + 
        			"</tr>\r\n" + 
        			"\r\n" + 
        			"<tr>\r\n" + 
        			"<td>A Guide to MySQL</td>\r\n" + 
        			"<td>Paul Barry</td>\r\n" + 
        			"<td>price is missing</td>\r\n" + 
        			"<td>Thomson</td>\r\n" + 
        			"<td>1418834351</td>\r\n" + 
        			"</tr>\r\n" + 
        			"\r\n" + 
        			"<tr>\r\n" + 
        			"<td>CCDA Exam Guide</td>\r\n" + 
        			"<td>Anthony Bruno</td>\r\n" + 
        			"<td>49.95</td>\r\n" + 
        			"<td>Cisco Press</td>\r\n" + 
        			"<td>0735700745</td>\r\n" + 
        			"</tr>\r\n" + 
        			"\r\n" + 
        			"<tr>\r\n" + 
        			"<td>Perl and CGI</td>\r\n" + 
        			"<td>Elizabeth Castro</td>\r\n" + 
        			"<td>99.50</td>\r\n" + 
        			"<td>publisher is missing</td>\r\n" + 
        			"<td>0201735687</td>\r\n" + 
        			"</tr>\r\n" + 
        			"\r\n" + 
        			"<tr>\r\n" + 
        			"<td>802.11 Security</td>\r\n" + 
        			"<td>Jon Edney</td>\r\n" + 
        			"<td>68.99</td>\r\n" + 
        			"<td>Addison Wesley</td>\r\n" + 
        			"<td>0321136209</td>\r\n" + 
        			"</tr>\r\n" + 
        			"\r\n" + 
        			"<tr>\r\n" + 
        			"<td>Web Design</td>\r\n" + 
        			"<td>Hoel Sklar</td>\r\n" + 
        			"<td>9.99</td>\r\n" + 
        			"<td>Course Tech</td>\r\n" + 
        			"<td>354278794</td>\r\n" + 
        			"</tr>\r\n" + 
        			"\r\n" + 
        			"<tr>\r\n" + 
        			"<td>Large Scale LANs</td>\r\n" + 
        			"<td>Kevin Dooley</td>\r\n" + 
        			"<td>39.00</td>\r\n" + 
        			"<td>O'Reilly</td>\r\n" + 
        			"<td>0596001509</td>\r\n" + 
        			"</tr>\r\n" + 
        			"\r\n" + 
        			"\r\n" + 
        			"\r\n" + 
        			"<tr>\r\n" + 
        			"<td colspan=\"5\">Delimeter is missing</td>\r\n" + 
        			"\r\n" + 
        			"</tr>\r\n" + 
        			"\r\n" + 
        			"<tr>\r\n" + 
        			"<td>Database and Web</td>\r\n" + 
        			"<td>Simon Burns</td>\r\n" + 
        			"<td>non numeric data</td>\r\n" + 
        			"<td>Perasons</td>\r\n" + 
        			"<td>0559000412</td>\r\n" + 
        			"</tr>\r\n" + 
        			"\r\n" + 
        			"<tr>\r\n" + 
        			"<td>Wireless Hacks</td>\r\n" + 
        			"<td>Rob Weeks</td>\r\n" + 
        			"<td>29.50</td>\r\n" + 
        			"<td>O'Reilly</td>\r\n" + 
        			"<td>0596101442</td>\r\n" + 
        			"</tr>\r\n" + 
        			"\r\n" + 
        			"<tr>\r\n" + 
        			"<td>Trace of Guilt</td>\r\n" + 
        			"<td>Neil Barret</td>\r\n" + 
        			"<td>5.99</td>\r\n" + 
        			"<td>Corgi Books</td>\r\n" + 
        			"<td>non numeric data</td>\r\n" + 
        			"</tr>\r\n" + 
        			"\r\n" + 
        			"</tbody>\r\n" + 
        			"</table>\r\n" + 
        			" </div>\r\n" + 
        			"<div class=\"footer\">\r\n" + 
        			"   <h3>Contact Details</h3>\r\n" + 
        			"  <p>Basanta Timilsena<br>9845634510<br>Babarhmahal,Kathmandu<br>Nepal</p>\r\n" + 
        			"@Java Project, 2017</div>\r\n" + 
        			"\r\n" + 
        			"   \r\n" + 
        			"</body>\r\n" + 
        			"</html>";
        	
        	
    		
    		File obj = new File ("home.html");
    		
    		String htm ="<!DOCTYPE html>\r\n" + 
    				"<html>\r\n" + 
    				"<head>\r\n" + 
    				"<style>\r\n" + 
    				"body{background-color:#d5dcf2;}\r\n" + 
    				"</style>\r\n" + 
    				"\r\n" + 
    				"<title>Project of java</title>\r\n" + 
    				"\r\n" + 
    				"<link rel=\"stylesheet\" href=\"project.css\">\r\n" + 
    				"\r\n" + 
    				"\r\n" + 
    				"</head>\r\n" + 
    				"\r\n" + 
    				"<body>\r\n" + 
    				" <div class=\"mainpage\">\r\n" + 
    				"\r\n" + 
    				"\r\n" + 
    				" <div class=\"header\">\r\n" + 
    				"  \r\n" + 
    				"  <h2>Books Information</h2>\r\n" + 
    				" </div>\r\n" + 
    				" <div class=\"id1\">\r\n" + 
    				" </div>\r\n" + 
    				" <div>\r\n" + 
    				"  <ul>\r\n" + 
    				"   <li><a href=\"home.html\">VALID-INVALID</a></li>\r\n" + 
    				"   <li class=\"current\"><a href=\"valid.html\">VALID</a></li>\r\n" + 
    				"   <li><a href=\"invalid.html\">INVALID</a></li>\r\n" + 
    				"   <li><input type=\"search\"placeholder=\"search\"</li>\r\n" + 
    				"  </ul>\r\n" + 
    				" </div>\r\n" + 
    				"<div class=\"id2\">\r\n" + 
    				"\r\n" + 
    				"<table border=\"1\">\r\n" + 
    				"<thead>\r\n" + 
    				"<caption><b>DETAILS OF BOOKS</b></caption>\r\n" + 
    				"<tr>\r\n" + 
    				"<th>Title</th>\r\n" + 
    				"<th>Author</th>\r\n" + 
    				"<th>Price</th>\r\n" + 
    				"<th>Publisher</th>\r\n" + 
    				"<th>ISBN</th>\r\n" + 
    				"</tr>\r\n" + 
    				"</thead>\r\n" + 
    				"<tbody>\r\n" + 
    				"<tr>\r\n" + 
    				"<td>Learning Java</td>\r\n" + 
    				"<td>William Lane </td>\r\n" + 
    				"<td>12.00</td>\r\n" + 
    				"<td>Wiley</td>\r\n" + 
    				"<td>0811234561</td>\r\n" + 
    				"\r\n" + 
    				"<tr>\r\n" + 
    				"<td>OOP programming </td>\r\n" + 
    				"<td>Graham Winter</td>\r\n" + 
    				"<td>32.50</td>\r\n" + 
    				"<td>O'Reilly</td>\r\n" + 
    				"<td>0471974555</td>\r\n" + 
    				"</tr>\r\n" + 
    				"\r\n" + 
    				"<tr>\r\n" + 
    				"<td>Windows XP Unwired</td>\r\n" + 
    				"<td>Wei Meng Lee</td>\r\n" + 
    				"<td>24.95</td>\r\n" + 
    				"<td>O'Reilly</td>\r\n" + 
    				"<td>0596005369</td>\r\n" + 
    				"</tr>\r\n" + 
    				"\r\n" + 
    				"\r\n" + 
    				"<tr>\r\n" + 
    				"<td>Multimedia Comms</td>\r\n" + 
    				"<td>Fred Halsall</td>\r\n" + 
    				"<td>53.99</td>\r\n" + 
    				"<td>Addison Wesley</td>\r\n" + 
    				"<td>0201398184</td>\r\n" + 
    				"</tr>\r\n" + 
    				"\r\n" + 
    				"<tr>\r\n" + 
    				"<td>Guide to Networks</td>\r\n" + 
    				"<td>Tamara Dean</td>\r\n" + 
    				"<td>34.50</td>\r\n" + 
    				"<td>Course Tech</td>\r\n" + 
    				"<td>1439055661</td>\r\n" + 
    				"</tr>\r\n" + 
    				"\r\n" + 
    				"\r\n" + 
    				"\r\n" + 
    				"<tr>\r\n" + 
    				"<td>CCDA Exam Guide</td>\r\n" + 
    				"<td>Anthony Bruno</td>\r\n" + 
    				"<td>49.95</td>\r\n" + 
    				"<td>Cisco Press</td>\r\n" + 
    				"<td>0735700745</td>\r\n" + 
    				"</tr>\r\n" + 
    				"\r\n" + 
    				"\r\n" + 
    				"\r\n" + 
    				"<tr>\r\n" + 
    				"<td>802.11 Security</td>\r\n" + 
    				"<td>Jon Edney</td>\r\n" + 
    				"<td>68.99</td>\r\n" + 
    				"<td>Addison Wesley</td>\r\n" + 
    				"<td>0321136209</td>\r\n" + 
    				"</tr>\r\n" + 
    				"\r\n" + 
    				"<tr>\r\n" + 
    				"<td>Web Design</td>\r\n" + 
    				"<td>Hoel Sklar</td>\r\n" + 
    				"<td>9.99</td>\r\n" + 
    				"<td>Course Tech</td>\r\n" + 
    				"<td>354278794</td>\r\n" + 
    				"</tr>\r\n" + 
    				"\r\n" + 
    				"<tr>\r\n" + 
    				"<td>Large Scale LANs</td>\r\n" + 
    				"<td>Kevin Dooley</td>\r\n" + 
    				"<td>39.00</td>\r\n" + 
    				"<td>O'Reilly</td>\r\n" + 
    				"<td>0596001509</td>\r\n" + 
    				"</tr>\r\n" + 
    				"\r\n" + 
    				"\r\n" + 
    				"\r\n" + 
    				"\r\n" + 
    				"\r\n" + 
    				"<tr>\r\n" + 
    				"<td>Database and Web</td>\r\n" + 
    				"<td>Simon Burns</td>\r\n" + 
    				"<td>non numeric data</td>\r\n" + 
    				"<td>Perasons</td>\r\n" + 
    				"<td>0559000412</td>\r\n" + 
    				"</tr>\r\n" + 
    				"\r\n" + 
    				"<tr>\r\n" + 
    				"<td>Wireless Hacks</td>\r\n" + 
    				"<td>Rob Weeks</td>\r\n" + 
    				"<td>29.50</td>\r\n" + 
    				"<td>O'Reilly</td>\r\n" + 
    				"<td>0596101442</td>\r\n" + 
    				"</tr>\r\n" + 
    				"\r\n" + 
    				"\r\n" + 
    				"\r\n" + 
    				"</tbody>\r\n" + 
    				"</table>\r\n" + 
    				" </div>\r\n" + 
    				"<div class=\"foot\">\r\n" + 
    				"   <h3>Contact Details</h3>\r\n" + 
    				"  <p>Basanta Timilsena<br>9845634510<br>Babarhmahal,Kathmandu<br>Nepal</p>\r\n" + 
    				"@Java Project, 2017</div>\r\n" + 
    				"\r\n" + 
    				"   \r\n" + 
    				"</body>\r\n" + 
    				"\r\n" + 
    				"</html>";
    		
    		File obje = new File ("valid.html");
    		
    		String ht = "<!DOCTYPE html>\r\n" + 
    				"<html>\r\n" + 
    				"<head>\r\n" + 
    				"<style>\r\n" + 
    				"body{background-color:#d5dcf2;}\r\n" + 
    				"</style>\r\n" + 
    				"\r\n" + 
    				"<title>Project of java</title>\r\n" + 
    				"\r\n" + 
    				"<link rel=\"stylesheet\" href=\"project.css\">\r\n" + 
    				"\r\n" + 
    				"\r\n" + 
    				"</head>\r\n" + 
    				"\r\n" + 
    				"<body>\r\n" + 
    				" <div class=\"mainpage\">\r\n" + 
    				"\r\n" + 
    				"\r\n" + 
    				" <div class=\"header\">\r\n" + 
    				"  \r\n" + 
    				"  <h2>Books Information</h2>\r\n" + 
    				" </div>\r\n" + 
    				" <div class=\"id1\">\r\n" + 
    				" </div>\r\n" + 
    				" <div>\r\n" + 
    				"  <ul>\r\n" + 
    				"   <li><a href=\"home.html\">HOME</a></li>\r\n" + 
    				"<li><a href=\"valid.html\">VALID</a></li>   \r\n" + 
    				"<li class=\"current\"><a href=\"invalid.html\">INVALID</a></li>\r\n" + 
    				"<li><input type=\"search\"placeholder=\"search\"</li>\r\n" + 
    				"   \r\n" + 
    				"   \r\n" + 
    				"  </ul>\r\n" + 
    				" </div>\r\n" + 
    				"<div class=\"id2\">\r\n" + 
    				" </div>\r\n" + 
    				"\r\n" + 
    				"<table border=\"1\">\r\n" + 
    				"<thead>\r\n" + 
    				"<caption><b>DETAILS OF BOOKS</b></caption>\r\n" + 
    				"<tr>\r\n" + 
    				"<th>Title</th>\r\n" + 
    				"<th>Author</th>\r\n" + 
    				"<th>Price</th>\r\n" + 
    				"<th>Publisher</th>\r\n" + 
    				"<th>ISBN</th>\r\n" + 
    				"</tr>\r\n" + 
    				"</thead>\r\n" + 
    				"<tbody>\r\n" + 
    				"\r\n" + 
    				"<tr>\r\n" + 
    				"<td>title is missing</td>\r\n" + 
    				"<td>William Stalling </td>\r\n" + 
    				"<td>25.00</td>\r\n" + 
    				"<td>Prentice Hall</td>\r\n" + 
    				"<td>1304086641</td>\r\n" + 
    				"</tr>\r\n" + 
    				"\r\n" + 
    				"<tr>\r\n" + 
    				"<td>Programming with Perl</td>\r\n" + 
    				"<td>author is missing</td>\r\n" + 
    				"<td>19.99</td>\r\n" + 
    				"<td>Wiley</td>\r\n" + 
    				"<td>0476887021</td>\r\n" + 
    				"</tr>\r\n" + 
    				"\r\n" + 
    				"\r\n" + 
    				"\r\n" + 
    				"\r\n" + 
    				"<tr>\r\n" + 
    				"<td>A Guide to MySQL</td>\r\n" + 
    				"<td>Paul Barry</td>\r\n" + 
    				"<td>price is missing</td>\r\n" + 
    				"<td>Thomson</td>\r\n" + 
    				"<td>1418834351</td>\r\n" + 
    				"</tr>\r\n" + 
    				"\r\n" + 
    				"\r\n" + 
    				"\r\n" + 
    				"<tr>\r\n" + 
    				"<td>Perl and CGI</td>\r\n" + 
    				"<td>Elizabeth Castro</td>\r\n" + 
    				"<td>99.50</td>\r\n" + 
    				"<td>publisher is missing</td>\r\n" + 
    				"<td>0201735687</td>\r\n" + 
    				"</tr>\r\n" + 
    				"\r\n" + 
    				"\r\n" + 
    				"\r\n" + 
    				"<tr>\r\n" + 
    				"<td>Web Design</td>\r\n" + 
    				"<td>Hoel Sklar</td>\r\n" + 
    				"<td>9.99</td>\r\n" + 
    				"<td>Course Tech</td>\r\n" + 
    				"<td>354278794</td>\r\n" + 
    				"</tr>\r\n" + 
    				"\r\n" + 
    				"\r\n" + 
    				"\r\n" + 
    				"\r\n" + 
    				"\r\n" + 
    				"<tr>\r\n" + 
    				"<td colspan=\"5\">Delimeter is missing</td>\r\n" + 
    				"\r\n" + 
    				"</tr>\r\n" + 
    				"\r\n" + 
    				"<tr>\r\n" + 
    				"<td>Database and Web</td>\r\n" + 
    				"<td>Simon Burns</td>\r\n" + 
    				"<td>non numeric data</td>\r\n" + 
    				"<td>Perasons</td>\r\n" + 
    				"<td>0559000412</td>\r\n" + 
    				"</tr>\r\n" + 
    				"\r\n" + 
    				"\r\n" + 
    				"<tr>\r\n" + 
    				"<td>Trace of Guilt</td>\r\n" + 
    				"<td>Neil Barret</td>\r\n" + 
    				"<td>5.99</td>\r\n" + 
    				"<td>Corgi Books</td>\r\n" + 
    				"<td>non numeric data</td>\r\n" + 
    				"</tr>\r\n" + 
    				"\r\n" + 
    				"\r\n" + 
    				"</tbody>\r\n" + 
    				"</table>\r\n" + 
    				" <div class=\"shoot\">\r\n" + 
    				"   <h3>Contact Details</h3>\r\n" + 
    				"  <p>Basanta Timilsena<br>9845634510<br>Babarhmahal,Kathmandu<br>Nepal</p>\r\n" + 
    				"@Java Project, 2017</div>\r\n" + 
    				"</body>\r\n" + 
    				"</html>";
    		
    		File objec = new File ("invalid.html");
    		
    		try {
    			BufferedWriter bw=new BufferedWriter(new FileWriter(obj));
    			BufferedWriter buw=new BufferedWriter(new FileWriter(obje));
    			BufferedWriter buwr=new BufferedWriter(new FileWriter(objec));
    			bw.write(html);
    			bw.close();
    			buw.write(htm);
    			buw.close();
    			buwr.write(ht);
    			buwr.close();
    		}
    		catch (IOException e) {
    			e.printStackTrace();
    			
    			}
        	
        	

		}
		
		
	}
	}
	
	
			



